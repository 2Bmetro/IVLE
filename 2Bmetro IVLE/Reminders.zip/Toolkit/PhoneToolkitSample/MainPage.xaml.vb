﻿' ----------------------------------------------------------------------------------
' Microsoft Developer & Platform Evangelism
' 
' Copyright (c) Microsoft Corporation. All rights reserved.
' 
' THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
' EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
' OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
' ----------------------------------------------------------------------------------
' The example companies, organizations, products, domain names,
' e-mail addresses, logos, people, places, and events depicted
' herein are fictitious.  No association with any real company,
' organization, product, domain name, email address, logo, person,
' places, or events is intended or should be inferred.
' ----------------------------------------------------------------------------------

' (c) Copyright Microsoft Corporation.
' This source is subject to the Microsoft Public License (Ms-PL).
' Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
' All other rights reserved.

Partial Public Class MainPage
    Inherits PhoneApplicationPage
    ' Constructor
    Public Sub New()
        InitializeComponent()
    End Sub

    Private Sub NavigateTo(ByVal page As String)
        Me.NavigationService.Navigate(New Uri(page, UriKind.Relative))
    End Sub

    Private Sub OnToggleSwitch(ByVal sender As Object, ByVal e As RoutedEventArgs)
        NavigateTo("/Samples/ToggleSwitchSample.xaml")
    End Sub

    Private Sub OnTransitions(ByVal sender As Object, ByVal e As RoutedEventArgs)
        NavigateTo("/Samples/TransitionsSample.xaml")
    End Sub

    Private Sub OnTiltEffect(ByVal sender As Object, ByVal e As RoutedEventArgs)
        NavigateTo("/Samples/TiltEffectSample.xaml")
    End Sub

    Private Sub OnPerformanceProgressBar(ByVal sender As Object, ByVal e As RoutedEventArgs)
        NavigateTo("/Samples/PerformanceProgressBarSample.xaml")
    End Sub

    Private Sub OnContextMenu(ByVal sender As Object, ByVal e As RoutedEventArgs)
        NavigateTo("/Samples/ContextMenuSample.xaml")
    End Sub

    Private Sub OnDateTimePicker(ByVal sender As Object, ByVal e As RoutedEventArgs)
        NavigateTo("/Samples/DateTimePickerSample.xaml")
    End Sub

    Private Sub OnWrapPanel(ByVal sender As Object, ByVal e As RoutedEventArgs)
        NavigateTo("/Samples/WrapPanelSample.xaml")
    End Sub

    Private Sub OnGestures(ByVal sender As Object, ByVal e As RoutedEventArgs)
        NavigateTo("/Samples/GestureSample.xaml")
    End Sub

    Private Sub OnAutoCompleteBox(ByVal sender As Object, ByVal e As RoutedEventArgs)
        NavigateTo("/Samples/AutoCompleteBoxSample.xaml")
    End Sub

    Private Sub OnListPicker(ByVal sender As Object, ByVal e As RoutedEventArgs)
        NavigateTo("/Samples/ListPickerSample.xaml")
    End Sub

    Private Sub OnLongListSelector(ByVal sender As Object, ByVal e As RoutedEventArgs)
        NavigateTo("/Samples/LongListSelectorSample.xaml")
    End Sub
End Class

