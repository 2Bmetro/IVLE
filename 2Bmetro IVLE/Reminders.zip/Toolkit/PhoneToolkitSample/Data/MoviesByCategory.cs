﻿// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Public License (Ms-PL).
// Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
// All other rights reserved.

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Windows.Input;

namespace PhoneToolkitSample.Data
{
    public class MoviesByCategory : ObservableCollection<MoviesInCategory>
    {
        public MoviesByCategory()
        {
            List<string> sortedCategories = new List<string>(Movie.Categories);
            sortedCategories.Sort();

            foreach (string category in sortedCategories)
            {
                MoviesInCategory group = new MoviesInCategory(category);
                this.Add(group);

                for (int i = 0; i < 5; ++i)
                {
                    group.Add(Movie.CreateRandom(category));
                }                
            }
        }
    }

    public class MoreCommand : ICommand
    {
        #region ICommand Members

        public bool CanExecute(object parameter)
        {
            return true;
        }

        public event EventHandler CanExecuteChanged;

        public void Execute(object parameter)
        {
            MoviesInCategory group = parameter as MoviesInCategory;
            if (group != null)
            {
                group.Add(Movie.CreateRandom(group.Key));
            }
        }

        #endregion
    }
}
