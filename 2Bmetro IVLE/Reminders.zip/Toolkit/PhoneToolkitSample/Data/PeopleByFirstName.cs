﻿// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Public License (Ms-PL).
// Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
// All other rights reserved.

using System.Collections.Generic;

namespace PhoneToolkitSample.Data
{
    public class PeopleByFirstName : List<PeopleInGroup>
    {
        private static readonly string Groups = "#abcdefghijklmnopqrstuvwxyz";

        private Dictionary<int, Person> _personLookup = new Dictionary<int, Person>();

        public PeopleByFirstName()
        {
            List<Person> people = new List<Person>(AllPeople.Current);
            people.Sort(Person.CompareByFirstName);

            Dictionary<string, PeopleInGroup> groups = new Dictionary<string, PeopleInGroup>();

            foreach (char c in Groups)
            {
                PeopleInGroup group = new PeopleInGroup(c.ToString());
                this.Add(group);
                groups[c.ToString()] = group;
            }

            foreach (Person person in people)
            {
                groups[Person.GetFirstNameKey(person)].Add(person);
            }
        }
    }
}
