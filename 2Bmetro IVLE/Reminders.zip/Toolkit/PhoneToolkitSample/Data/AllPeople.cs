﻿// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Public License (Ms-PL).
// Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
// All other rights reserved.

using System.Collections.Generic;

namespace PhoneToolkitSample.Data
{
    public class AllPeople : IEnumerable<Person>
    {
        private static Dictionary<int, Person> _personLookup;
        private static AllPeople _instance;

        public static AllPeople Current
        {
            get
            {
                return _instance ?? (_instance = new AllPeople());
            }
        }

        public Person this[int index]
        {
            get
            {
                Person person;
                _personLookup.TryGetValue(index, out person);
                return person;
            }
        }

        #region IEnumerable<Person> Members

        public IEnumerator<Person> GetEnumerator()
        {
            EnsureData();
            return _personLookup.Values.GetEnumerator();
        }

        #endregion

        #region IEnumerable Members

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            EnsureData();
            return _personLookup.Values.GetEnumerator();
        }

        #endregion

        private void EnsureData()
        {
            if (_personLookup == null)
            {
                _personLookup = new Dictionary<int, Person>();
                for (int n = 0; n < 100; ++n)
                {
                    Person person = Person.GetRandomPerson(n);
                    _personLookup[n] = person;
                }
            }
        }

    }
}
