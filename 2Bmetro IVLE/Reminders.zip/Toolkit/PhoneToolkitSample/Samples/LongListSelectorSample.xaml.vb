﻿' ----------------------------------------------------------------------------------
' Microsoft Developer & Platform Evangelism
' 
' Copyright (c) Microsoft Corporation. All rights reserved.
' 
' THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
' EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
' OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
' ----------------------------------------------------------------------------------
' The example companies, organizations, products, domain names,
' e-mail addresses, logos, people, places, and events depicted
' herein are fictitious.  No association with any real company,
' organization, product, domain name, email address, logo, person,
' places, or events is intended or should be inferred.
' ----------------------------------------------------------------------------------

' (c) Copyright Microsoft Corporation.
' This source is subject to the Microsoft Public License (Ms-PL).
' Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
' All other rights reserved.

Imports PhoneToolkitSample.Data

Namespace Samples

    Partial Public Class LongListSelectorSample
        Inherits PhoneApplicationPage
        Public Sub New()
            InitializeComponent()
            LoadLinqMovies()
            AddHandler linqMovies.SelectionChanged, AddressOf MovieSelectionChanged
            AddHandler codeMovies.SelectionChanged, AddressOf MovieSelectionChanged
        End Sub


        Private Sub LoadLinqMovies()
            Dim movies As New List(Of Movie)

            For i = 0 To 49
                movies.Add(Movie.CreateRandom())
            Next i

            Dim g = movies.GroupBy(Function(p) p.Category).OrderBy(Function(p) p.Key)
            Dim moviesByCategory = From c In g
                  Select New PublicGrouping(Of String, Movie)(c)

            linqMovies.ItemsSource = moviesByCategory
        End Sub

        Private Sub MovieSelectionChanged(ByVal sender As Object, ByVal e As SelectionChangedEventArgs)

        End Sub

        Private Sub PersonSelectionChanged(ByVal sender As Object, ByVal e As SelectionChangedEventArgs) Handles buddies.SelectionChanged
            Dim _person = TryCast(buddies.SelectedItem, Person)
            If _person IsNot Nothing Then
                NavigationService.Navigate(New Uri("/Samples/PersonDetail.xaml?ID=" & _person.ID, UriKind.Relative))
            End If
        End Sub
    End Class

End Namespace
