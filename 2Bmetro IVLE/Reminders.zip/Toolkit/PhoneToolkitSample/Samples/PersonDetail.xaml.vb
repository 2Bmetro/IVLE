﻿' ----------------------------------------------------------------------------------
' Microsoft Developer & Platform Evangelism
' 
' Copyright (c) Microsoft Corporation. All rights reserved.
' 
' THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
' EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
' OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
' ----------------------------------------------------------------------------------
' The example companies, organizations, products, domain names,
' e-mail addresses, logos, people, places, and events depicted
' herein are fictitious.  No association with any real company,
' organization, product, domain name, email address, logo, person,
' places, or events is intended or should be inferred.
' ----------------------------------------------------------------------------------

' (c) Copyright Microsoft Corporation.
' This source is subject to the Microsoft Public License (Ms-PL).
' Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
' All other rights reserved.

Imports PhoneToolkitSample.Data

Namespace Samples

    Partial Public Class PersonDetail
        Inherits PhoneApplicationPage
        Public Sub New()
            InitializeComponent()

            quote.Text =
                LoremIpsum.GetParagraph(4) & Environment.NewLine & Environment.NewLine &
                LoremIpsum.GetParagraph(8) & Environment.NewLine & Environment.NewLine &
                LoremIpsum.GetParagraph(6)
        End Sub

        Protected Overrides Sub OnNavigatedTo(ByVal e As NavigationEventArgs)
            MyBase.OnNavigatedTo(e)
            Dim idParam As String = Nothing
            If NavigationContext.QueryString.TryGetValue("ID", idParam) Then
                Dim id = Int32.Parse(idParam)
                DataContext = AllPeople.Current(id)
            End If
        End Sub
    End Class

End Namespace
