﻿// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Public License (Ms-PL).
// Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
// All other rights reserved.

using System.ComponentModel;
using System.Windows;
using Microsoft.Windows.Design.Features;
using Microsoft.Windows.Design.Metadata;

namespace Microsoft.Phone.Controls.Design
{
    internal class ToggleSwitchMetadata : AttributeTableBuilder
    {
        public ToggleSwitchMetadata()
        {
            // Type attributes
            AddCustomAttributes(typeof(ToggleSwitch), new DescriptionAttribute("Represents a switch that can be toggled between two states."));
            AddCustomAttributes(typeof(ToggleSwitch), new FeatureAttribute(typeof(ToggleSwitchInitializer)));

            // Property attributes
            AddCustomAttributes(typeof(ToggleSwitch), "IsChecked", new CategoryAttribute(MetadataStore.CommonProperties));
            AddCustomAttributes(typeof(ToggleSwitch), "IsChecked", new DescriptionAttribute("Gets or sets whether the ToggleSwitch is checked."));
            AddCustomAttributes(typeof(ToggleSwitch), "IsChecked", new TypeConverterAttribute(typeof(NullableBoolConverter)));
            AddCustomAttributes(typeof(ToggleSwitch), "Header", new CategoryAttribute(MetadataStore.CommonProperties));
            AddCustomAttributes(typeof(ToggleSwitch), "Header", new DescriptionAttribute("Gets or sets the header."));
            AddCustomAttributes(typeof(ToggleSwitch), "Header", new TypeConverterAttribute(typeof(StringConverter)));
            AddCustomAttributes(typeof(ToggleSwitch), "HeaderTemplate", new DescriptionAttribute("Gets or sets the template used to display the control's header."));
            AddCustomAttributes(typeof(ToggleSwitch), "Checked", new DescriptionAttribute("Occurs when a ToggleSwitch is checked."));
            AddCustomAttributes(typeof(ToggleSwitch), "Unchecked", new DescriptionAttribute("Occurs when a ToggleSwitch is unchecked."));
        }
    }
}