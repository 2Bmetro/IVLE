﻿// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Public License (Ms-PL).
// Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
// All other rights reserved.

using System.Windows;
using System.Windows.Controls;

namespace Microsoft.Phone.Controls
{
    /// <summary>
    /// Class that implements a container for the ListPicker control.
    /// </summary>
    [TemplateVisualState(GroupName = SelectionStatesGroupName, Name = SelectionStatesUnselectedStateName)]
    [TemplateVisualState(GroupName = SelectionStatesGroupName, Name = SelectionStatesSelectedStateName)]
    public class ListPickerItem : ContentControl
    {
        private const string SelectionStatesGroupName = "SelectionStates";
        private const string SelectionStatesUnselectedStateName = "Unselected";
        private const string SelectionStatesSelectedStateName = "Selected";

        /// <summary>
        /// Initializes a new instance of the ListPickerItem class.
        /// </summary>
        public ListPickerItem()
        {
            DefaultStyleKey = typeof(ListPickerItem);
        }

        /// <summary>
        /// Builds the visual tree for the control when a new template is applied.
        /// </summary>
        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();
            VisualStateManager.GoToState(this, IsSelected ? SelectionStatesSelectedStateName : SelectionStatesUnselectedStateName, false);
        }

        internal bool IsSelected
        {
            get { return _isSelected; }
            set
            {
                _isSelected = value;
                VisualStateManager.GoToState(this, _isSelected ? SelectionStatesSelectedStateName : SelectionStatesUnselectedStateName, true);
            }
        }
        private bool _isSelected;
    }
}
