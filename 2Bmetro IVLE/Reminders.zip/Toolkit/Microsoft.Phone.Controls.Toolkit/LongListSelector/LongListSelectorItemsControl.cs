﻿// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Public License (Ms-PL).
// Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
// All other rights reserved.

using System;
using System.Windows;
using System.Windows.Controls;

namespace Microsoft.Phone.Controls
{
    /// <summary>
    /// Partial definition of LongListSelector. Includes ItemsControl subclass.
    /// </summary>
    public partial class LongListSelector : Control
    {
        private class GroupSelectedEventArgs : EventArgs
        {
            public GroupSelectedEventArgs(object group)
            {
                Group = group;
            }

            public object Group { get; private set; }
        }

        private delegate void GroupSelectedEventHandler(object sender, GroupSelectedEventArgs e);

        private class LongListSelectorItemsControl : ItemsControl
        {
            public event GroupSelectedEventHandler GroupSelected;

            protected override void PrepareContainerForItemOverride(DependencyObject element, object item)
            {
                base.PrepareContainerForItemOverride(element, item);

                GestureService.GetGestureListener(element).Tap += LongListSelectorItemsControl_Tap;
            }

            protected override void ClearContainerForItemOverride(DependencyObject element, object item)
            {
                base.ClearContainerForItemOverride(element, item);

                GestureService.GetGestureListener(element).Tap -= LongListSelectorItemsControl_Tap;
            }

            private void LongListSelectorItemsControl_Tap(object sender, GestureEventArgs e)
            {
                ContentPresenter cc = sender as ContentPresenter;
                if (cc != null)
                {
                    GroupSelectedEventHandler handler = GroupSelected;
                    if (handler != null)
                    {
                        GroupSelectedEventArgs args = new GroupSelectedEventArgs(cc.Content);
                        handler(this, args);
                    }
                }
            }
        }
    }
}
