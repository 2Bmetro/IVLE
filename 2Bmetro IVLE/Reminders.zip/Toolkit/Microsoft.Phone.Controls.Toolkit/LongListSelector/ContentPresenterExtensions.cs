﻿// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Public License (Ms-PL).
// Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
// All other rights reserved.

using System.Windows.Controls;

namespace Microsoft.Phone.Controls
{
    /// <summary>
    /// This class utilizes the Tag property to attach data to ContentPresenters
    /// </summary>
    internal static class ContentPresenterExtensions
    {
        private class ExtraData
        {
            public int ResolvedIndex;
            public double LastDesiredHeight;
        }

        public static void GetExtraData(this ContentPresenter cp, out int resolvedIndex, out double lastDesiredHeight)
        {
            ExtraData extraData = cp.Tag as ExtraData;
            if (extraData != null)
            {
                resolvedIndex = extraData.ResolvedIndex;
                lastDesiredHeight = extraData.LastDesiredHeight;
            }
            else
            {
                resolvedIndex = -1;
                lastDesiredHeight = 0;
            }
        }

        public static void SetExtraData(this ContentPresenter cp, int resolvedIndex, double lastDesiredHeight)
        {
            ExtraData extraData = cp.Tag as ExtraData;
            if (extraData == null)
            {
                cp.Tag = extraData = new ExtraData();                
            }
            extraData.ResolvedIndex = resolvedIndex;
            extraData.LastDesiredHeight = lastDesiredHeight;
        }
    }
}