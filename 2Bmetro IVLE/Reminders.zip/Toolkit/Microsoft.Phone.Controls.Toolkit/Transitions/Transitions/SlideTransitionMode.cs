﻿// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Public License (Ms-PL).
// Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
// All other rights reserved.

namespace Microsoft.Phone.Controls
{
    /// <summary>
    /// The slide transition modes.
    /// </summary>
    public enum SlideTransitionMode
    {
        /// <summary>
        /// The slide up, fade in transition mode.
        /// </summary>
        SlideUpFadeIn,
        /// <summary>
        /// The slide up, fade out transition mode.
        /// </summary>
        SlideUpFadeOut,
        /// <summary>
        /// The slide down, fade in transition mode.
        /// </summary>
        SlideDownFadeIn,
        /// <summary>
        /// The slide down, fade out transition mode.
        /// </summary>
        SlideDownFadeOut,
        /// <summary>
        /// The slide left, fade in transition mode.
        /// </summary>
        SlideLeftFadeIn,
        /// <summary>
        /// The slide left, fade out transition mode.
        /// </summary>
        SlideLeftFadeOut,
        /// <summary>
        /// The slide right, fade in transition mode.
        /// </summary>
        SlideRightFadeIn,
        /// <summary>
        /// The slide right, fade out transition mode.
        /// </summary>
        SlideRightFadeOut
    };
}