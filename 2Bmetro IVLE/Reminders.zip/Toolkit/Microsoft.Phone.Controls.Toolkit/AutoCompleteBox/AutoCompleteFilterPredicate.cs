﻿// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Public License (Ms-PL).
// Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
// All other rights reserved.

#if WINDOWS_PHONE
namespace Microsoft.Phone.Controls
#else
namespace System.Windows.Controls
#endif
{
    /// <summary>
    /// Represents the filter used by the
    /// <see cref="T:System.Windows.Controls.AutoCompleteBox" /> control to
    /// determine whether an item is a possible match for the specified text.
    /// </summary>
    /// <returns>true to indicate <paramref name="item" /> is a possible match
    /// for <paramref name="search" />; otherwise false.</returns>
    /// <param name="search">The string used as the basis for filtering.</param>
    /// <param name="item">The item that is compared with the
    /// <paramref name="search" /> parameter.</param>
    /// <typeparam name="T">The type used for filtering the
    /// <see cref="T:System.Windows.Controls.AutoCompleteBox" />. This type can
    /// be either a string or an object.</typeparam>
    /// <QualityBand>Stable</QualityBand>
    public delegate bool AutoCompleteFilterPredicate<T>(string search, T item);
}