﻿// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using System.Linq;
using System.Windows.Media.Imaging;
using System.IO.IsolatedStorage;
using Todo.Misc;
using Todo.Shell;
using Todo.Resources;

namespace Todo
{
    public static class ShellTileHelpersUI
    {
        public static bool IsPinned(this PhoneApplicationPage page)
        {
            return ShellTileHelpersCore.IsPinned(page.NavigationService.CurrentSource);
        }

        public static bool IsPinned(this Project project)
        {
            Uri uri = project.MakePinnedProjectUri();
            return ShellTileHelpersCore.IsPinned(project.Id.ToString());
        }

        //DEMOSTOP#6 
        public static void PinProject(Project p)
        {
            // Create the object to hold the properties for the tile
            StandardTileData initialData = new StandardTileData
            {
                //We can add a background image, count and title, just like with Push
                BackgroundImage = p.GetDefaultTileUri(),
                Title = p.Name,
            };

            Uri uri = p.MakePinnedProjectUri();
            ShellTileHelpersCore.Pin(uri, initialData);
        }


        public static void UnPinProject(Project p)
        {
            ShellTileHelpersCore.UnPin(p.Id.ToString());
        }

        public static Uri GetDefaultTileUri(this Project project)
        {
            string color = ApplicationStrings.ColorBlue; // default to blue 
            ColorEntryList list = App.Current.Resources[UIConstants.ColorEntries] as ColorEntryList;
            if (list != null)
            {
                ColorEntry projectEntry = list.FirstOrDefault(x => x.Color == project.Color);
                if (projectEntry != null)
                    color = projectEntry.Name;
            }

            return UIConstants.MakeDefaultTileUri(color);
        }

        public static string CreateTileBackground(this Project project)
        {
            Grid grid = new Grid();
            Rectangle rect = new Rectangle();
            rect.Width = 173;
            rect.Height = 173;
            rect.Fill = new SolidColorBrush(project.Color.ToColor());

            TextBlock text = new TextBlock();
            text.Text = "TASK";
            text.Foreground = new SolidColorBrush(Colors.White);
            text.FontSize = 32;
            grid.Children.Add(rect);
            grid.Children.Add(text);
            grid.Arrange(new Rect(0d, 0d, 173d, 173d));

            WriteableBitmap wbmp = new WriteableBitmap(grid, null);
            string tiledirectory = "tiles";
            string fullPath = tiledirectory + @"/" + project.Name + ".jpg";
            using (var store = IsolatedStorageFile.GetUserStoreForApplication())
            {

                if (!store.DirectoryExists(tiledirectory))
                {
                    store.CreateDirectory(tiledirectory);
                }

                using (var stream = store.OpenFile(fullPath, System.IO.FileMode.OpenOrCreate))
                {
                    wbmp.SaveJpeg(stream, 173, 173, 0, 100);
                }


            }
            return "isostore:/" + fullPath;
        }

        public static Uri MakePinnedProjectUri(this Project p)
        {
            return UIConstants.MakePinnedProjectUri(p);
        }
    }
}
