﻿// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

using System;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Data;
using Todo.Misc;

namespace Todo.Converters
{
    /// <summary>
    /// Converts a textual string into a color entry from the ones available in the application resources.
    /// </summary>
    public class ColorStringToColorEntryConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            ColorEntryList colorEntries = App.Current.Resources["ColorEntries"] as ColorEntryList;
            ColorEntry entry = colorEntries.FirstOrDefault(ce => ce.Color.ToString() == value.ToString());
            if (entry == null)
            {
                System.Diagnostics.Debug.WriteLine("TODO: CLean this up, Jaime added as temporary workaround, since it was crashing and preventing me from doing other work");
                entry = new ColorEntry();
                entry.Color = (string) value;
                entry.Name = "UNKNOWN"; 
            }
            return entry; 
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            return (value as ColorEntry).Color.ToString();
        }
    }
}
