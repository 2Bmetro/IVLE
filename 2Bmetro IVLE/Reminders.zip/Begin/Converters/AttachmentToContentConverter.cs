﻿// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Data;
using Todo.Misc;
using System.IO;
using System.Windows.Media.Imaging;

namespace Todo.Converters
{
    /// <summary>
    /// Converts an attachment into a control that displays it.
    /// </summary>
    public class AttachmentToContentConverter : IValueConverter
    {
        #region IValueConverter Members

        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            Attachment attachment = (Attachment)value;
            FrameworkElement attachmentElement = null;

            Binding textNoteBinding = new Binding()
            {
                Source = attachment,
                Path = new PropertyPath("TextNote")
            };

            switch (attachment.AttachmentTypeID.ToString())
            {
                case Utils.AttachmentTypeIDText:
                    TextBlock text = new TextBlock();

                    text.SetBinding(TextBlock.TextProperty, textNoteBinding);

                    attachmentElement = text;
                    break;

                case Utils.AttachmentTypeIDImage:
                    // Create a small preview image
                    Image image = new Image();
                    image.Stretch = Stretch.Uniform;
                    image.Width = 200;

                    // Do not bind the image, as it cannot be changed short of recreating the attachment
                    MemoryStream memoryStream = new MemoryStream(attachment.Blob.ToArray());
                    BitmapImage bitmap = new BitmapImage();
                    bitmap.SetSource(memoryStream);
                    image.Source = bitmap;

                    // Create a text block to display the caption
                    TextBlock captionBlock = new TextBlock();                    
                    captionBlock.Margin = new Thickness(0, 8, 0, 0);

                    Binding visibilityBinding = new Binding()
                    {
                        Source = attachment,
                        Path = new PropertyPath("TextNote"),
                        Converter = App.Current.Resources["NullToCollapsedConverter"] as IValueConverter
                    };

                    captionBlock.SetBinding(TextBlock.VisibilityProperty, visibilityBinding);
                    captionBlock.SetBinding(TextBlock.TextProperty, textNoteBinding);

                    // Place the image and its caption in a stack panel
                    StackPanel panel = new StackPanel();
                    panel.Children.Add(image);
                    panel.Children.Add(captionBlock);

                    attachmentElement = panel;

                    break;

                case Utils.AttachmentTypeIDVoice:
                    TextBlock voiceCaption = new TextBlock();

                    voiceCaption.SetBinding(TextBlock.TextProperty, textNoteBinding);

                    attachmentElement = voiceCaption;
                    break;

                default:
                    break;
            }

            return attachmentElement;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }

        #endregion
    }
}
