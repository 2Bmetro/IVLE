﻿// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Scheduler;
using Todo.Resources;
using System.Reflection;
using System.Windows.Navigation;
using System.IO.IsolatedStorage;

namespace Todo
{
    // DEMOSTOP#5 
    public static class RemindersHelpers 
    {
        
    }

    public static class EnumHelpers
    {
        /// <summary>
        /// Gets a localized string representing an enumeration value.
        /// </summary>
        /// <typeparam name="T">The enumerated type to work on.</typeparam>
        /// <param name="enumValue">An enumeration value for which to get the string.</param>
        /// <param name="prefix">Prefix used for the localized resource names which describe the enumerable 
        /// type.</param>
        /// <returns>A localized string describing the enumeration value.</returns>
        public static string GetLocalizedName<T>(this T enumValue, string prefix) where T : struct
        {
            if (!typeof(T).IsEnum)
            {
                throw new ArgumentException("T must be an enumeration", "T");
            }

            PropertyInfo enumValueStringProperty = typeof(ApplicationStrings).GetProperty(
                String.Format("{0}_{1}", prefix, Enum.GetName(typeof(T), enumValue)));

            if (enumValueStringProperty == null)
            {
                throw new Exception("Cannot find a localized string for the supplied enumeration information.");
            }

            return enumValueStringProperty.GetValue(null, null) as string;
        } 
    }


    public static class Extensions
    {
        public static Color ToColor(this string color)
        {
            string hexColor = color.Replace("#", "");
            System.Diagnostics.Debug.Assert (hexColor.Length == 8);
            Color retval = new Color()
            {
                A = Convert.ToByte(hexColor.Substring(0, 2), 16),
                R = Convert.ToByte(hexColor.Substring(2, 2), 16),
                G = Convert.ToByte(hexColor.Substring(4, 2), 16),
                B = Convert.ToByte(hexColor.Substring(6, 2), 16)
            };
            return retval; 
        }

        public static string SafeGetQueryParam(this NavigationContext context, string paramKey )
        {
            if (context.QueryString != null & context.QueryString.Keys.Contains(paramKey))
            {
                return context.QueryString[paramKey];
            }
            return string.Empty; 
        }

        public static Guid GetGuidParam(this NavigationContext context, string paramKey)
        {
            if (context.QueryString != null & context.QueryString.Keys.Contains(paramKey))
            {
                return new Guid ( context.QueryString[paramKey]); 
            }
            return Guid.Empty; 
        } 

        public static void Set ( this IsolatedStorageSettings settings, string key, object value )
        {
            if (settings.Contains(key))
                settings.Set(key, value);
            else
                settings.Add(key, value); 
        } 
        
    } 
}
