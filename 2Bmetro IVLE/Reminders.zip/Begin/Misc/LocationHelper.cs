﻿// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Device.Location;

namespace Todo
{
    public class LocationService
    {
        public event EventHandler LocationUpdated;

        
        private static LocationService _instance;         
        private GeoCoordinate _lastLocation = new GeoCoordinate(0, 0);
        private DateTime _lastLocationPublishedDateTime = DateTime.MinValue;
        private const double DefaultMovementThresholdInMeters = 300; 
        private static GeoCoordinateWatcher _geoWatcher; 
         
        private LocationService()
        {
            
        }

        public static LocationService Current
        {
            get { return _instance ?? (_instance = new LocationService()); }
        }

        public GeoCoordinate Location
        {
            get
            {                 
                return _lastLocation;
            }
            set
            {
                _lastLocation = value;                 
                if (HasLocation)
                {                     
                   if (LocationUpdated != null)
                       LocationUpdated(this, EventArgs.Empty);                  
                }
            }
        }

        public GeoPositionStatus Status { get; set; }

        public bool HasLocation
        {
            get
            {                
                return _lastLocation.Latitude != 0.0 && !double.IsNaN(_lastLocation.Latitude);
            }
        }

        public bool SensorsEnabled
        {
            get { return _geoWatcher.Permission == GeoPositionPermission.Granted; }
        }

        public void StartService( bool useTimer = false , double milliseconds = 3000 )
        {
            if (_geoWatcher == null)
            {
                _geoWatcher = new GeoCoordinateWatcher { MovementThreshold = DefaultMovementThresholdInMeters };                
                _geoWatcher.StatusChanged += _geoWatcher_StatusChanged;
                _geoWatcher.PositionChanged += _geoWatcher_PositionChanged;
            }
            _geoWatcher.Start();             
        }

        public void StopService()
        {
            if (_geoWatcher != null)
                _geoWatcher.Stop(); 
        } 
     

        private void _geoWatcher_StatusChanged(object sender, GeoPositionStatusChangedEventArgs e)
        {
            Status = e.Status;
        }

        private void _geoWatcher_PositionChanged(object sender, GeoPositionChangedEventArgs<GeoCoordinate> e)
        {
            if (_geoWatcher.Status == GeoPositionStatus.Ready)
            {
                Location = e.Position.Location;
            }
        }
  

        

        private void RootFrameUnobscured(object sender, EventArgs e)
        {
             
        }         
    }
}
