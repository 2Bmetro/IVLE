﻿// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.IO;

namespace FileUploaderWcfRestService
{
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerCall)]
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public class UploaderService : IUploaderService
    {
        #region IUploaderService Members

        public bool UploadFile(string fileName, System.IO.Stream fileContents)
        {
            var filepath = HttpContext.Current.Server.MapPath(@"~\Backups\" + fileName);

            if (!Directory.Exists(Path.GetDirectoryName(filepath)))
            {
                Directory.CreateDirectory(Path.GetDirectoryName(filepath));
            }

            using (Stream file = File.OpenWrite(filepath))
            {
                CopyStream(fileContents, file);
            }
            return true;
        }

        #endregion

        private static void CopyStream(Stream input, Stream output) 
        { 
            var buffer = new byte[8 * 1024]; 
            int len; 
            
            while ((len = input.Read(buffer, 0, buffer.Length)) > 0) 
            { 
                output.Write(buffer, 0, len); 
            } 
        }
    }
}