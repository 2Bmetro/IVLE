﻿// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using System.Linq;
using Todo.Interfaces;
using Todo.Misc;

namespace Todo.ViewModels
{
    public class ProjectsViewModel : ViewModelItemsBase<Project>, IEditableViewModel<Project>
    {
        public ProjectsViewModel(DataContextBase todoDC)
            : base(todoDC)
        {

        }

        /// <summary>
        /// Creates and adds a few ItemViewModel objects into the Task collection.
        /// </summary>
        public override void LoadData()
        {
            var projects = (from c in todoDC.Projects
                            select c);

            foreach (var project in projects)
            {
                Items.Add(project);
                project.InitializeItemNotifications();
            }

            this.IsDataLoaded = true;
            NotifyPropertyChanged("Items");
        }

        #region IEditableViewModel Members

        public void DropTableData()
        {
            var projects = (from project in todoDC.Projects
                            where project.Id != new Guid(Utils.ProjectIDDefault)
                            select project);

            todoDC.Projects.DeleteAllOnSubmit(projects);
            todoDC.SubmitChanges();

            DropData();
        }

        public Project Create()
        {
            Project project = new Project();
            return project;
        }

        public void Insert(Project project)
        {
            Items.Add(project);

            todoDC.Projects.InsertOnSubmit(project);
            todoDC.SubmitChanges();
            NotifyPropertyChanged("Items");
        }

        public void Update(Project project)
        {
            todoDC.SubmitChanges();
            NotifyPropertyChanged("Items");
        }

        public void Delete(Guid projectID)
        {
            var res = from p in Items
                      where p.Id == projectID
                      select p;

            Project proj = res.FirstOrDefault();

            if (null != proj)
            {
                //First delete all existing project items
                var items = from i in App.TasksViewModel.Items
                            where i.ProjectID == proj.Id
                            select i;

                foreach (Task item in items)
                    App.TasksViewModel.Delete(item.Id);

                Items.Remove(proj);

                todoDC.Projects.DeleteOnSubmit(proj);

                todoDC.SubmitChanges();
                NotifyPropertyChanged("Items");
            }
        }
        #endregion
    }
}