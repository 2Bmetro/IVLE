﻿// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Todo.Resources;
using Microsoft.Phone.Scheduler;

namespace Todo.ViewModels
{
    public class TaskEditViewModel : ViewModelBase 
    {
        private bool isReminderSettingEnabled = false ; 
        private Task task; 
        private bool isNew ;
        private string reminderContent;
        DateTime? reminderDate;
        DateTime? reminderTime; 

        public TaskEditViewModel() : this ( Guid.Empty) 
        {

        } 

        public TaskEditViewModel ( Guid id ) 
        {
            if (id != Guid.Empty)
            {
                task = App.TasksViewModel.Find(id);
                System.Diagnostics.Debug.Assert(task != null);
                isNew = false;

                InitializeReminder(); 
            }
            if ( task == null )              
            {
                task = new Task();
                isNew = true; 
            } 
        } 

        public bool HasSystemReminder
        {
            get
            {
                // Replace this code
                return false;
            } 
        }

        public bool IsReminderSettingEnabled 
        {
            get
            {
                return isReminderSettingEnabled; 
            } 
            set 
            {
                // Add code here
            } 
        }

        public DateTime? ReminderDate
        {
            get
            {
                if (HasSystemReminder && !reminderDate.HasValue)
                    InitializeReminder(); 

                return reminderDate; 
            } 
            set 
            {
                reminderDate = value;
                OnPropertyChanged("ReminderDate");
                CheckAndSaveReminder(); 
            } 
        }

        public DateTime? ReminderTime
        {
            get
            {
                if (HasSystemReminder && !reminderTime.HasValue)
                    InitializeReminder(); 

                return reminderTime; 
            }
            set
            {
                reminderTime = value;
                OnPropertyChanged("ReminderTime");
                CheckAndSaveReminder(); 
            }
        }

        Reminder reminder;
        bool notSearchedForReminder = true;  
        void InitializeReminder()
        {
            // Add code here
        } 

        public string ReminderContent
        {
            get
            {
                if (HasSystemReminder && string.IsNullOrEmpty(reminderContent))
                    InitializeReminder();  
                return reminderContent; 
            }
            set
            {
                if (reminderContent != value)
                {
                    reminderContent = value;
                    OnPropertyChanged("ReminderContent");
                    CheckAndSaveReminder(); 
                } 
            } 
        } 

        void CheckAndSaveReminder()
        {
            // Add code here
        } 

        public bool HasValidReminder
        {
            get
            {
                return (ReminderTime.HasValue
                        && ReminderDate.HasValue &&
                    !string.IsNullOrEmpty(ReminderContent)); 
            } 
        } 

        public Task Task
        {
            get
            {
                return task; 
            }
        }

        public bool IsNew
        {
            get
            {
                return isNew; 
            }
        }

        private bool hasAttachments = false ; 
        public bool HasAttachments
        {
            get
            {
                return hasAttachments; 
            }
        }

        public Visibility NeedsAttachmentsVisibility
        {
            get
            {
                if (hasAttachments)
                    return Visibility.Collapsed;
                else
                    return Visibility.Visible; 
            }
        } 
        public void Delete()
        {
            App.TasksViewModel.Delete(task.Id);
        } 
    }
}
