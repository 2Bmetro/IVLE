﻿// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Linq;
using Todo.Resources;
using System.IO.IsolatedStorage;
using System.Runtime.Serialization;
using System.Collections.Generic; 


namespace Todo.ViewModels
{
    public class LocationEditViewModel  : ViewModelBase 
    {
        public LocationEditViewModel()
        {
            isNew = true ;  
        } 
        public LocationEditViewModel( string id )
        {
            if (string.IsNullOrEmpty(id))
            {
                isNew = true ;
                location = new Location(); 
            }
            else
            {
                isNew = false;
                Guid guid = new Guid(id);
                location = App.LocationsViewModel.Find(guid);                 
            } 
        }

        public Location Location
        {
            get
            {
                System.Diagnostics.Debug.Assert(location != null); 
                return location; 
            }
        }

        public bool IsNew 
        {
            get
            {
                return isNew; 
            } 
        }

        public bool Validate()
        {
                if  ( string.IsNullOrEmpty ( location.Name )) 
                { 
                    MessageBox.Show (ApplicationStrings.ValidateLocationName); 
                    return false; 
                } 
                if ( location.Latitude == 0.0 || location.Longitude == 0.0) 
                {
                    MessageBox.Show (ApplicationStrings.ValidateLocationLatLong ) ; 
                    return false; 
                } 

                //TODO: Check for duplicates 

            return true ; 
        } 

        public void Save ( ) 
        { 
            if ( isNew ) 
                App.LocationsViewModel.Insert ( location ); 
            else 
                App.LocationsViewModel.Update ( location ) ;

                System.Threading.ThreadPool.QueueUserWorkItem(SaveAsXML  ); 
        }


        void SaveAsXML( object state )
        {
            using (System.IO.IsolatedStorage.IsolatedStorageFile iso = System.IO.IsolatedStorage.IsolatedStorageFile.GetUserStoreForApplication())
            {
                using (IsolatedStorageFileStream stream = iso.OpenFile( Constants.LOCATIONSXMLPATH, System.IO.FileMode.OpenOrCreate))
                {
                    DataContractSerializer serializer = new DataContractSerializer(typeof(List<Location>));
                    serializer.WriteObject(stream, App.LocationsViewModel.Items.ToList<Location>()); 
                } 
            }
        } 
        private Location location;
        private bool isNew = false; 
    }
}
