﻿// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Todo.Models;
using System.ComponentModel;
using Todo.Misc;
using Todo.Resources;
using Microsoft.Phone.Scheduler;
using System.IO.IsolatedStorage;
using System.Runtime.Serialization;
using System.Diagnostics;

namespace Todo.ViewModels
{
    /// <summary>
    /// Allows the UI to interact with the settings model.
    /// </summary>
    public class SettingsViewModel : ViewModelBase
    {
        private LocalhostSync syncProvider;

        private bool syncInProgress;

        /// <summary>
        /// Whether a sync operation is currently in progress or not.
        /// </summary>
        public bool SyncInProgress
        {
            get
            {
                return syncInProgress;
            }
            set
            {
                if (value != syncInProgress)
                {
                    syncInProgress = value;
                    OnPropertyChanged("SyncInProgress");
                }
            }
        }

        private long syncTotal;

        /// <summary>
        /// The total size of the current sync operation. This is meaningless if an operation
        /// is not currently in progress.
        /// </summary>
        public long SyncTotal
        {
            get
            {
                return syncTotal;
            }
            set
            {
                if (value != syncTotal)
                {
                    syncTotal = value;
                    OnPropertyChanged("SyncTotal");
                }
            }
        }

        private long syncProgress;

        /// <summary>
        /// The current progress of the current sync operation. This is meaningless if an operation
        /// is not currently in progress.
        /// </summary>
        public long SyncProgress
        {
            get
            {
                return syncProgress;
            }
            set
            {
                if (value != syncProgress)
                {
                    syncProgress = value;
                    OnPropertyChanged("SyncProgress");
                }
            }
        }

        /// <summary>
        /// Creates a new instance of the class.
        /// </summary>
        public SettingsViewModel()
        {
            syncProvider = new LocalhostSync();

            syncProvider.DownloadFinished += DownloadFinished;
            syncProvider.UploadFinished += UploadFinished;
            syncProvider.DownloadUploadProgress += OperationProgress;


            periodicTask = ScheduledActionService.Find(PeriodicTaskName) as PeriodicTask;

            //I believe in Beta the IsEnabled flag is not working. 

            if (periodicTask != null)
                IsBackgroundProcessingAllowed = periodicTask.IsEnabled;
            else
                IsBackgroundProcessingAllowed = true; ;

            LoadSettings();


        }

        private void OperationProgress(object sender, DownloadUploadProgressEventArgs e)
        {
            SyncTotal = e.Total;
            SyncProgress = e.Progress;
        }

        private void UploadFinished(object sender, DownloadUploadFinishedEventArgs e)
        {
            SyncInProgress = false;
        }

        private void DownloadFinished(object sender, DownloadUploadFinishedEventArgs e)
        {
            MessageBox.Show(ApplicationStrings.Msg_RestoreWarning);
            SyncInProgress = false;
        }

        /// <summary>
        /// Uploads the application's database to the synchronization service.
        /// </summary>
        public void UploadDatabase()
        {
            SyncProgress = 0;
            SyncInProgress = true;

            syncProvider.Upload("x", "x", "x");
        }

        /// <summary>
        /// Downloads the application's database from the synchronization service.
        /// </summary>
        public void DownloadDatabase()
        {
            SyncProgress = 0;
            SyncInProgress = true;

            syncProvider.Download("x", "x", "x");
        }

        public bool HideCompletedOnStartup
        {
            get
            {
                return hideCompletedOnStartup;
            }
            set
            {
                if (hideCompletedOnStartup != value)
                {
                    hideCompletedOnStartup = value;
                    OnPropertyChanged("HideCompletedOnStartup");
                }
            }
        }

        public bool HideCompletedOnRefresh
        {
            get
            {
                return hideCompletedOnRefresh;
            }
            set
            {
                if (hideCompletedOnRefresh != value)
                {
                    hideCompletedOnRefresh = value;
                    OnPropertyChanged("HideCompletedOnRefresh");
                }
            }
        }

        public bool UseBackgroundTaskUpdates
        {
            get
            {
                return useBackgroundTaskUpdates;
            }
            set
            {
                if (useBackgroundTaskUpdates != value)
                {
                    useBackgroundTaskUpdates = value;
                    OnPropertyChanged("UseBackgroundTaskUpdates");
                }
            }
        }



        public bool UseBackgroundLocation
        {
            get
            {
                return useBackgroundLocation;
            }
            set
            {
                if (useBackgroundLocation != value)
                {
                    useBackgroundLocation = value;
                    OnPropertyChanged("UseBackgroundLocation");
                }
            }
        }


        public bool BackupDatabaseNightly
        {
            get
            {
                return backupDatabaseNightly;
            }
            set
            {
                if (backupDatabaseNightly != value)
                {
                    backupDatabaseNightly = value;
                    OnPropertyChanged("BackupDatabaseNightly");
                }
            }
        }

        public bool IsBackgroundProcessingAllowed
        {
            get
            {
                return isBackgroundProcessingAllowed;
            }
            private set
            {
                if (isBackgroundProcessingAllowed != value)
                {
                    isBackgroundProcessingAllowed = value;
                    OnPropertyChanged("IsBackgroundProcessingAllowed");
                }
            }
        }

        public ICommand Save
        {
            get
            {
                if (saveCommand == null)
                    saveCommand = new DelegateCommand(OnSave);
                return saveCommand;
            }
        }

        void OnSave(object param)
        {
            if (UseBackgroundTaskUpdates || UseBackgroundLocation)
            {
                EnableTask(PeriodicTaskName, ApplicationStrings.PeriodicTaskDescription);
            }
            else
                DisableTask(PeriodicTaskName);

            SaveSettings();
        }

        void LoadSettings()
        {
            //IsolatedStorageSettings.ApplicationSettings.TryGetValue<bool>(UIConstants.UseBackgroundLocation, out useBackgroundLocation);
            //UseBackgroundLocation = useBackgroundLocation;
            //IsolatedStorageSettings.ApplicationSettings.TryGetValue<bool>(UIConstants.UseBackgroundTaskUpdater, out useBackgroundTaskUpdates);
            //UseBackgroundTaskUpdates = useBackgroundTaskUpdates;
            //IsolatedStorageSettings.ApplicationSettings.TryGetValue<bool>(UIConstants.HideCompletedOnRefresh, out hideCompletedOnRefresh);
            //HideCompletedOnRefresh = hideCompletedOnRefresh;
            //IsolatedStorageSettings.ApplicationSettings.TryGetValue<bool>(UIConstants.HideCompletedOnStartup, out hideCompletedOnStartup);
            //HideCompletedOnStartup = hideCompletedOnStartup; 

            SettingsWorkaround wa = SettingsWorkaround.Load();
            if (wa != null)
            {
                this.UseBackgroundTaskUpdates = wa.UseTileUpdater;
                this.UseBackgroundLocation = wa.UseLocation;
                this.HideCompletedOnStartup = wa.HideOnStartup;
                this.HideCompletedOnRefresh = wa.HideOnRefresh;
                this.BackupDatabaseNightly = wa.BackupNightly;
            }
        }

        void SaveSettings()
        {
            //IsolatedStorageSettings.ApplicationSettings.Set(UIConstants.UseBackgroundLocation, this.UseBackgroundLocation);
            //IsolatedStorageSettings.ApplicationSettings.Set(UIConstants.UseBackgroundTaskUpdater, this.useBackgroundTaskUpdates);
            //IsolatedStorageSettings.ApplicationSettings.Set(UIConstants.HideCompletedOnRefresh, this.HideCompletedOnRefresh);
            //IsolatedStorageSettings.ApplicationSettings.Set(UIConstants.HideCompletedOnStartup, this.hideCompletedOnStartup);
            //IsolatedStorageSettings.ApplicationSettings.Save(); 

            SettingsWorkaround wa = new SettingsWorkaround
            {
                UseLocation = this.UseBackgroundLocation,
                UseTileUpdater = this.UseBackgroundTaskUpdates,
                HideOnRefresh = this.HideCompletedOnRefresh,
                HideOnStartup = this.HideCompletedOnStartup,
                BackupNightly = this.BackupDatabaseNightly
            };
            wa.Save();

        }


        public ICommand Backup
        {
            get
            {
                if (backupCommand == null)
                    backupCommand = new DelegateCommand(OnBackup);
                return backupCommand;
            }
        }

        void OnBackup(object param)
        {
            UploadDatabase();
        }

        public ICommand Restore
        {
            get
            {
                if (restoreCommand == null)
                    restoreCommand = new DelegateCommand(Onrestore);
                return restoreCommand;
            }
        }

        void Onrestore(object param)
        {
            DownloadDatabase();
        }


        PeriodicTask periodicTask = null;
        const string PeriodicTaskName = "TidyPeriodic";
        //DEMOSTOP#8
        void EnableTask(string taskName, string description)
        {
            PeriodicTask t = this.periodicTask;
            bool found = (t != null);
            if (!found)
            {
                t = new PeriodicTask(taskName);
            }

            t.Description = description;
            t.ExpirationTime = DateTime.Now.AddDays(10);

            if (!found)
            {
                ScheduledActionService.Add(t);
            }
            else
            {
                ScheduledActionService.Remove(taskName);
                ScheduledActionService.Add(t);
            }

            if (Debugger.IsAttached)
            {
                ScheduledActionService.LaunchForTest(t.Name, TimeSpan.FromSeconds(5));
            }
        }

        void DisableTask(string taskName)
        {
            try
            {
                PeriodicTask t;
                if (periodicTask != null && periodicTask.Name != taskName)
                    t = periodicTask;
                else
                    t = periodicTask = ScheduledActionService.Find(taskName) as PeriodicTask;

                if (t != null)
                    ScheduledActionService.Remove(t.Name);
            }
            finally { };
        }


        private bool hideCompletedOnStartup;
        private bool hideCompletedOnRefresh;
        private bool useBackgroundTaskUpdates;
        private bool useBackgroundLocation;
        private bool backupDatabaseNightly;
        private bool isBackgroundProcessingAllowed;

        DelegateCommand saveCommand;
        DelegateCommand backupCommand;
        DelegateCommand restoreCommand;
    }
}
