﻿// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Todo.Interfaces;
using System.Linq;
using Microsoft.Phone.Controls;
using System.Collections.ObjectModel; 


namespace Todo.ViewModels
{
    public class LocationsViewModel : ViewModelItemsBase<Location>, IEditableViewModel<Location>
    {

        public LocationsViewModel(DataContextBase todoDC)
            : base(todoDC)
        {

        }


        public override void LoadData()
        {
            var locations = (from c in todoDC.Locations
                            select c);

            foreach (var location in locations)
            {
                Items.Add(location);
            //    project.InitializeItemNotifications();
            }

            this.IsDataLoaded = true;
            NotifyPropertyChanged("Items");
        }

        #region IEditableViewModel Members

        public void DropTableData()
        {
             
        }

        public Location Create()
        {
            return new Location();              
        }

        public void Insert(Location newLocation)
        {
            Items.Add(newLocation);

            todoDC.Locations.InsertOnSubmit(newLocation);
            todoDC.SubmitChanges();
            NotifyPropertyChanged("Items");
        }

        public void Update(Location location)
        {
            todoDC.SubmitChanges();
         //   NotifyPropertyChanged("Items");
        }

        public void Delete(Guid locationId)
        {
            var res = from l in Items
                      where l.Id == locationId 
                      select l;

            Location location = res.FirstOrDefault();

           
            if (null != location)
            {
                //First delete all existing project items
                //var items = from i in App.TasksViewModel.Items
                //            where i.Id == proj.Id
                //            select i;

                //foreach (Task item in items)
                //    App.TasksViewModel.Delete(item.Id);

                Items.Remove(location);

                todoDC.Locations.DeleteOnSubmit(location);

                todoDC.SubmitChanges();
                NotifyPropertyChanged("Items");
            } 
        }
        #endregion

        DelegateCommand editLocationCommand; 
        public ICommand EditLocationCommand
        {
            get
            {
                if (editLocationCommand == null)
                {
                    editLocationCommand = new DelegateCommand(OnEditCommand); 
                }
                return editLocationCommand; 
            }
        }

        private void OnEditCommand(object param)
        {
            Location location = param as Location;
            System.Diagnostics.Debug.Assert(location != null); 
            ((PhoneApplicationFrame)Application.Current.RootVisual).Navigate(
                UIConstants.MakeLocationEditViewUri ( location ) );                  
        }


        DelegateCommand deleteLocationCommand;
        public ICommand DeleteLocationCommand
        {
            get
            {
                if (deleteLocationCommand == null)
                {
                    deleteLocationCommand = new DelegateCommand(OnDeleteCommand);
                }
                return deleteLocationCommand;
            }
        }

        private void OnDeleteCommand(object param)
        {
            Location location = param as Location;
            System.Diagnostics.Debug.Assert(location != null);

            this.Delete(location.Id);  
        }           
    }
}
