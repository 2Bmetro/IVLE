﻿// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using System.Linq;
using Todo.Interfaces;
using Todo.Misc;

namespace Todo.ViewModels
{
    public class AttachmentViewModel : ViewModelItemsBase<Attachment>, IEditableViewModel<Attachment>
    {
        public AttachmentViewModel(DataContextBase todoDC)
            : base(todoDC)
        {

        }

        /// <summary>
        /// Creates and adds a few ItemViewModel objects into the Task collection.
        /// </summary>
        public override void LoadData()
        {
            var attachments = (from a in todoDC.Attachment
                              select a);

            foreach (var attachment in attachments)
                Items.Add(attachment);

            IsDataLoaded = true;
            NotifyPropertyChanged("Items");
        }

        #region IEditableViewModel Members

        public void DropTableData()
        {
            var attachments = (from a in todoDC.Attachment
                               select a);

            todoDC.Attachment.DeleteAllOnSubmit(attachments);
            todoDC.SubmitChanges();

            DropData();
        }

        public Attachment Create()
        {
            Attachment attachment = new Attachment();
            //attachment.Id = new Guid(Utils.AttachmentTypeText);
            return attachment;
        }

        public void Insert(Attachment attachment)
        {
            Items.Add(attachment);

            todoDC.Attachment.InsertOnSubmit(attachment);
            todoDC.SubmitChanges();
            NotifyPropertyChanged("Items");
        }

        public void Update(Attachment attachment)
        {
            todoDC.SubmitChanges();
            NotifyPropertyChanged("Items");
        }

        public void Delete(Guid attachmentID)
        {
            var res = from a in Items
                      where a.Id == attachmentID
                      select a;

            Attachment att = res.FirstOrDefault();

            if (null != att)
            {
                Items.Remove(att);

                todoDC.Attachment.DeleteOnSubmit(att);

                todoDC.SubmitChanges();
                NotifyPropertyChanged("Items");
            }
        }

        public void DeleteByTaskID(Guid taskID)
        {
            var res = from a in Items
                      where a.ItemID == taskID
                      select a;

            List<Attachment> removedAttachments = res.ToList();
            foreach (Attachment att in removedAttachments)
                Items.Remove(att);

            todoDC.Attachment.DeleteAllOnSubmit(removedAttachments);
            todoDC.SubmitChanges(); 
            NotifyPropertyChanged("Items");
        }
        #endregion
    }
}