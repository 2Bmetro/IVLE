﻿// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using System.Linq;
using Todo.Interfaces;
using Todo.Misc;

namespace Todo.ViewModels
{
    public class TasksViewModel : ViewModelItemsBase<Task>, IEditableViewModel<Task>
    {
        public TasksViewModel(DataContextBase todoDC)
            : base(todoDC)
        {
            if (!DesignerProperties.IsInDesignTool)
            {
                System.Diagnostics.Debug.Assert(todoDC != null);
            }
        }

        /// <summary>
        /// Gets all items which are due today, sorted by priority.
        /// </summary>
        public IOrderedEnumerable<Task> Today
        {
            get
            {
                return from task in App.TasksViewModel.Items
                       where task.DueDate.HasValue && task.DueDate.Value.Date == DateTime.Now.Date
                       orderby task.Priority
                       select task;
            }
        }


        //DEMOSTOP#4 
        /// <summary>
        /// Gets all high priority items, sorted by due date.
        /// </summary>
        public IOrderedEnumerable<Task> Urgent
        {
            get
            {
                return from task in App.TasksViewModel.Items
                       where task.Priority == PriorityValue.High
                       orderby task.DueDate.MaxOnNull()
                       select task;
            }
        }

        /// <summary>
        /// Gets all items which are completed, sorted by due date.
        /// </summary>
        public IOrderedEnumerable<Task> Completed
        {
            get
            {
                return from task in App.TasksViewModel.Items
                       where task.Status == TaskStatus.Completed
                       orderby task.DueDate.MaxOnNull()
                       select task;
            }
        }

        Location _nearbyLocation ; 
        public Location NearbyLocation
        {
            get
            {
                return _nearbyLocation; 
            }
            set
            {
                if (_nearbyLocation != value)
                {
                    _nearbyLocation = value;
                    NotifyPropertyChanged("NearbyLocation");
                    NotifyPropertyChanged("Nearby"); 
                } 
            }
        } 
        public IOrderedEnumerable<Task> Nearby 
        {
            get
            {
                if ( NearbyLocation != null)
                {
                    return from task in App.TasksViewModel.Items
                           where task.LocationID == NearbyLocation.Id
                           orderby task.DueDate.MaxOnNull()
                           select task;
                }
                return null; 
            }
        }

        /// <summary>
        /// Gets all items, sorted by due date.
        /// </summary>
        public IOrderedEnumerable<Task> ByDate
        {
            get
            {
                return from task in App.TasksViewModel.Items
                       orderby task.DueDate.MaxOnNull()
                       select task;
            }
        }        

        /// <summary>
        /// Creates and adds a few ItemViewModel objects into the Task collection.
        /// </summary>
        public override void LoadData()
        {
            PropertyChanged += new PropertyChangedEventHandler(TasksViewModel_PropertyChanged);

            var tasks = from t in todoDC.Items select t;

            foreach (var task in tasks)
            {
                Items.Add(task);
                task.PropertyChanged += task_PropertyChanged;
            }

            // Only register this now, so that we do not fire updates for each and every item loaded
            Items.CollectionChanged += Items_CollectionChanged;

            IsDataLoaded = true;

            NotifyCollectionChanges();
        }

        private void TasksViewModel_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == "Items")
            {
                NotifyCollectionChanges();
            }
        }

        private void NotifyCollectionChanges()
        {
            NotifyPropertyChanged("Today");
            NotifyPropertyChanged("Urgent");
            NotifyPropertyChanged("Completed");
            NotifyPropertyChanged("ByDate");            
        }

        private void Items_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            if (e.Action == System.Collections.Specialized.NotifyCollectionChangedAction.Add)
            {
                foreach (Task task in e.NewItems)
                {
                    task.PropertyChanged += task_PropertyChanged;
                }
            }
            else if (e.Action == System.Collections.Specialized.NotifyCollectionChangedAction.Remove)
            {
                foreach (Task task in e.OldItems)
                {
                    task.PropertyChanged -= task_PropertyChanged;
                }
            }

            NotifyCollectionChanges();
        }

        private void task_PropertyChanged(object sender, PropertyChangedEventArgs args)
        {
            if (args.PropertyName == "Completed")
            {
                NotifyPropertyChanged("Completed");
            }
            if (args.PropertyName == "DueDate")
            {
                // All views are sorted by due date, and "Today" is filtered by due date
                NotifyPropertyChanged("Today");
                NotifyPropertyChanged("Completed");
                NotifyPropertyChanged("Urgent");
                NotifyPropertyChanged("ByDate");
            }
            if (args.PropertyName == "Priority")
            {
                NotifyPropertyChanged("Urgent");
                NotifyPropertyChanged("Today");
            }
        }

        #region IEditableViewModel Members

        public void DropTableData()
        {
            var tasks = (from t in todoDC.Items
                         select t);

            todoDC.Items.DeleteAllOnSubmit(tasks);
            todoDC.SubmitChanges();

            DropData();
        }

        public Task Create()
        {
            Task item = new Task();            
            item.ProjectID = new Guid(Utils.ProjectIDDefault);
            return item;
        }

        public void Insert(Task item)
        {
            Items.Add(item);

            todoDC.Items.InsertOnSubmit(item);
            todoDC.SubmitChanges();

        }

        public void Update(Task item)
        {
            todoDC.SubmitChanges();
        }

        public void Delete(Guid itemID)
        {
            App.AttachmentViewModel.DeleteByTaskID(itemID);

            var res = from i in Items
                      where i.Id == itemID
                      select i;

            Task itm = res.FirstOrDefault();

            if (null != itm)
            {
                Items.Remove(itm);

                todoDC.Items.DeleteOnSubmit(itm);

                todoDC.SubmitChanges();
            }
        }        

        #endregion
    }


}