﻿// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Todo.Interfaces;
using Microsoft.Phone.BackgroundTransfer;
using System.IO.IsolatedStorage;
using Todo.Resources;

namespace Todo.Misc
{
    //DEMOSTOP#3 
    public class LocalhostSync : ISyncProvider
    {
        //REQUIRES THE SERVER TO DEFINE A MIME TYPE: ".sdf" as "application/octet-stream"!
        const string serviceUploadLocationURL = "http://localhost/FileUploaderWcfRestService/UploaderService/File/";
        const string downloadLocationURL = "http://localhost/FileUploaderWcfRestService/Backups/";
        const string TransfersFiles = @"shared\transfers"; //Default download location
        const string downloadedDBName = "ToDo_NEW.sdf";
        const string localDBName = "ToDo.sdf";

        #region ISyncProvider Members
        public string Name
        {
            get { return LocalizedStrings.LocalhostSyncName; }
        }

        public void Upload(string username, string password, string filename)
        {
            using (System.IO.IsolatedStorage.IsolatedStorageFile iso = System.IO.IsolatedStorage.IsolatedStorageFile.GetUserStoreForApplication())
            {
                if (!iso.FileExists(localDBName))
                    return;

                iso.CopyFile(localDBName, "/" + TransfersFiles + "/" + localDBName, true);
            }

            BackgroundTransferRequest btr = new BackgroundTransferRequest(new Uri(serviceUploadLocationURL + localDBName, UriKind.Absolute));
            btr.TransferPreferences = TransferPreferences.AllowBattery;
            btr.Method = "POST";
            btr.UploadLocation = new Uri("/" + TransfersFiles + "/" + localDBName, UriKind.Relative);
            btr.TransferStatusChanged += new EventHandler<BackgroundTransferEventArgs>(btr_UploadTransferStatusChanged);
            btr.TransferProgressChanged += new EventHandler<BackgroundTransferEventArgs>(btr_TransferProgressChanged);
            Microsoft.Phone.BackgroundTransfer.BackgroundTransferService.Add(btr);
        }

        void btr_TransferProgressChanged(object sender, BackgroundTransferEventArgs e)
        {
            bool isUploading = e.Request.TotalBytesToSend > 0 ? true : false;

            if (null != DownloadUploadProgress)
                DownloadUploadProgress(this,
                    new DownloadUploadProgressEventArgs(isUploading,
                                                        isUploading ? e.Request.BytesSent : e.Request.BytesReceived,
                                                        isUploading ? e.Request.TotalBytesToSend : e.Request.TotalBytesToReceive));
        }

        void btr_UploadTransferStatusChanged(object sender, BackgroundTransferEventArgs e)
        {
            if (e.Request.TransferStatus == Microsoft.Phone.BackgroundTransfer.TransferStatus.Completed)
            {
                using (IsolatedStorageFile iso = IsolatedStorageFile.GetUserStoreForApplication())
                {
                    if (iso.FileExists(e.Request.UploadLocation.OriginalString))
                        iso.DeleteFile(e.Request.UploadLocation.OriginalString);
                }

                Microsoft.Phone.BackgroundTransfer.BackgroundTransferService.Remove(e.Request);

                if (null != e.Request.TransferError)
                {
                    //LOG error
                }
                else
                {
                    if (null != UploadFinished)
                        UploadFinished(this, new DownloadUploadFinishedEventArgs());
                }

            }
        }

        void btr_DownloadTransferStatusChanged(object sender, BackgroundTransferEventArgs e)
        {
            System.Diagnostics.Debug.WriteLine(e.Request.TransferStatus);

            if (e.Request.TransferStatus == Microsoft.Phone.BackgroundTransfer.TransferStatus.Completed)
            {
                Microsoft.Phone.BackgroundTransfer.BackgroundTransferService.Remove(e.Request);

                if (null != e.Request.TransferError)
                {
                    //LOG error
                }
                else
                {
                    //Overwrite the DB
                    using (IsolatedStorageFile iso = IsolatedStorageFile.GetUserStoreForApplication())
                    {
                        iso.CopyFile("/" + TransfersFiles + "/" + downloadedDBName, "/" + localDBName, true);
                        iso.DeleteFile("/" + TransfersFiles + "/" + downloadedDBName);

                        if (null != DownloadFinished)
                            DownloadFinished(this, new DownloadUploadFinishedEventArgs());
                    }
                }
            }
        }

        public void Download(string username, string password, string filename)
        {
            BackgroundTransferRequest btr = new BackgroundTransferRequest(
                new Uri(downloadLocationURL + localDBName, UriKind.Absolute),
                new Uri(TransfersFiles + @"\" + downloadedDBName, UriKind.Relative));
            btr.TransferPreferences = TransferPreferences.AllowBattery;
            btr.TransferStatusChanged += new EventHandler<BackgroundTransferEventArgs>(btr_DownloadTransferStatusChanged);
            btr.TransferProgressChanged += new EventHandler<BackgroundTransferEventArgs>(btr_TransferProgressChanged);
            BackgroundTransferService.Add(btr);
        }

        #endregion

        public delegate void DownloadFinishedEventHandler(object sender, DownloadUploadFinishedEventArgs e);
        public delegate void DownloadProgressEventHandler(object sender, DownloadUploadProgressEventArgs e);

        public event DownloadFinishedEventHandler DownloadFinished;
        public event DownloadFinishedEventHandler UploadFinished;
        public event DownloadProgressEventHandler DownloadUploadProgress;

    }
}
