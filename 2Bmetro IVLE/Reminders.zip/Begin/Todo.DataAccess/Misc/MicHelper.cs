﻿// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.IO;
using Microsoft.Xna.Framework.Audio;
using System.Windows.Threading;
using Todo.Misc;

namespace Todo
{
    public class MicHelper
    {
        private MemoryStream ms;
        private Microphone mic;
        private DispatcherTimer recordingTimer;

        private DateTime recordingStartTime;
        private DispatcherTimer playbackTimer;

        private SoundEffect se;
        private SoundEffectInstance sei;

        public event EventHandler PlaybackStopped;
        public event EventHandler RecordingStopped;

        public MicHelper()
        {
            //Setup mic
            mic = Microphone.Default;

            //Setup timers
            recordingTimer = new DispatcherTimer();
            recordingTimer.Interval = TimeSpan.FromSeconds(Utils.maxRecordingDuration);
            recordingTimer.Tick += new EventHandler(recordingTimer_Tick);

            playbackTimer = new DispatcherTimer();
            playbackTimer.Tick += new EventHandler(playbackTimer_Tick);
        }

        private void playbackTimer_Tick(object sender, EventArgs e)
        {
            playbackTimer.Stop();
            StopPlaying();
        }

        // When the buffer's ready we need to empty it        
        // We'll copy to a MemoryStream        
        // We could push into IsolatedStorage etc        
        void DefaultMic_BufferReady(object sender, EventArgs e)
        {
            byte[] buffer = new byte[1024];
            int bytesRead = 0;
            while ((bytesRead = mic.GetData(buffer, 0, buffer.Length)) > 0)
                ms.Write(buffer, 0, bytesRead);
        }

        public void StartRecording(TimeSpan duration)
        {
            if (duration.TotalSeconds > Utils.maxRecordingDuration)
                duration = TimeSpan.FromSeconds(Utils.maxRecordingDuration);

            //Setup timer
            recordingTimer.Interval = duration;
            recordingTimer.Start();

            if (null != ms)
                ms.Close();

            ms = new System.IO.MemoryStream();

            recordingStartTime = DateTime.Now;

            mic.BufferReady += DefaultMic_BufferReady;
            mic.Start();
        }

        void recordingTimer_Tick(object sender, EventArgs e)
        {
            recordingTimer.Stop();
            StopRecording();
        }

        public void StopRecording()
        {
            if (recordingTimer.IsEnabled)
                recordingTimer.Stop();

            if (mic.State != Microsoft.Xna.Framework.Audio.MicrophoneState.Stopped)
            {
                mic.Stop();
                mic.BufferReady -= DefaultMic_BufferReady;

                RecordingLength = DateTime.Now - recordingStartTime;                

                ms.Position = 0;

                Recording = ms;
                RecordingBytes = Recording.ToArray();

                if (RecordingStopped != null)
                {
                    RecordingStopped(this, null);
                }
            }
        }

        public void PlayRecording()
        {
            se = new SoundEffect(RecordingBytes, mic.SampleRate, AudioChannels.Mono);
            sei = se.CreateInstance();
            sei.Play();

            playbackTimer.Interval = RecordingLength;
            playbackTimer.Start();
        }

        public void PlayRecording(byte[] bytes, TimeSpan length)
        {
            se = new SoundEffect(bytes, mic.SampleRate, AudioChannels.Mono);
            sei = se.CreateInstance();
            sei.Play();

            playbackTimer.Interval = length;
            playbackTimer.Start();
        }

        public void StopPlaying()
        {
            if (playbackTimer.IsEnabled)
            {
                playbackTimer.Stop();
            }

            if (sei != null)
            {
                sei.Stop();
            }

            if (PlaybackStopped != null)
            {
                PlaybackStopped(this, null);
            }
        }

        public TimeSpan RecordingLength { get; private set; }

        public byte[] RecordingBytes
        {
            get;
            private set;
        }

        public System.IO.MemoryStream Recording
        {
            get;
            private set;
        }

        public bool HasData
        {
            get
            {
                bool bRes = false;
                if (null != Recording)
                    if (Recording.Length > 0)
                        bRes = true;

                return bRes;
            }
        }
    }
}
