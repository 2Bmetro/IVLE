﻿// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.IO.IsolatedStorage;
using System.IO;
using Microsoft.Phone.Tasks;

namespace Todo.Misc
{

    /// <summary>
    /// Allows easily sending crash reports for the application.
    /// </summary>
    public class LittleWatson
    {
        const string filename = "LittleWatson.txt"; 

        /// <summary>
        /// Reports an exception which has caused the application to crash.
        /// </summary>
        /// <param name="ex">The exception to report.</param>
        /// <param name="extra">Additional information to place in the error report.</param>
        public  static void ReportException(Exception ex, string extra)
        {
            try
            {
                using (var store = IsolatedStorageFile.GetUserStoreForApplication())
                {
                    SafeDeleteFile(store);

                    using (TextWriter output = new StreamWriter(store.CreateFile(filename)))
                    {
                        output.WriteLine(extra);
                        output.WriteLine(ex.Message);
                        output.WriteLine(ex.StackTrace);
                    }
                }
            }
            catch (Exception)
            {
                // We do not want this code to cause exceptions of its own
            }
        }

        /// <summary>
        /// Checks whether an error report is present following an application crash. If a report is indeed present,
        /// offers to email the report (this requires an e-mail account to be set up on the device).
        /// </summary>
        public static void CheckForPreviousException()
        {
            try
            {
                string contents = null;

                using (var store = IsolatedStorageFile.GetUserStoreForApplication())
                {
                    if (store.FileExists(filename))
                    {
                        using (TextReader reader = new StreamReader(store.OpenFile(filename, FileMode.Open, FileAccess.Read, FileShare.None)))
                        {
                            contents = reader.ReadToEnd();
                        }

                        // We have the file contents so we may delete the crash report
                        SafeDeleteFile(store);
                    }
                }

                if (contents != null)
                {
                    if (MessageBox.Show("A problem occurred the last time you ran this application. Would you like " +
                            "to send an email to report it?", "Problem Report", MessageBoxButton.OKCancel) 
                            == MessageBoxResult.OK)
                    {
                        EmailComposeTask email = new EmailComposeTask();

                        email.Subject = "Todo auto-generated problem report";

                        email.Body = contents;

                        SafeDeleteFile(IsolatedStorageFile.GetUserStoreForApplication());
                        email.Show();
                    }
                }
            }
            catch (Exception)
            {
                // We do not want this code to cause exceptions of its own
            }
            finally
            {
                // One way or another, we must make sure to delete the last crash report
                SafeDeleteFile(IsolatedStorageFile.GetUserStoreForApplication());
            }
        }

        private static void SafeDeleteFile(IsolatedStorageFile store)
        {
            try
            {
                store.DeleteFile(filename);
            }
            catch (Exception)
            {
                // We do not want this code to cause exceptions of its own
            }
        }
    }
}
