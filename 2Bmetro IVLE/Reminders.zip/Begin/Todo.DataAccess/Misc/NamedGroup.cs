﻿// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.Generic;
using System.Collections;

namespace Todo.Misc
{
    /// <summary>
    /// Represents a collection of items with an associated title.
    /// </summary>
    /// <typeparam name="T">The type of items in the collection.</typeparam>
    public class NamedGroup<T> : IEnumerable<T>
    {
        private IEnumerable<T> items;

        /// <summary>
        /// Sets or gets the group's title.
        /// </summary>
        public string Title { get; set; }        

        /// <summary>
        /// Creates a new group of items.
        /// </summary>
        /// <param name="title">The group's title.</param>
        /// <param name="items">The items to include in the group.</param>
        public NamedGroup(string title, IEnumerable<T> items)
        {
            this.items = items;
            Title = title;
        }

        public override bool Equals(object obj)
        {
            NamedGroup<T> that = obj as NamedGroup<T>;

            return (that != null) && (that.Title == Title);
        }

        public override int GetHashCode()
        {
            return Title.GetHashCode();
        }

        #region IEnumerable<T> Members

        public IEnumerator<T> GetEnumerator()
        {
            return items.GetEnumerator();
        }

        #endregion

        #region IEnumerable Members

        IEnumerator IEnumerable.GetEnumerator()
        {
            return items.GetEnumerator();
        }

        #endregion
    }
}
