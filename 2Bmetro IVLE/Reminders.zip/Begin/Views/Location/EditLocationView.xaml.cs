﻿// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Todo.ViewModels;
using System.Device.Location;
using Microsoft.Phone.Shell;
using Todo.Resources;
using Todo.Misc;
using System.Windows.Threading;

namespace Todo.Views.Location
{
    public partial class EditLocationView : EntityEditingPage
    {
        public EditLocationView()
        {
            InitializeComponent();
            InitializeAppBarText(); 
        }

        LocationEditViewModel locationEditViewModel;

        private void InitializeAppBarText()
        {
            ((ApplicationBarIconButton)ApplicationBar.Buttons[(int)Utils.LocationEditViewAppBarButtons.Save]).Text = ApplicationStrings.appBar_Save;
            ((ApplicationBarIconButton)ApplicationBar.Buttons[(int)Utils.LocationEditViewAppBarButtons.Cancel]).Text = ApplicationStrings.appBar_Cancel;
            ((ApplicationBarIconButton)ApplicationBar.Buttons[(int)Utils.LocationEditViewAppBarButtons.Geocode]).Text = ApplicationStrings.appBar_Geocode;
        }
        protected override void OnNavigatedTo(System.Windows.Navigation.NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);
            string id = string.Empty;             
            if (locationEditViewModel == null ) 
            { 
           
                locationEditViewModel = new LocationEditViewModel(NavigationContext.SafeGetQueryParam(UIConstants.LocationIdQueryParam)); 
                this.DataContext = locationEditViewModel;                                    
            } 
        }

        protected override void OnNavigatedFrom(System.Windows.Navigation.NavigationEventArgs e)
        {
            base.OnNavigatedFrom(e);
        }
        private void appBar_OnCancel(object sender, EventArgs e)
        {
            NavigationService.GoBack();
        }

        private void appBar_OnSave(object sender, EventArgs e)
        {

            if (locationEditViewModel.Validate())
            {
                locationEditViewModel.Save();
                NavigationService.GoBack();
            }           
        }
        ProgressIndicator progressIndicator;
        DispatcherTimer timer;
        GeoCoordinateWatcher watcher; 

        private void appBar_OnUseCurrentLocation(object sender, EventArgs e)
        {
            if (timer == null)
            {
                timer = new DispatcherTimer();
                timer.Interval = TimeSpan.FromSeconds(5);
                timer.Tick += new EventHandler(timer_Tick);
            }
            else if (timer.IsEnabled)
            {
                //Double clicking? 
                System.Diagnostics.Debug.WriteLine("ignoring double click on geocode"); 
                return; 
            } 

            
            if (watcher == null)
            {
                watcher = new GeoCoordinateWatcher();
                watcher.StatusChanged += new EventHandler<GeoPositionStatusChangedEventArgs>(watcher_StatusChanged);
            }

            timer.Start(); 

            progressIndicator = new ProgressIndicator (); 
            progressIndicator.IsIndeterminate = true; 
            progressIndicator.IsVisible = true; 
            SystemTray.IsVisible= true ;
            watcher.Start(); 


        }

        void timer_Tick(object sender, EventArgs e)
        {
            StopGeocoordinateWatcher();
            MessageBox.Show(ApplicationStrings.ErrorLocationAttempt); 
        }

        void StopGeocoordinateWatcher () 
        { 
            if ( timer != null ) 
                timer.Stop(); 
            if ( watcher != null) 
            { 
                watcher.Stop(); 
            } 
            progressIndicator.IsVisible = false ;
            progressIndicator = null ; 
            SystemTray.IsVisible = false;              
        } 
        void watcher_StatusChanged(object sender, GeoPositionStatusChangedEventArgs e)
        {

             if ( watcher.Status == GeoPositionStatus.Ready )
             { 
                    this.locationEditViewModel.Location.Latitude = watcher.Position.Location.Latitude; 
                    this.locationEditViewModel.Location.Longitude = watcher.Position.Location.Longitude ;
                    StopGeocoordinateWatcher(); 
             }
        } 
    }
}