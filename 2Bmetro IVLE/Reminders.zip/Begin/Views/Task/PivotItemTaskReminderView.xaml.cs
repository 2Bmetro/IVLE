﻿// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Todo.Misc;
using Todo.Resources;
using Microsoft.Phone.Scheduler;

namespace Todo.Views
{
    /// <summary>
    /// Allows adding task reminders.
    /// </summary>
    public partial class PivotItemTaskReminderView : UserControl
    {
        /// <summary>
        /// Creates a new instance of the control. Be sure to call <see cref="UpdateUI"/> at least once
        /// before using the control for it to function properly.
        /// </summary>
        public PivotItemTaskReminderView()
        {
            InitializeComponent();
        }        

        /// <summary>
        /// Causes the control to store its state in the supplied state store.
        /// </summary>
        /// <param name="stateStore">State store in which to store state information.</param>
        public void StoreState(IDictionary<string, object> stateStore)
        {
            stateStore["ReminderDescription"] = textDescription.Text;
            stateStore["ReminderDate"] = dateReminder.Value.Value;
            stateStore["ReminderTime"] = timeReminder.Value.Value;
        }

        /// <summary>
        /// Causes the control to restore its state from the supplied state store, assuming it has
        /// previously stored state information inside it.
        /// </summary>
        /// <param name="stateStore">State store from which to restore state information.</param>
        public void RestoreState(IDictionary<string, object> stateStore)
        {
            textDescription.Text = stateStore["ReminderDescription"].ToString();
            dateReminder.Value = (DateTime)stateStore["ReminderDate"];
            timeReminder.Value = (DateTime)stateStore["ReminderTime"];
        }

        private void RemoveClicked(object sender, RoutedEventArgs e)
        {            
        }

        private void AddOrUpdateClicked(object sender, RoutedEventArgs e)
        {            
        }
    }
}
