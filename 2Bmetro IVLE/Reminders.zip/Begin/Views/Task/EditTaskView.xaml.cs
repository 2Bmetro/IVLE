﻿// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Todo.Misc;
using Microsoft.Phone.Shell;
using Todo.Resources;
using System.Windows.Navigation;
using Todo.Models;
using System.Data.Linq;
using System.Globalization;

namespace Todo.Views
{
    /// <summary>
    /// Allows editing a specific task or creating a new one.
    /// </summary>
    public partial class EditTaskView : EntityEditingPage
    {
        private Project project;
        private Task task;

        private bool sourcesSet;

        /// <summary>
        /// Creates a new instance of the page.
        /// </summary>
        public EditTaskView()
        {
            InitializeComponent();

            InitializeAppBarText();

            sourcesSet = false;
        }

        /// <summary>
        /// Initializes the page with a task to edit or a new task to create.
        /// </summary>
        /// <param name="e"></param>
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            lock (App.SyncObject)
            {
                if (e.NavigationMode == NavigationMode.Back && e.IsNavigationInitiator && 
                    App.IsAppDataLoaded && !App.WasTombstoned)
                {
                    // We navigated back to the page, so there is no need to initialize anything
                    return;
                }
            }

            if (NavigationContext.QueryString.ContainsKey(UIConstants.ProjectIdQueryParam))
            {
                // We navigated to the page to create a new task for the specified project
                PageTitle.Text = ApplicationStrings.TaskEditNewTaskTitle;

                task = new Task();

                task.Id = Guid.NewGuid();

                if (RegisterForInitialDataLoadCompleted(
                    SetSourcesAfterDataLoad, NewTaskAfterDataLoad, RestoreState))
                {
                    ApplicationBar.IsVisible = false;
                }
                else
                {
                    SetSources();
                    NewTaskForProject();
                    DataContext = task;
                }
            }
            else if (NavigationContext.QueryString.ContainsKey(UIConstants.TaskIdQueryParam))
            {
                // We navigated to the page to edit an existing task                
                PageTitle.Text = ApplicationStrings.TaskEditEditTaskTitle;

                if (RegisterForInitialDataLoadCompleted(
                    SetSourcesAfterDataLoad, GetTaskAfterDataLoad, RestoreState))
                {
                    ApplicationBar.IsVisible = false;
                }
                else
                {
                    SetSources();
                    GetTaskFromQueryString();
                    DataContext = task;
                }                
            }            

            base.OnNavigatedTo(e);
        }

        private void GetTaskFromQueryString()
        {
            Guid taskGuid = NavigationContext.GetGuidParam(UIConstants.TaskIdQueryParam);  
            task = App.TasksViewModel.Items.FirstOrDefault(t => t.Id == taskGuid);
        }

        void SetSourcesAfterDataLoad(object sender, EventArgs e)
        {
            Dispatcher.BeginInvoke(() =>
                {
                    SetSources();
                });
        }

        protected override void OnNavigatingFrom(NavigatingCancelEventArgs e)
        {
            // If we did not remove focus from the title box, binding did not update the value yet
            task.Title = textTaskTitle.Text;            

            base.OnNavigatingFrom(e);
        }

        private void NewTaskForProject()
        {
            Guid projectGuid = NavigationContext.GetGuidParam(UIConstants.ProjectIdQueryParam);  
            project = App.ProjectsViewModel.Items.FirstOrDefault(proj => proj.Id == projectGuid);
            task.Projects = project;
            task.Priority = project.DefaultPriority;

            // Set a due date for the task according to the project setting
            switch (project.DefaultDueDate)
            {
                case DefaultDueDate.None:
                    break;
                case DefaultDueDate.SameDay:
                    task.DueDate = DateTime.Now.Date;
                    break;
                case DefaultDueDate.NextDay:
                    task.DueDate = DateTime.Now.Date.AddDays(1);
                    break;
                case DefaultDueDate.Weekend:
                    DayOfWeek today = DateTime.Now.DayOfWeek; 
                    int daysoffset = 0 ; 
                    if ( today < DayOfWeek.Saturday ) 
                    { 
                        daysoffset = (int) ( DayOfWeek.Saturday - today); 
                    }
                    task.DueDate = DateTime.Now.Date.AddDays(daysoffset);  
                    break;
                case DefaultDueDate.MonthEnd:
                    task.DueDate = new DateTime(DateTime.Now.Year, DateTime.Now.Month,
                        DateTime.DaysInMonth(DateTime.Now.Year, DateTime.Now.Month));
                    break;
                default:
                    break;
            }
        }

        private void NewTaskAfterDataLoad(object sender, EventArgs e)
        {
            Dispatcher.BeginInvoke(() =>
                {
                    NewTaskForProject();
                });
        }

        private void GetTaskAfterDataLoad(object sender, EventArgs e)
        {
            Dispatcher.BeginInvoke(() =>
                {
                    GetTaskFromQueryString();
                });
        }

        private void SetSources()
        {
            if (!sourcesSet)
            {
                sourcesSet = true;
                listProjects.ItemsSource = App.ProjectsViewModel.Items;
                //listStatus.ItemsSource = MetaData.TaskStatusValues;
                listPriority.ItemsSource = MetaData.PriorityValues;
                listLocations.ItemsSource = App.LocationsViewModel.Items;
            }
        }

        protected override void RestoreState(object sender, EventArgs e)
        {
            Dispatcher.BeginInvoke(() =>
                {
                    task.Title = State["title"].ToString();
                    task.Projects = App.ProjectsViewModel.Items.First(
                        p => p.Id == (Guid)State["projectID"]);
                    task.Priority = (PriorityValue)State["priority"];
                    task.Status = (TaskStatus)State["status"];
                    task.DueDate = State["dueDate"] as DateTime?;

                    ApplicationBar.IsVisible = true;
                    DataContext = task;
                });
        }

        protected override void StoreState()
        {
            State["title"] = textTaskTitle.Text;
            State["projectID"] = (listProjects.SelectedItem as Project).Id;
            State["priority"] = (PriorityValue)listPriority.SelectedItem;
            //TODO: we're using a checkbox for status now -- need to update this to get the value from that checkbox
            //State["status"] = (TaskStatus)listStatus.SelectedItem;
            State["dueDate"] = dateDueDate.Value;
        }

        
        private void appBar_OnSave(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(textTaskTitle.Text))
            {
                MessageBox.Show(ApplicationStrings.Msg_EmptyTaskTitle);

                return;
            }

            // If we did not remove focus from the title box, binding did not update the value yet
            task.Title = textTaskTitle.Text;

            // Save the new task
            if (NavigationContext.QueryString.ContainsKey(UIConstants.ProjectIdQueryParam))
            {
                App.TasksViewModel.Insert(task);
            }
            // Update the existing task
            else
            {
                App.TasksViewModel.Update(task);
            }

            NavigationService.GoBack();
        }

        private void appBar_OnCancel(object sender, EventArgs e)
        {
            NavigationService.GoBack();
        }

        private void InitializeAppBarText()
        {
            ((ApplicationBarIconButton)ApplicationBar.Buttons[(int)Utils.TaskEditViewAppBarButtons.Save]).Text = ApplicationStrings.appBar_Save;
            ((ApplicationBarIconButton)ApplicationBar.Buttons[(int)Utils.TaskEditViewAppBarButtons.Cancel]).Text = ApplicationStrings.appBar_Cancel;
            ((ApplicationBarMenuItem)ApplicationBar.MenuItems[(int)Utils.GeneralAppBarMenuItems.Location]).Text = ApplicationStrings.appBar_Location;
            ((ApplicationBarMenuItem)ApplicationBar.MenuItems[(int)Utils.GeneralAppBarMenuItems.Settings]).Text = ApplicationStrings.appBar_Settings;
        }

 
        private void appBar_OnLocation(object sender, EventArgs e)
        {
            StoreState();
            NavigationService.Navigate(UIConstants.LocationsListView);
        }

       

        private void appBar_OnSettings(object sender, EventArgs e)
        {
            StoreState();
            NavigationService.Navigate(UIConstants.SettingsView);
        }
    }
}