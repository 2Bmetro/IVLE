﻿// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using Todo.Misc;
using Todo.Resources;
using System.Windows.Navigation;
using Todo.ViewModels;
using System.Windows.Data;

namespace Todo.Views
{
    /// <summary>
    /// This page displays information about a task and allows manipulating its attachments.
    /// </summary>
    public partial class TaskView : TodoAppPage
    {
        
        private TaskEditViewModel taskViewModel; 
        private bool pageInitialized;

        /// <summary>
        /// Creates a new instance of the page.
        /// </summary>
        public TaskView()
        {
            InitializeComponent();
            InitializeAppBarText();

             
            pageInitialized = false;


            // create appbar buttons

            ApplicationBarIconButton editButton = new ApplicationBarIconButton(new Uri("/Images/appbar.edit.png", UriKind.Relative));
            editButton.Text = ApplicationStrings.appBar_Edit;
            editButton.Click += appBar_OnEdit;

            ApplicationBarIconButton deleteButton = new ApplicationBarIconButton(new Uri("/Images/appbar.delete.png", UriKind.Relative));
            deleteButton.Text = ApplicationStrings.appBar_Delete;
            deleteButton.Click += appBar_OnDelete;

            ApplicationBar.Buttons.Add(editButton);
            ApplicationBar.Buttons.Add(deleteButton);

        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            lock (App.SyncObject)
            {
                if (e.NavigationMode == NavigationMode.Back && e.IsNavigationInitiator &&
                    App.IsAppDataLoaded && !App.WasTombstoned)
                {
                    // We navigated back to the page, so there is no need to initialize anything
                    return;
                }
            }

            if ( !App.IsAppDataLoaded ) 
            { 
                RegisterForInitialDataLoadCompleted(InitializePageAfterDataLoaded, RestoreState); 
            } 
            else 
            { 
                InitializePageAfterDataLoaded(null, null); 
                RestoreState ( null, null ) ; 

            } 
            
            base.OnNavigatedTo(e);
        }

        protected override void OnNavigatedFrom(NavigationEventArgs e)
        {
            if (!e.IsNavigationInitiator)
            {
                StoreState();
            }

            base.OnNavigatedFrom(e);
        }

        protected override void StoreState()
        {
          

            base.StoreState();
        }

        protected override void RestoreState(object sender, EventArgs args)
        {
            Dispatcher.BeginInvoke(() =>
            {
               
            });

            base.RestoreState(sender, args);
        }

        protected bool CanNavigate ( )
        {
            
            if (this.taskViewModel.IsReminderSettingEnabled &&
                !this.taskViewModel.HasValidReminder)
            {
                MessageBoxResult result = MessageBox.Show(ApplicationStrings.TaskReminderIsIncomplete, "", MessageBoxButton.OKCancel);  
               {
                   return (result == MessageBoxResult.OK );  
               } 
            }
            return true; 
        }
        private void InitializePageAfterDataLoaded(object sender, EventArgs e)
        {
            Dispatcher.BeginInvoke(() =>
                {
                    InitializePage();                   
                    ApplicationBar.IsVisible = true;
                });
        }

        private void InitializePage()
        {
            if ( !pageInitialized)
            { 
                Guid id = NavigationContext.GetGuidParam ( UIConstants.TaskIdQueryParam ) ; 
                taskViewModel = new TaskEditViewModel(id );  
                this.DataContext = taskViewModel; 

                //hacky workaround to prevent flickering. 
                //Binding binding = new Binding ("IsReminderSettingEnabled"); 
                //binding.Converter = App.Current.Resources["BoolToVisibilityConverter"] as IValueConverter;                
                //reminderContainer.SetBinding ( Grid.VisibilityProperty, binding ); 

                //reminderContainer.Visibility= 
                //Visibility="{Binding IsReminderSettingEnabled, Converter={StaticResource BoolToVisibilityConverter}}"

                pageInitialized = true;
            } 
        }

        protected override void OnBackKeyPress(System.ComponentModel.CancelEventArgs e)
        {
            if (CanNavigate())
            {
                base.OnBackKeyPress(e);
            } 
        }

         

        private void appBar_OnEdit(object sender, EventArgs e)
        {
            if ( CanNavigate ()) 
                NavigationService.Navigate(UIConstants.MakeTaskEditViewUri(taskViewModel.Task )) ;
        }
     

        private void appBar_OnDelete(object sender, EventArgs e)
        {
            if (MessageBox.Show(ApplicationStrings.Msg_TaskDelete, ApplicationStrings.MsgTitle_TaskDelete,
                MessageBoxButton.OKCancel) == MessageBoxResult.OK)
            {
                taskViewModel.Delete();                 
                NavigationService.GoBack();
            }
        }

         
        private void appBar_OnSettings(object sender, EventArgs e)
        {
            if ( CanNavigate()) 
            base.OnAppBarSettingsClick( sender, e );  
        }

        private void InitializeAppBarText()
        {             
            ((ApplicationBarMenuItem)ApplicationBar.MenuItems[(int)Utils.GeneralAppBarMenuItems.Settings]).Text = ApplicationStrings.appBar_Settings;
        }         
    }
}