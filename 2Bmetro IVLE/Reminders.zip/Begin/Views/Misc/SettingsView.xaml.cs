﻿// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Todo.Interfaces;
using Todo.Data;
using Microsoft.Phone.Scheduler;
using Todo.ViewModels;

namespace Todo.Views
{
    public partial class SettingsView : TodoAppPage
    {
        private bool isDirty = false;

        SettingsViewModel settingsViewModel; 
        public SettingsView()
        {
            InitializeComponent();
            settingsViewModel = new SettingsViewModel();
            this.DataContext = settingsViewModel; 
        }

        

        #region Overrides
        protected override void OnBackKeyPress(System.ComponentModel.CancelEventArgs e)
        {
            promptToSave();

            base.OnBackKeyPress(e);
        }

        protected override void OnNavigatedFrom(System.Windows.Navigation.NavigationEventArgs e)
        {
            
            base.OnNavigatedFrom(e);
        }
        #endregion

        #region Event Handlers
        private void appBar_OK(object sender, EventArgs e)
        {
            settingsViewModel.Save.Execute(null); 
            NavigationService.GoBack();
        }

        private void appBar_Cancel(object sender, EventArgs e)
        {
            promptToSave();

            NavigationService.GoBack();
        }

        private void appBar_OnAbout(object sender, EventArgs e)
        {
            NavigationService.Navigate(UIConstants.AboutView);
        }

       

       
        #endregion

        #region Private functionality
        private void promptToSave()
        {
            if (isDirty)
            {
                if (MessageBox.Show("Save changes before exit?", "Save changes", MessageBoxButton.OKCancel) == MessageBoxResult.OK)
                    settingsViewModel.Save.Execute(null ); 
            } 
        }

        

        
        #endregion



 
    }
}