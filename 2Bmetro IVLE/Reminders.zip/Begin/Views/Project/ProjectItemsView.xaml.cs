﻿// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using Todo.Misc;
using Todo.Resources;

namespace Todo.Views
{
    /// <summary>
    /// Displays all of the items contained in the project in one of several ways.
    /// </summary>
    public partial class ProjectItemsView : TodoAppPage
    {
        private bool pageInitialized;

        /// <summary>
        /// Constructs a new instance of the page.
        /// </summary>
        public ProjectItemsView()
        {
            InitializeComponent();

            InitializeAppBarText();

            pageInitialized = false;
        }

        protected override void OnNavigatedTo(System.Windows.Navigation.NavigationEventArgs e)
        {
            if (RegisterForInitialDataLoadCompleted(InitializePageAfterDataLoaded))
            {
                pivot.IsEnabled = false;
                ApplicationBar.IsVisible = false;
            }
            else
            {
                InitializePage();
            }

            base.OnNavigatedTo(e);
        }

        void InitializePageAfterDataLoaded(object sender, EventArgs e)
        {
            Dispatcher.BeginInvoke(() =>
            {
                InitializePage();
            });
        }

        private void InitializePage()
        {
            if (!pageInitialized)
            {
                pageInitialized = true;
                ApplicationBar.IsVisible = true;
                pivot.IsEnabled = true;
                Guid projectID = NavigationContext.GetGuidParam(UIConstants.ProjectIdQueryParam); 
                DataContext = App.ProjectsViewModel.Items.FirstOrDefault(p => p.Id == projectID);
            }
        }

        private void appBar_NewItem(object sender, EventArgs e)
        {
            NavigationService.Navigate(
                UIConstants.MakeEditTaskViewUriForProject (this.DataContext as Project ));  
        }

        private void appBar_OnAbout(object sender, EventArgs e)
        {
            NavigationService.Navigate(UIConstants.AboutView);
        }

        private void appBar_OnSettings(object sender, EventArgs e)
        {
            NavigationService.Navigate(UIConstants.SettingsView);
        }

        private void InitializeAppBarText()
        {
            ((ApplicationBarIconButton)ApplicationBar.Buttons[(int)Utils.ProjectItemsViewAppBarButtons.NewItem]).Text = ApplicationStrings.appBar_NewTask;          
            ((ApplicationBarMenuItem)ApplicationBar.MenuItems[(int)Utils.GeneralAppBarMenuItems.Settings]).Text = ApplicationStrings.appBar_Settings;
        }

        private void TaskTapped(object sender, System.Windows.Input.GestureEventArgs e)
        {
            Task item = (sender as FrameworkElement).DataContext as Task;

            NavigationService.Navigate(UIConstants.MakeTaskViewUri(item));


        }
    }
}