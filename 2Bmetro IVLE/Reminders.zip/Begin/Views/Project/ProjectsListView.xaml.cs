﻿// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using Todo.Misc;
using Todo.Resources;

namespace Todo.Views
{
    public partial class ProjectsListView : TodoAppPage
    {
        private bool pageInitialized;

        public ProjectsListView()
        {
            pageInitialized = false;

            InitializeComponent();

            InitializeAppBarText();            
        }

        protected override void OnNavigatedTo(System.Windows.Navigation.NavigationEventArgs e)
        {
            if (RegisterForInitialDataLoadCompleted(InitializePageAfterDataLoaded))
            {
                ApplicationBar.IsVisible = false;
            }
            else
            {
                InitializePage();
            }

            base.OnNavigatedTo(e);
        }

        void InitializePageAfterDataLoaded(object sender, EventArgs e)
        {
            Dispatcher.BeginInvoke(() =>
                {
                    InitializePage();
                });
        }

        private void InitializePage()
        {
            if (!pageInitialized)
            {
                pageInitialized = true;
                ApplicationBar.IsVisible = true;
                DataContext = App.ProjectsViewModel.Items;
            }
        }

        private void ListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (e.AddedItems.Count == 1)
            {
                NavigationService.Navigate(
                    UIConstants.MakeProjectDetailsViewUri ( e.AddedItems[0] as Project ));                      
                listProjects.SelectedItem = null;
            }
        }

        private void appBar_OnNewProject(object sender, EventArgs e)
        {
            NavigationService.Navigate(new Uri("/Views/Project/EditProjectDetailsView.xaml", UriKind.Relative));
        }

        private void appBar_OnAbout(object sender, EventArgs e)
        {
            NavigationService.Navigate(UIConstants.AboutView);
        }

        private void appBar_OnLocationClick(object sender, EventArgs e)
        {
            base.OnAppBarLocationClick( sender, e ); 
            
        }

        private void appBar_OnSettings(object sender, EventArgs e)
        {
            base.OnAppBarSettingsClick( sender, e );              
        }

        private void InitializeAppBarText()
        {
            ((ApplicationBarIconButton)ApplicationBar.Buttons[(int)Utils.ProjectListViewAppBarButtons.NewProject]).Text = ApplicationStrings.appBar_NewProject;
            //((ApplicationBarMenuItem)ApplicationBar.MenuItems[(int)Utils.GeneralAppBarMenuItems.About]).Text = ApplicationStrings.appBar_About;
            ((ApplicationBarMenuItem)ApplicationBar.MenuItems[(int)Utils.GeneralAppBarMenuItems.Settings]).Text = ApplicationStrings.appBar_Settings;
            ((ApplicationBarMenuItem)ApplicationBar.MenuItems[(int)Utils.GeneralAppBarMenuItems.Location]).Text = ApplicationStrings.appBar_Location;
        }
    }
}