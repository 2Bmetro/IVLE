﻿// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Todo.Misc;
using Microsoft.Phone.Shell;
using Todo.Resources;

namespace Todo.Views
{
    /// <summary>
    /// Allows editing or creating a new note attachment.
    /// </summary>
    public partial class NoteAttachmentView : EntityEditingPage
    {
        private bool newNote;
        private Attachment noteAttachment;

        private bool attachmentSet;

        /// <summary>
        /// Creates a new instance of the page.
        /// </summary>
        public NoteAttachmentView()
        {
            InitializeComponent();

            InitializeAppBarText();

            attachmentSet = false;
        }

        /// <summary>
        /// Initializes the page with an existing note attachment or a new one.
        /// </summary>
        /// <param name="e"></param>
        protected override void OnNavigatedTo(System.Windows.Navigation.NavigationEventArgs e)
        {
            if (NavigationContext.QueryString.ContainsKey(UIConstants.AttachmentIdQueryParam))
            {
                // We navigated to edit an existing note
                PageTitle.Text = ApplicationStrings.NoteAttachmentEditTitle;

                if (RegisterForInitialDataLoadCompleted(GetNoteAttachmentAfterDataLoaded, RestoreState))
                {
                    ApplicationBar.IsVisible = false;
                }
                else
                {
                    GetNoteAttachment();
                }
            }
            else if (NavigationContext.QueryString.ContainsKey(UIConstants.TaskIdQueryParam))
            {
                // We navigated to the page to create a new note
                PageTitle.Text = ApplicationStrings.NoteAttachmentAddTitle;

                if (RegisterForInitialDataLoadCompleted(NewNoteAttachmentAfterDataLoaded, RestoreState))
                {
                    ApplicationBar.IsVisible = false;
                }
                else
                {
                    NewNoteAttachment();
                }
            }

            DataContext = noteAttachment;

            base.OnNavigatedTo(e);
        }

        protected override void OnNavigatingFrom(System.Windows.Navigation.NavigatingCancelEventArgs e)
        {
            // In case we did not remove the focus from the note contents text box
            noteAttachment.TextNote = textNote.Text;

            base.OnNavigatingFrom(e);
        }

        private void NewNoteAttachmentAfterDataLoaded(object sender, EventArgs args)
        {
            Dispatcher.BeginInvoke(() =>
            {
                NewNoteAttachment();
            });
        }

        private void NewNoteAttachment()
        {
            if (attachmentSet)
            {
                return;
            }

            newNote = true;
            ((ApplicationBarIconButton)ApplicationBar.Buttons[(int)Utils.NoteAttachmentViewAppBarButtons.Delete]).IsEnabled = false;

            noteAttachment = new Attachment();
            noteAttachment.Id = Guid.NewGuid();
            noteAttachment.AttachmentType = App.AttachmentTypeViewModel.Items.First(attType => attType.Id == new Guid(Utils.AttachmentTypeIDText));

            DataContext = noteAttachment;
            attachmentSet = true;
        }

        private void GetNoteAttachmentAfterDataLoaded(object sender, EventArgs args)
        {
            Dispatcher.BeginInvoke(() =>
            {
                GetNoteAttachment();
            });
        }

        private void GetNoteAttachment()
        {
            if (attachmentSet)
            {
                return;
            }

            Guid attachmentGuid = NavigationContext.GetGuidParam(UIConstants.AttachmentIdQueryParam);  
            noteAttachment = App.AttachmentViewModel.Items.FirstOrDefault(att => att.Id == attachmentGuid);

            newNote = false;

            DataContext = noteAttachment;
            attachmentSet = true;
        }

        protected override void StoreState()
        {
            State["Note"] = textNote.Text;

            base.StoreState();
        }

        protected override void RestoreState(object sender, EventArgs args)
        {
            Dispatcher.BeginInvoke(() =>
                {
                    textNote.Text = State["Note"].ToString();

                    ApplicationBar.IsVisible = true;
                });

            base.RestoreState(sender, args);
        }

        private void appBar_OnAbout(object sender, EventArgs e)
        {
            NavigationService.Navigate(UIConstants.AboutView);
        }

        private void appBar_OnSave(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(textNote.Text))
            {
                MessageBox.Show(ApplicationStrings.Msg_EmptyNote);

                return;
            }

            // In case we did not remove the focus from the note contents text box
            noteAttachment.TextNote = textNote.Text;

            if (newNote)
            {
                noteAttachment.Items = App.TasksViewModel.Items.First(item => item.Id ==  NavigationContext.GetGuidParam(UIConstants.TaskIdQueryParam));

                App.AttachmentViewModel.Insert(noteAttachment);
            }
            else
            {
                App.AttachmentViewModel.Update(noteAttachment);
            }

            NavigationService.GoBack();
        }

        private void appBar_OnCancel(object sender, EventArgs e)
        {
            NavigationService.GoBack();
        }

        private void appBar_OnDelete(object sender, EventArgs e)
        {
            if (MessageBox.Show(ApplicationStrings.Msg_AttachmentDelete, ApplicationStrings.MsgTitle_AttachmentDelete,
                MessageBoxButton.OKCancel) == MessageBoxResult.OK)
            {
                App.AttachmentViewModel.Delete(noteAttachment.Id);

                NavigationService.GoBack();
            }
        }

        private void appBar_OnSettings(object sender, EventArgs e)
        {
            NavigationService.Navigate(UIConstants.SettingsView);
        }

        private void InitializeAppBarText()
        {
            ((ApplicationBarIconButton)ApplicationBar.Buttons[(int)Utils.NoteAttachmentViewAppBarButtons.Save]).Text = ApplicationStrings.appBar_Save;
            ((ApplicationBarIconButton)ApplicationBar.Buttons[(int)Utils.NoteAttachmentViewAppBarButtons.Cancel]).Text = ApplicationStrings.appBar_Cancel;
            ((ApplicationBarIconButton)ApplicationBar.Buttons[(int)Utils.NoteAttachmentViewAppBarButtons.Delete]).Text = ApplicationStrings.appBar_Delete;             
            ((ApplicationBarMenuItem)ApplicationBar.MenuItems[(int)Utils.GeneralAppBarMenuItems.Settings]).Text = ApplicationStrings.appBar_Settings;
        }
    }
}