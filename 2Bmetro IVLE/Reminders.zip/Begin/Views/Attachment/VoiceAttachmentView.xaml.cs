﻿// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using Todo.Misc;
using Todo.Resources;
using System.Data.Linq;

namespace Todo.Views
{
    public partial class VoiceAttachmentView : EntityEditingPage
    {
        private bool newRecording;
        private bool isRecording;
        private bool isPlayingBack;
        private bool dataRecorded;

        private bool attachmentSet;

        private Task task;
        private MicHelper micHelper;

        private Attachment voiceAttachment;

        public VoiceAttachmentView()
        {
            InitializeComponent();

            InitializeAppBarText();

            micHelper = new MicHelper();
            micHelper.RecordingStopped += micHelper_RecordingStopped;
            micHelper.PlaybackStopped += micHelper_PlaybackStopped;

            attachmentSet = false;
        }

        protected override void OnNavigatedFrom(System.Windows.Navigation.NavigationEventArgs e)
        {
            micHelper = null;

            base.OnNavigatedFrom(e);
        }

        protected override void OnNavigatingFrom(System.Windows.Navigation.NavigatingCancelEventArgs e)
        {
            micHelper.StopRecording();
            micHelper.StopPlaying();

            // If the caption box did not lose focus, we need to update this manually
            voiceAttachment.TextNote = textCaption.Text;

            base.OnNavigatingFrom(e);
        }

        protected override void OnNavigatedTo(System.Windows.Navigation.NavigationEventArgs e)
        {
            buttonPlayStop.Content = ApplicationStrings.VoiceMemoButtonPlay;

            newRecording = false;
            isRecording = false;
            isPlayingBack = false;
            dataRecorded = false;

            if (NavigationContext.QueryString.ContainsKey(UIConstants.TaskIdQueryParam))
            {
                // We navigated to the page to create a new recording
                newRecording = true;

                if (RegisterForInitialDataLoadCompleted(NewVoiceAttachmentAfterDataLoaded, RestoreState))
                {
                    ApplicationBar.IsVisible = false;
                    buttonRecord.IsEnabled = false;
                }
                else
                {
                    NewVoiceAttachment();
                }
            }
            else if (NavigationContext.QueryString.ContainsKey(UIConstants.AttachmentIdQueryParam))
            {
                // We are editing an existing recording
                if (RegisterForInitialDataLoadCompleted(GetVoiceAttachmentAfterDataLoaded, RestoreState))
                {
                    ApplicationBar.IsVisible = false;
                    buttonRecord.IsEnabled = false;
                }
                else
                {
                    GetVoiceAttachment();
                }
            }

            base.OnNavigatedTo(e);
        }

        private void GetVoiceAttachmentAfterDataLoaded(object sender, EventArgs e)
        {
            Dispatcher.BeginInvoke(() =>
            {
                GetVoiceAttachment();
            });
        }

        private void GetVoiceAttachment()
        {
            if (attachmentSet)
            {
                return;
            }

            voiceAttachment = App.AttachmentViewModel.Items.First(
                att => att.Id == NavigationContext.GetGuidParam(UIConstants.AttachmentIdQueryParam) );

            buttonPlayStop.IsEnabled = true;

            DataContext = voiceAttachment;
            attachmentSet = true;
        }

        private void NewVoiceAttachmentAfterDataLoaded(object sender, EventArgs e)
        {
            Dispatcher.BeginInvoke(() =>
                {
                    NewVoiceAttachment();
                });
        }

        private void NewVoiceAttachment()
        {
            if (attachmentSet)
            {
                return;
            }

            task = App.TasksViewModel.Items.First(t => t.Id == NavigationContext.GetGuidParam(UIConstants.TaskIdQueryParam) );

            voiceAttachment = new Attachment();
            voiceAttachment.Id = Guid.NewGuid();
            voiceAttachment.AttachmentType = App.AttachmentTypeViewModel.Items.First(
                    attType => attType.Id == new Guid(Utils.AttachmentTypeIDVoice));            

            DataContext = voiceAttachment;
            attachmentSet = true;

            ((ApplicationBarIconButton)ApplicationBar.Buttons[(int)Utils.VoiceAttachmentViewAppBarButtons.Delete]).IsEnabled = false;
        }

        protected override void StoreState()
        {
            State["Caption"] = textCaption.Text;            
            State["RecordingData"] = (voiceAttachment.Blob == null) ? null : voiceAttachment.Blob.ToArray();
            State["RecordingLength"] = voiceAttachment.Length;
            State["DataRecorded"] = dataRecorded;

            base.StoreState();
        }

        protected override void RestoreState(object sender, EventArgs args)
        {
            Dispatcher.BeginInvoke(() =>
                {
                    textCaption.Text = State["Caption"].ToString();
                    voiceAttachment.Blob = State["RecordingData"] as byte[];
                    voiceAttachment.Length = (double)State["RecordingLength"];
                    dataRecorded = (bool)State["DataRecorded"];

                    ApplicationBar.IsVisible = true;
                    buttonRecord.IsEnabled = true;

                    if (voiceAttachment.Blob != null)
                    {
                        buttonPlayStop.IsEnabled = true;
                    }
                });

            base.RestoreState(sender, args);
        }

        private void InitializeAppBarText()
        {
            ((ApplicationBarIconButton)ApplicationBar.Buttons[(int)Utils.VoiceAttachmentViewAppBarButtons.Save]).Text = ApplicationStrings.appBar_Save;
            ((ApplicationBarIconButton)ApplicationBar.Buttons[(int)Utils.VoiceAttachmentViewAppBarButtons.Cancel]).Text = ApplicationStrings.appBar_Cancel;
            ((ApplicationBarIconButton)ApplicationBar.Buttons[(int)Utils.VoiceAttachmentViewAppBarButtons.Delete]).Text = ApplicationStrings.appBar_Delete;            
            ((ApplicationBarMenuItem)ApplicationBar.MenuItems[(int)Utils.GeneralAppBarMenuItems.Settings]).Text = ApplicationStrings.appBar_Settings;
        }

        private void appBar_OnAbout(object sender, EventArgs e)
        {
            NavigationService.Navigate(UIConstants.AboutView);
        }

        private void appBar_OnSave(object sender, EventArgs e)
        {
            micHelper.StopRecording();
            micHelper.StopPlaying();

            if (String.IsNullOrEmpty(textCaption.Text))
            {
                MessageBox.Show(ApplicationStrings.Msg_NoCaption);

                return;
            }

            // If the caption box did not lose foxus, binding may not have updated this
            voiceAttachment.TextNote = textCaption.Text;

            if (newRecording)
            {
                if (voiceAttachment.Blob == null)
                {
                    MessageBox.Show(ApplicationStrings.Msg_NoRecording);

                    return;
                }

                // To this only now since otherwise the rollback will leave the UI attachment
                // list out of sync
                voiceAttachment.Items = task;

                App.AttachmentViewModel.Insert(voiceAttachment);
            }
            else
            {                
                App.AttachmentViewModel.Update(voiceAttachment);
            }

            NavigationService.GoBack();
        }

        private void appBar_OnCancel(object sender, EventArgs e)
        {            
            NavigationService.GoBack();
        }

        private void btnRecord_Click(object sender, RoutedEventArgs e)
        {
            if (isRecording)
            {
                // The button should stop the recording
                micHelper.StopRecording();
            }
            else
            {
                if (dataRecorded)
                {
                    if (MessageBox.Show(ApplicationStrings.Msg_VoiceDiscard, ApplicationStrings.MsgTitle_VoiceDiscard,
                        MessageBoxButton.OKCancel) == MessageBoxResult.Cancel)
                    {
                        return;
                    }
                }

                // The button should initiate a recording
                isRecording = true;
                progressIndicator.Visibility = Visibility.Visible;
                micHelper.StartRecording(TimeSpan.FromSeconds(Utils.maxRecordingDuration));
                buttonRecord.Content = ApplicationStrings.VoiceMemoButtonStop;
                buttonPlayStop.IsEnabled = false;
            }
        }

        private void btnPlay_Click(object sender, RoutedEventArgs e)
        {
            if (isPlayingBack)
            {
                micHelper.StopPlaying();
            }
            else
            {
                micHelper.PlayRecording(voiceAttachment.Blob.ToArray(), TimeSpan.FromSeconds(voiceAttachment.Length));
                isPlayingBack = true;
                progressIndicator.Visibility = Visibility.Visible;
                buttonRecord.IsEnabled = false;
                buttonPlayStop.Content = ApplicationStrings.VoiceMemoButtonStop;
            }
        }

        private void micHelper_PlaybackStopped(object sender, EventArgs e)
        {
            isPlayingBack = false;
            progressIndicator.Visibility = Visibility.Collapsed;
            buttonRecord.IsEnabled = true;
            buttonPlayStop.Content = ApplicationStrings.VoiceMemoButtonPlay;
        }

        private void micHelper_RecordingStopped(object sender, EventArgs e)
        {
            isRecording = false;
            progressIndicator.Visibility = Visibility.Collapsed;
            buttonRecord.Content = ApplicationStrings.VoiceMemoButtonRecord;
            buttonPlayStop.IsEnabled = true;
            dataRecorded = true;
            voiceAttachment.Blob = micHelper.RecordingBytes;
            voiceAttachment.Length = micHelper.RecordingLength.TotalSeconds;
        }

        private void appBar_OnDelete(object sender, EventArgs e)
        {
            if (MessageBox.Show(ApplicationStrings.Msg_AttachmentDelete, ApplicationStrings.MsgTitle_AttachmentDelete,
                MessageBoxButton.OKCancel) == MessageBoxResult.OK)
            {
                App.AttachmentViewModel.Delete(voiceAttachment.Id);

                NavigationService.GoBack();
            }
        }

        private void appBar_OnSettings(object sender, EventArgs e)
        {
            NavigationService.Navigate(UIConstants.SettingsView);
        }
    }
}