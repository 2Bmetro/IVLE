﻿// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Navigation;
using Todo.Resources;
using Todo.Misc;

namespace Todo.Views
{
    /// <summary>
    /// A page which contains editing controls and needs to perserve their content when the application
    /// deactivates and warn the user when navigating away after performing changes.
    /// </summary>
    public class EntityEditingPage : TodoAppPage
    {
        protected bool rollbackRequired;

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            rollbackRequired = false;

            base.OnNavigatedTo(e);
        }

        protected override void OnNavigatingFrom(NavigatingCancelEventArgs e)
        {
            // If the the user made changes to an entity on the page we can check for them on the datacontext
            // and warn the user when navigating away from the page
            if (e.NavigationMode == NavigationMode.Back && App.TodoDC.HasPendingChanges())
            {
                if (MessageBox.Show(ApplicationStrings.Msg_DiscardChanges, ApplicationStrings.MsgTitle_DiscardChanges,
                    MessageBoxButton.OKCancel) == MessageBoxResult.Cancel)
                {
                    e.Cancel = true;
                }
                else
                {
                    rollbackRequired = true;
                }
            }

            base.OnNavigatingFrom(e);
        }

        protected override void OnNavigatedFrom(NavigationEventArgs e)
        {
            // Call the base implementation first to have the state stored if needed
            base.OnNavigatedFrom(e);

            if (e.IsNavigationInitiator == true)
            {
                // Discard the changes performed on the page if that is what the user intended
                if (rollbackRequired)
                {
                    App.TodoDC.RollBack();
                }             
            }
            else if (App.TodoDC.HasPendingChanges())
            {
                // If we don't rollback before deactivation, the changes will get submitted
                App.TodoDC.RollBack();
            }
        }
    }
}
