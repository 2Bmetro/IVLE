﻿// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using Todo.ViewModels;
using Microsoft.Phone.Data.Linq;
using Todo.Misc;
using Todo.Resources;
using System.Threading;
using System.Windows.Threading;

namespace Todo
{
    public partial class App : Application
    {
        public const string DatabaseFilename = "isostore:ToDo.sdf";
        public static string DatabasePassword = "";

        private static bool appInitialLoadPerformed = false;
        public static bool AppInitialized = false;        

        //Application's Helper data
        #region Static Tables/Data Models and loading
        public static DataContextBase TodoDC;
        private static ProjectsViewModel projectsViewModel = null;
        public static ProjectsViewModel ProjectsViewModel
        {
            get
            {
                // Delay creation of the view model until necessary
                if (projectsViewModel == null)
                    projectsViewModel = new ProjectsViewModel(TodoDC);

                return projectsViewModel;
            }
        }

        private static AttachmentTypeViewModel attachmentTypeViewModel = null;
        public static AttachmentTypeViewModel AttachmentTypeViewModel
        {
            get
            {
                // Delay creation of the view model until necessary
                if (attachmentTypeViewModel == null)
                    attachmentTypeViewModel = new AttachmentTypeViewModel(TodoDC);

                return attachmentTypeViewModel;
            }
        }

        private static LocationsViewModel locationsViewModel = null;
        public static LocationsViewModel LocationsViewModel
        {
            get
            {
                // Delay creation of the view model until necessary
                if (locationsViewModel == null)
                    locationsViewModel = new Todo.ViewModels.LocationsViewModel(TodoDC);

                return locationsViewModel;
            }
        }

        private static AttachmentViewModel attachmentViewModel = null;
        public static AttachmentViewModel AttachmentViewModel
        {
            get
            {
                // Delay creation of the view model until necessary
                if (attachmentViewModel == null)
                    attachmentViewModel = new AttachmentViewModel(TodoDC);

                return attachmentViewModel;
            }
        }

        private static TasksViewModel tasksViewModel = null;
        /// <summary>
        /// A static ViewModel used by the views to bind against.
        /// </summary>
        /// <returns>The MainViewModel object.</returns>
        public static TasksViewModel TasksViewModel
        {
            get
            {
                // Delay creation of the view model until necessary
                if (tasksViewModel == null)
                    tasksViewModel = new TasksViewModel(TodoDC);

                return tasksViewModel;
            }
        }

        public static void DropLoadedData()
        {
            App.TasksViewModel.DropData();
            App.ProjectsViewModel.DropData();
            App.AttachmentTypeViewModel.DropData();
            App.AttachmentViewModel.DropData();
        }

        public static void EnsureDataLoaded()
        {
            if (!App.ProjectsViewModel.IsDataLoaded)
            {
                App.ProjectsViewModel.LoadData();
            }

            if (!App.AttachmentTypeViewModel.IsDataLoaded)
            {
                App.AttachmentTypeViewModel.LoadData();
            }

            if (!App.AttachmentViewModel.IsDataLoaded)
            {
                App.AttachmentViewModel.LoadData();
            }

            if (!App.TasksViewModel.IsDataLoaded)
            {
                App.TasksViewModel.LoadData();
            }
            if (!App.LocationsViewModel.IsDataLoaded)
            {
                App.LocationsViewModel.LoadData(); 
            } 
        }

        private static SettingsViewModel settingsViewModel = null;        
        public static SettingsViewModel SettingsViewModel
        {
            get
            {
                // Delay creation of the view model until necessary
                if (settingsViewModel == null)
                    settingsViewModel = new SettingsViewModel();

                return settingsViewModel;
            }
        }
        #endregion

        /// <summary>
        /// Provides easy access to the root frame of the Phone Application.
        /// </summary>
        /// <returns>The root frame of the Phone Application.</returns>
        public PhoneApplicationFrame RootFrame { get; private set; }

        /// <summary>
        /// Synchronization object used for safely updating the application data.
        /// </summary>
        public static object SyncObject { get; private set; }

        /// <summary>
        /// Gets whether or not the application was restored from tombstoning.
        /// </summary>
        public static bool WasTombstoned { get; private set; }

        /// <summary>
        /// Constructor for the Application object.
        /// </summary>
        public App()
        {
            SyncObject = new object();

            // Global handler for uncaught exceptions. 
            UnhandledException += Application_UnhandledException;

            // Show graphics profiling information while debugging.
            if (System.Diagnostics.Debugger.IsAttached)
            {
                // Display the current frame rate counters
                Application.Current.Host.Settings.EnableFrameRateCounter = true;

                // Show the areas of the app that are being redrawn in each frame.
                //Application.Current.Host.Settings.EnableRedrawRegions = true;

                // Enable non-production analysis visualization mode, 
                // which shows areas of a page that are being GPU accelerated with a colored overlay.
                //Application.Current.Host.Settings.EnableCacheVisualization = true;
            }

            // Standard Silverlight initialization
            InitializeComponent();

            // Phone-specific initialization
            InitializePhoneApplication();

            // Initialize XNA dispatcher for Audio recording
            InitializeXNADispatcher();

            // Initialize a list of colors and associated names for use by the application
            InitializeColorEntries();


            TodoDC = new DataContextBase("Data Source='" + DatabaseFilename + "'" + (DatabasePassword.Length == 0 ? "" : ";Password='" + DatabasePassword + "'"));
            TodoDC.ObjectTrackingEnabled = true;
        }

        private void InitializeColorEntries()
        {
            // ROBBY: I removed black and white because they create problems with the background and red because it 
            // should be reserved for overdue. Also, I swapped out the colors to be a little more unique.
             
            ColorEntryList colorEntries = new ColorEntryList
            {                                 
                new ColorEntry { Name = ApplicationStrings.ColorRed, Color = "#FFFF0000" },            
                new ColorEntry { Name = ApplicationStrings.ColorGray, Color = "#FFD0D0D0" },
                new ColorEntry { Name = ApplicationStrings.ColorOrange, Color = "#FFFF7200"},
                new ColorEntry { Name = ApplicationStrings.ColorBlue, Color = "#FF0E68AD"},
                new ColorEntry { Name = ApplicationStrings.ColorFuchsia, Color = "#FFDA1773"},
                new ColorEntry { Name = ApplicationStrings.ColorPurple, Color = "#FF6b217E"},
                new ColorEntry { Name = ApplicationStrings.ColorGreen, Color = "#FF62A616"},
                new ColorEntry { Name = ApplicationStrings.ColorCyan, Color = "#FF109791"},
                new ColorEntry { Name = ApplicationStrings.ColorYellow, Color = "#FFFFAE00"},
                new ColorEntry { Name = ApplicationStrings.ColorMauve, Color = "#FFA186BE"},
                new ColorEntry { Name = ApplicationStrings.ColorSalmon, Color = "#FFFF835D"}
            };

            Resources.Add( UIConstants.ColorEntries , colorEntries);
        }

        private void InitializeXNADispatcher()
        {
            this.ApplicationLifetimeObjects.Add(new XNAAsyncDispatcher(TimeSpan.FromMilliseconds(50)));
        }

        // Code to execute when the application is launching (eg, from Start)
        // This code will not execute when the application is reactivated
        private void Application_Launching(object sender, LaunchingEventArgs e)
        {
            WasTombstoned = false;
            appInitialLoadPerformed = false;
            AppInitialized = false;

            Thread databaseInitializationThread = new Thread(new ThreadStart(InitializeDatabase));
            databaseInitializationThread.Start();

        }

        // Code to execute when the application is activated (brought to foreground)
        // This code will not execute when the application is first launched
        private void Application_Activated(object sender, ActivatedEventArgs e)
        {
            // Ensure that application state is restored appropriately
            if (!e.IsApplicationInstancePreserved)
            {
                WasTombstoned = true;
                App.AppInitialized = true;
                Thread initialDataLoad = new Thread(new ThreadStart(InitializeData));
                initialDataLoad.Start();
            }
            else
            {
                WasTombstoned = false;
            }
        }

        // Code to execute when the application is deactivated (sent to background)
        // This code will not execute when the application is closing
        private void Application_Deactivated(object sender, DeactivatedEventArgs e)
        {
            // Since we are deactivating, be sure to submit all changes to the database as the application may not
            // get activated again
            TodoDC.SubmitChanges();

            
        }

        // Code to execute when the application is closing (eg, user hit Back)
        // This code will not execute when the application is deactivated
        private void Application_Closing(object sender, ClosingEventArgs e)
        {
            TodoDC.SubmitChanges();
            TodoDC.Dispose();
        }

        // Code to execute if a navigation fails
        private void RootFrame_NavigationFailed(object sender, NavigationFailedEventArgs e)
        {
            LittleWatson.ReportException(e.Exception, "Navigation Failure");

            if (System.Diagnostics.Debugger.IsAttached)
            {
                // A navigation has failed; break into the debugger
                System.Diagnostics.Debugger.Break();
            }
        }

        // Code to execute on Unhandled Exceptions
        private void Application_UnhandledException(object sender, ApplicationUnhandledExceptionEventArgs e)
        {
            LittleWatson.ReportException(e.ExceptionObject, "Unhandled exception");

            if (System.Diagnostics.Debugger.IsAttached)
            {
                // An unhandled exception has occurred; break into the debugger
                System.Diagnostics.Debugger.Break();
            }
        }


        #region Phone application initialization

        // Avoid double-initialization
        private bool phoneApplicationInitialized = false;

        // Do not add any additional code to this method
        private void InitializePhoneApplication()
        {
            if (phoneApplicationInitialized)
                return;

            // Create the frame but don't set it as RootVisual yet; this allows the splash
            // screen to remain active until the application is ready to render.
            RootFrame = new PhoneApplicationFrame();

            UriMapper mapper = new UriMapper();
            mapper.UriMappings.Add(new UriMapping
            {
                Uri = new Uri("/Nearby.xaml", UriKind.Relative),
                MappedUri = new Uri("/Views/Project/ProjectsListView.xaml?nearby=true", UriKind.Relative)
            });
            RootFrame.UriMapper = mapper; 
                                                    

            RootFrame.Navigated += CompleteInitializePhoneApplication;

            // Handle navigation failures
            RootFrame.NavigationFailed += RootFrame_NavigationFailed;

            // Ensure we don't initialize again
            phoneApplicationInitialized = true;
        }

        // Do not add any additional code to this method
        private void CompleteInitializePhoneApplication(object sender, NavigationEventArgs e)
        {
            // Set the root visual to allow the application to render
            if (RootVisual != RootFrame)
                RootVisual = RootFrame;

            // Remove this handler since it is no longer needed
            RootFrame.Navigated -= CompleteInitializePhoneApplication;
        }

        #endregion

        #region Data Initialization
        private void InitializeDatabase()
        {
            if (System.Diagnostics.Debugger.IsAttached)
                Todo.Data.DataHelper.InitializeDatabase(false, App.TodoDC);
            else
                Todo.Data.DataHelper.InitializeDatabase(App.TodoDC);

            App.AppInitialized = true;
            if (null != DatabaseInitialized)
                DatabaseInitialized(this, new EventArgs());

            if (!App.appInitialLoadPerformed)
            {
                Thread initialDataLoading = new Thread(new ThreadStart(InitializeData));
                initialDataLoading.Start();
            }

        }


        public static bool IsAppDataLoaded
        {
            get
            {
                lock (SyncObject)
                {
                    return appInitialLoadPerformed;
                } 
            }
        } 

        private void InitializeData()
        {
            App.EnsureDataLoaded();

            // Synchronize the data loading procedure
            lock (SyncObject)
            {
                App.appInitialLoadPerformed = true;

                if (null != InitialDataLoaded)
                {
                    InitialDataLoaded(this, new EventArgs());
                }   
            }

            LocationService.Current.LocationUpdated += new EventHandler(Current_LocationUpdated);
            LocationService.Current.StartService(); 
            ////ALEXDEBUG!
            //Todo.Models.LocalhostSync ds = new Models.LocalhostSync();

            //ds.DownloadUploadProgress += (s, e) =>
            //    {
            //        System.Diagnostics.Debug.WriteLine((e.IsUpload ? "Uploaded " : "Downloaded ") + e.Progress + " of " + e.Total);
            //    };

            //ds.DownloadFinished += (s, e) =>
            //    {
            //        System.Diagnostics.Debug.WriteLine("Download finished!");
            //    };

            //ds.UploadFinished += (s,e) =>
            //    {
            //        System.Diagnostics.Debug.WriteLine("Upload finished!");
            //    };

            //ds.Upload("a", "a", "a"); //parameters are ignored, since we have no authorization and db name is a constant
            //ds.Download("a", "a", "a"); //parameters are ignored, since we have no authorization and db name is a constant
            
        }

        void Current_LocationUpdated(object sender, EventArgs e)
        {
            Location newLocation = LocationHelper.FindNearestMeetingThreshold(locationsViewModel.Items, LocationService.Current.Location);
            tasksViewModel.NearbyLocation = newLocation;  
        }

        // Data initialization events
        public event EventHandler<EventArgs> DatabaseInitialized;
        public event EventHandler<EventArgs> InitialDataLoaded;

        #endregion
    }
}
