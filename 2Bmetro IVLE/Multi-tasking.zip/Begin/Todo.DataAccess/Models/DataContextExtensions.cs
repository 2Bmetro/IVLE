﻿// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// This file contains additional methods for some of the data context's classes
//------------------------------------------------------------------------------

using System;
using System.Linq;
using System.ComponentModel;
using System.Collections.Specialized;
using Todo.Misc;
using System.Data.Linq;

namespace Todo
{
    public partial class Project
    {
        /// <summary>
        /// Returns all project items sorted by their due date.
        /// </summary>
        public IOrderedEnumerable<Task> ItemsByDate
        {
            get
            {
                return from task in Items
                       orderby task.DueDate.MaxOnNull()
                       select task;
            }
        }

        /// <summary>
        /// Returns all project items which are not completed, sorted by their due date.
        /// </summary>
        public IOrderedEnumerable<Task> ItemsOpen
        {
            get
            {
                return from task in Items
                       where !task.Completed
                       orderby task.DueDate.MaxOnNull()
                       select task;
            }
        }

        /// <summary>
        /// Returns all project items which are overdue, sorted by their priority.
        /// </summary>
        public IOrderedEnumerable<Task> ItemsOverdue
        {
            get
            {
                return from task in Items
                       where task.DueDate.HasValue && task.DueDate.Value.Date < DateTime.Now.Date
                       orderby task.Priority
                       select task;
            }
        }

        /// <summary>
        /// Returns all project items which are of high priority, sorted by their due date.
        /// </summary>
        public IOrderedEnumerable<Task> ItemsUrgent
        {
            get
            {
                return from task in Items
                       where task.Priority == PriorityValue.High
                       orderby task.DueDate.MaxOnNull()
                       select task;
            }
        }

        /// <summary>
        /// The total amount of items contained in the project.
        /// </summary>
        public int TotalItemCount
        {
            get
            {
                return Items.Count;
            }
        }

        /// <summary>
        /// The amount of open items in the project.
        /// </summary>
        public int OpenItemCount
        {
            get
            {
                return Items.Where(item => item.Completed != true).Count();
            }
        }

        /// <summary>
        /// The amount of overdue items in the project.
        /// </summary>
        public int OverdueItemCount
        {
            get
            {
                return Items.Where(item => item.DueDate.HasValue && item.DueDate.Value.Date < DateTime.Now.Date &&
                    item.Completed == false).Count();
            }
        }

        /// <summary>
        /// The amount of high priority items in the project.
        /// </summary>
        public int HighPriorityItemCount
        {
            get
            {
                return Items.Where(item => item.Priority == PriorityValue.High).Count();
            }
        }

        /// <summary>
        /// Fires notification events indicating the counts for open/total/overdue items may have been updated.
        /// </summary>
        public void SendItemCountUpdates()
        {
            Items_CollectionChanged(this, null);
        }

        partial void OnCreated()
        {
            // Register for item set changes to fire changes for the item count properties
            Items.CollectionChanged += Items_CollectionChanged;
        }

        partial void OnValidate(ChangeAction action)
        {
            if (action == ChangeAction.Delete)
            {
                Items.CollectionChanged -= Items_CollectionChanged;
            }
        }

        /// <summary>
        /// Goes over all items contained in the project and registers to their property notifications.
        /// This will cause the project to update in accordance to item changes.
        /// </summary>
        public void InitializeItemNotifications()
        {
            foreach (Task task in Items)
            {
                task.PropertyChanged += projectTaskPropertyChanged;
            }
        }

        public override string ToString()
        {
            return Name;
        }

        private void Items_CollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            if (e.Action == System.Collections.Specialized.NotifyCollectionChangedAction.Add)
            {
                foreach (Task task in e.NewItems)
                {
                    task.PropertyChanged += projectTaskPropertyChanged;
                }
            }
            else if (e.Action == System.Collections.Specialized.NotifyCollectionChangedAction.Remove)
            {
                foreach (Task task in e.OldItems)
                {
                    task.PropertyChanged -= projectTaskPropertyChanged;
                }
            }

            NotifyItemRelatedProperties();
        }

        private void NotifyItemRelatedProperties()
        {
            SendPropertyChanged("OpenItemCount");
            SendPropertyChanged("HighPriorityItemCount");
            SendPropertyChanged("TotalItemCount");
            SendPropertyChanged("OverdueItemCount");
            SendPropertyChanged("ItemsOverdue");
            SendPropertyChanged("ItemsOpen");
            SendPropertyChanged("ItemsUrgent");
            SendPropertyChanged("ItemsByDate");
        }

        private void projectTaskPropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == "Completed")
            {
                SendPropertyChanged("OpenItemCount");
                SendPropertyChanged("OverdueItemCount");
                SendPropertyChanged("ItemsOverdue");
                SendPropertyChanged("ItemsOpen");
            }
            else if (e.PropertyName == "Priority")
            {
                SendPropertyChanged("HighPriorityItemCount");
                SendPropertyChanged("ItemsUrgent");
            }
            else if (e.PropertyName == "DueDate")
            {
                SendPropertyChanged("ItemsOverdue");
                SendPropertyChanged("ItemsOpen");
                SendPropertyChanged("ItemsUrgent");
                SendPropertyChanged("ItemsByDate");
                SendPropertyChanged("OverdueItemCount");
            }
        }
    }

    public partial class Task
    {
        partial void OnCreated()
        {
            // Register for property changes
            PropertyChanged += Items_PropertyChanged;
        }

        partial void OnValidate(ChangeAction action)
        {
            if (action == ChangeAction.Delete)
            {
                // Unregister from all property notifications to prevent unwanted UI updates
                PropertyChanged = null;
            }
        }

        private void Items_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            // See if the Status has changed, and if so update the "Completed" property
            if (e.PropertyName == "Status" )
            {
                if (Status == TaskStatus.Completed)
                {
                    Completed = true;
                }
                else
                {
                    Completed = false;
                }
            }
        }

        partial void OnCompletedChanged()
        {
            if (Completed)
            {
                Status = TaskStatus.Completed;
            }
            else
            {
                Status = TaskStatus.InProgress;
            }
        }
    }    
}