﻿// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.IO.IsolatedStorage;
using System.IO;
using Microsoft.Phone.Data.Linq;
using System.Linq;
using System.Collections.Generic;
using Todo.Misc;
using Todo.Resources;

namespace Todo.Data
{
    public class DataHelper
    {
        public static void InitializeDatabase(DataContextBase todo)
        {
            using (IsolatedStorageFile iso = IsolatedStorageFile.GetUserStoreForApplication())
            {
                if (iso.FileExists("ToDo.sdf"))
                    return;

                CreateDatabase(todo);
            }
        }

        public static void InitializeDatabase(bool wipe, DataContextBase todo)
        {
            using (IsolatedStorageFile iso = IsolatedStorageFile.GetUserStoreForApplication())
            {
                if (wipe)
                    WipeDatabase(iso);
                else
                {
                    if (iso.FileExists("ToDo.sdf"))
                        return;
                }

                CreateDatabase(todo);
            }
        }
        
        //DEMOSTOP#2 
        private static void CreateDatabase(DataContextBase todo)
        {
            try
            {
                // Generate the database (with structure) from the code-based data context
                todo.CreateDatabase();

                // Populate the database with system data
                GenerateSystemData(todo);

                // Create a default "Hello 'ToDo' note" -- OPTIONAL
                Task items = new Task();
                items.Id = Guid.NewGuid();
                items.Title = "Welcome to the \"Todo\"!";
                items.LocationID = new Guid(Utils.LocationIDDefault); 
                items.Completed = true;
                todo.Items.InsertOnSubmit(items);

                todo.SubmitChanges();                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while creating the DB: " + ex.Message);
                System.Diagnostics.Debug.WriteLine("Error while creating the DB: " + ex.Message);
            }

        }

        private static void GenerateSystemData(DataContextBase todo)
        {            
            //Add projects
            Project project = new Project();
            project.Id = new Guid(Utils.ProjectIDDefault);
            project.Name =  LocalizedStrings.DefaultProjectName;
            project.Description = LocalizedStrings.DefaultProjectDescription;

            project.Color = Colors.Gray.ToString();
            todo.Projects.InsertOnSubmit(project);


            List<Location> locations = new List<Location>(); 
            Location location = new Location ();
 
            location = new Location();
            location.Id = new Guid(Utils.LocationIDDefault); 
            location.Name = LocalizedStrings.DefaultLocationName;
            location.Description = LocalizedStrings.DefaultLocationDescription; 
            location.Latitude = 0;
            location.Longitude = 0;            
            locations.Add(location);


            location = new Location(); 
            location.Id = Guid.NewGuid();
            location.Name = "Work";
            location.Address = "One Microsoft Way";
            location.Description = location.Address; 
            location.City = "Redmond";
            location.State = "WA";
            location.Latitude = 47.639767;
            location.Longitude = -122.129755; 
            location.ZipCode = "98052";   
            locations.Add(location);
 
            location = new Location();
            location.Id = Guid.NewGuid();
            location.Name = "Home";
            location.Address = "123 Main";
            location.Description = "123 Main  Seattle, WA"; 
            location.City = "Seattle";
            location.State = "WA";
            location.Latitude = 47.599903;
            location.Longitude = -122.333728;
            location.ZipCode = "98104";
            locations.Add(location);
          
            todo.Locations.InsertAllOnSubmit (locations); 


            //Add attachment types
            List<AttachmentType> attachmentTypes = new List<AttachmentType>();
            AttachmentType attachmentType = new AttachmentType();
            attachmentType.Id = new Guid(Utils.AttachmentTypeIDText);
            attachmentType.Name = "Text";
            attachmentTypes.Add(attachmentType);

            attachmentType = new AttachmentType();
            attachmentType.Id = new Guid(Utils.AttachmentTypeIDImage);
            attachmentType.Name = "Image";
            attachmentTypes.Add(attachmentType);

            attachmentType = new AttachmentType();
            attachmentType.Id = new Guid(Utils.AttachmentTypeIDVoice);
            attachmentType.Name = "Voice";
            attachmentTypes.Add(attachmentType);
            todo.AttachmentType.InsertAllOnSubmit(attachmentTypes);
            
            //Submit
            try
            {

                todo.SubmitChanges();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message); 
            } 
        }

        public static void WipeDatabase(IsolatedStorageFile iso)
        {
            if (iso.FileExists("ToDo.sdf"))
                iso.DeleteFile("ToDo.sdf");
        }

        public static bool DatabaseExists(bool overrideResult = false)
        {
            if (!overrideResult)
            {
                using (IsolatedStorageFile iso = IsolatedStorageFile.GetUserStoreForApplication())
                {
                    if (iso.FileExists("ToDo.sdf"))
                        return true;
                    else
                        return false;
                }
            }
            else
                return false;
        }
    }
}
