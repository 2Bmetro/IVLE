﻿// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.ComponentModel;
using Microsoft.Phone.Scheduler;
using Todo.Resources;
using System.Data.Linq;
using System.Collections.Generic;
using System.Reflection;
using Todo.Interfaces;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;

namespace Todo.Misc
{
    public static class Utils
    {
        #region Consts
        public const string AttachmentTypeIDImage = "abdd119e-994a-41a8-8b31-0a13ee8457a3";
        public const string AttachmentTypeIDText = "42c40d46-f989-48f5-a578-83aef91a9b8b";
        public const string AttachmentTypeIDVoice = "5fab358b-5a4d-4f8f-a3f8-eaba26787596";
        public const string PriorityIDLow = "a57b2fef-7adc-4bb3-8dc4-f6f26401a039";
        public const string PriorityIDNormal = "8ea145fb-f58f-46e8-a222-3c49ff37883a";
        public const string PriorityIDHigh = "35406517-6b86-4599-897c-c9804de9fae1";
        public const string ProjectIDDefault = "562090ea-d7db-4433-aabd-946ccfa8dab0";
        public const string StatusIDNotStarted = "5e4a5162-9910-4a08-9db7-199e04801faa";
        public const string StatusIDInProgress = "2bcaa96e-2461-443c-8bd1-ad4aef55cea9";
        public const string StatusIDCompleted = "d34ea57b-4092-46a1-a215-44bc9aa3ecb1";
        public const string StatusIDWaiting = "123f287b-198e-4b85-b2d1-5a045c8282cc";
        public const string StatusIDDeferred = "5ec5f353-078f-4c2b-b541-45eade3d3762";
        public const string LocationIDDefault = "7FC90001-DC92-495C-8C1D-A9A20A58561A" ;  

        public const int maxRecordingDuration = 60;
        #endregion

        #region Enums
        public enum MainViewAppBarButtons : int
        {
            NewTask = 0,
            Projects = 1,
            Settings = 2
        }

        public enum TaskViewAppBarButtons : int
        {
            Edit = 0,
            Delete = 1,
            AddImage = 2,
            AddVoice = 3
        }

        public enum EditTaskViewAppBarButtons : int
        {
            Save = 0,
            Cancel = 1,
            AddImage = 2,
            AddVoice = 3
        }

        public enum ImageAttachmentViewAppBarButtons : int
        {
            Add = 0,
            Cancel = 1
        }

        public enum ImageViewAppBarButtons : int
        {
            Save = 0,
            Cancel = 1,
            Delete = 2
        }

        public enum VoiceAttachmentViewAppBarButtons : int
        {
            Save = 0,
            Cancel = 1,
            Delete = 2
        }

        public enum EditTaskViewAppBarMenuItems
        {
            AddReminder,
            About = 1
        }

        public enum ProjectListViewAppBarButtons : int
        {
            NewProject = 0
        }

        public enum ProjectDetailsViewAppBarButtons : int
        {
            EditProject = 0,
            PinProject = 1,
            DeleteProject = 2
        }

        public enum ProjectItemsViewAppBarButtons : int
        {
            NewItem = 0
        }

        public enum ProjectEditViewAppBarButtons : int
        {
            Save = 0,
            Cancel = 1
        }

        public enum LocationEditViewAppBarButtons : int 
        {
            Save = 0 , 
            Cancel = 1 , 
            Geocode = 2 
        } 
        public enum TaskEditViewAppBarButtons : int
        {
            Save = 0,
            Cancel = 1
        }

        public enum NoteAttachmentViewAppBarButtons : int
        {
            Save = 0,
            Cancel = 1,
            Delete = 2
        }

        public enum AboutAppBarButtons : int
        {
            OK = 0
        }

        public enum GeneralAppBarMenuItems
        {            
            Settings = 0, 
            // About = 1 , 
            Location = 1 , 
        }

        public enum LocationListViewButtons
        {
            NewTask = 0,
        }

        public enum LocationListViewMenuItems
        {
            Settings = 0,
        }
        #endregion

        #region Property Change Notification
        /// <summary>
        /// Raise an event indicating a property change.
        /// </summary>
        /// <param name="propertyName">The name of the property.</param>
        /// <param name="sender">The event sender.</param>
        /// <param name="PropertyChanged">The event handler.</param>
        public static void RaisePropertyChanged(string propertyName, object sender, PropertyChangedEventHandler PropertyChanged)
        {
            Deployment.Current.Dispatcher.BeginInvoke(() =>
                {
                    PropertyChangedEventHandler handler = PropertyChanged;
                    if (null != handler)
                        handler(sender, new PropertyChangedEventArgs(propertyName));
                });
        }
        #endregion

        #region Extension Methods        

        /// <summary>
        /// Returns the date time value, or the maximal date time value if the value is null.
        /// </summary>
        /// <param name="dateTime">The date time to examine.</param>
        /// <returns>The date time value, or the maximal date time value if the value is null.</returns>
        public static DateTime MaxOnNull(this DateTime? dateTime)
        {
            return dateTime.HasValue ? dateTime.Value : DateTime.MaxValue;
        }

        /// <summary>
        /// Checks whether a certain data context contains pending changes or not.
        /// </summary>
        /// <param name="dataContext">The data context to test for pending changes.</param>
        /// <returns>True if there are pending changes and false otherwise.</returns>
        public static bool HasPendingChanges(this DataContext dataContext)
        {
            ChangeSet pendingChanges = dataContext.GetChangeSet();

            if (pendingChanges.Deletes.Count > 0 || pendingChanges.Inserts.Count > 0 ||
                pendingChanges.Updates.Count > 0)
            {
                return true;
            }

            return false;
        }

        /// <summary>
        /// Rolls back all of the data context's pending changes.
        /// </summary>
        /// <param name="dataContext">The data context for which to perform the rollback.</param>
        /// <remarks>Assumes that all data objects implement IPropertyChangedNotifier.</remarks>
        public static void RollBack(this DataContext dataContext)
        {
            ChangeSet pendingChanges = dataContext.GetChangeSet();

            // Discard insertions and deletions by performing the opposite operation
            foreach (var insertion in pendingChanges.Inserts)
            {
                dataContext.GetTable(insertion.GetType()).DeleteOnSubmit(insertion);
            }

            foreach (var deletion in pendingChanges.Deletes)
            {
                dataContext.GetTable(deletion.GetType()).DeleteOnSubmit(deletion);
            }

            // Discard updates by refreshing the objects from the database
            foreach (var update in pendingChanges.Updates)
            {
                dataContext.Refresh(RefreshMode.OverwriteCurrentValues, update);

                // Since this sets private fields directly, we must go over all properties and fire change 
                // notifications
                IPropertyChangedNotifier updateNotify = update as IPropertyChangedNotifier;

                foreach (PropertyInfo propertyInfo in update.GetType().GetProperties())
                {
                    updateNotify.SendPropertyChanged(propertyInfo.Name);
                }
            }
        }

              

        #endregion

 
    }
}
