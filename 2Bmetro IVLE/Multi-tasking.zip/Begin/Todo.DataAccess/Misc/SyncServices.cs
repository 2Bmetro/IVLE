﻿// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Todo.Misc
{
    public enum SyncFrequency
    {
        Daily,
        Weekly,
        Manual
    }

    public class DownloadUploadFinishedEventArgs : EventArgs
    {
        public DownloadUploadFinishedEventArgs()
        {
        }
    }

    public class DownloadUploadProgressEventArgs : EventArgs
    {
        private long progress, total;
        private bool isUpload;

        public DownloadUploadProgressEventArgs(bool isUpload, long progress, long total)
        {
            this.progress = progress;
            this.total = total;
            this.isUpload = isUpload;
        }

        public long Progress
        {
            get { return progress; }
        }

        public long Total
        {
            get { return total; }
        }

        public bool IsUpload
        {
            get { return isUpload; }
        }
    }
}
