﻿// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Todo.Views;
using Todo.Data;
using Todo.Misc;
using Microsoft.Phone.Shell;
using Todo.Resources;

namespace Todo
{
    public partial class MainView : TodoAppPage
    {
        // Constructor
        public MainView()
        {
            InitializeComponent();

            InitializeAppBarText();

            DataContext = App.TasksViewModel;
        }

        protected override void OnNavigatedTo(System.Windows.Navigation.NavigationEventArgs e)
        {
            //Take special care of being navigated to after resuming from a reminder
            if (NavigationContext.QueryString.ContainsKey(UIConstants.ModeQueryParam))
            {
                NavigationService.RemoveBackEntry();
            }

            if (RegisterForInitialDataLoadCompleted(RestoreState))
            {
                pivot.IsEnabled = false;
                ApplicationBar.IsVisible = false;
            }
            else
            {
                lock (App.SyncObject)
                {
                    // When launching the application, we want to allow all data to load before letting the user
                    // interact with the application
                    if (!App.IsAppDataLoaded)
                    {
                        pivot.IsEnabled = false;
                        ApplicationBar.IsVisible = false;
                        (App.Current as App).InitialDataLoaded += EnablePage;
                    }
                }
            }

            base.OnNavigatedTo(e);
        }

        protected override void OnNavigatedFrom(System.Windows.Navigation.NavigationEventArgs e)
        {
            if (!e.IsNavigationInitiator)
            {
                StoreState();
            }

            base.OnNavigatedFrom(e);
        }

        protected override void StoreState()
        {
            State[UIConstants.RestoreStatePivotIndex] = pivot.SelectedIndex;

            base.StoreState();
        }

        protected override void RestoreState(object sender, EventArgs args)
        {
            Dispatcher.BeginInvoke(() =>
                {
                    if ( State.Keys.Contains(UIConstants.RestoreStatePivotIndex))
                        pivot.SelectedIndex = (int)State[UIConstants.RestoreStatePivotIndex];
                    else if ( !string.IsNullOrEmpty(NavigationContext.SafeGetQueryParam( Constants.NEARBYQUERYPARAM)))
                    {
                        pivot.SelectedIndex = UIConstants.NearbyPivotIndex; 
                    } 

                    pivot.IsEnabled = true;
                    ApplicationBar.IsVisible = true;
                });

            base.RestoreState(sender, args);
        }

        private void EnablePage(object sender, EventArgs args)
        {
            Dispatcher.BeginInvoke(() =>
            {
                pivot.IsEnabled = true;
                ApplicationBar.IsVisible = true;
            });
        } 

            
           

        private void appBar_OnNewTask(object sender, EventArgs e)
        {
            NavigationService.Navigate(UIConstants.MakeDefaultProjectEditTaskViewUri()); 

               
        }

        private void appBar_OnSettings(object sender, EventArgs e)
        {
            NavigationService.Navigate(UIConstants.SettingsView);
        }       

        private void appBar_OnAbout(object sender, EventArgs e)
        {
            NavigationService.Navigate(UIConstants.AboutView);
        }

        private void appBar_OnProjects(object sender, EventArgs e)
        {
            NavigationService.Navigate(UIConstants.ProjectListView);
        }


        private void appBar_OnLocation(object sender, EventArgs e)
        {
            NavigationService.Navigate(UIConstants.LocationsListView);
        }

        private void InitializeAppBarText()
        {
            ((ApplicationBarIconButton)ApplicationBar.Buttons[(int)Utils.MainViewAppBarButtons.NewTask]).Text = ApplicationStrings.appBar_NewTask;
            ((ApplicationBarIconButton)ApplicationBar.Buttons[(int)Utils.MainViewAppBarButtons.Projects]).Text = ApplicationStrings.appBar_Projects;            
            ((ApplicationBarMenuItem)ApplicationBar.MenuItems[(int)Utils.GeneralAppBarMenuItems.Settings]).Text = ApplicationStrings.appBar_Settings;
            ((ApplicationBarMenuItem)ApplicationBar.MenuItems[(int)Utils.GeneralAppBarMenuItems.Location]).Text = ApplicationStrings.appBar_Location;
        }

        // Handler for the task template's checkbox
        private void CompleteBoxClicked(object sender, RoutedEventArgs e)
        {
            CheckBox checkbox = sender as CheckBox;

            Task item = checkbox.DataContext as Task;

            item.Completed = checkbox.IsChecked.Value;

            // Update the model data
            App.TasksViewModel.Update(item);
        }

        // Handler for tapping task items
        private void TaskTapped(object sender, System.Windows.Input.GestureEventArgs e)
        {
            Task item = (sender as FrameworkElement).DataContext as Task;

            NavigationService.Navigate(UIConstants.MakeTaskViewUri(item)); 
                    
                   
        }
    }
}
