﻿// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Todo.Resources;
using Microsoft.Phone.Shell;
using Todo.Misc;
using System.Windows.Media.Imaging;

namespace Todo.Views
{
    public partial class ProjectDetailsView : TodoAppPage
    {
        
        private bool pageInitialized;

        public ProjectDetailsView()
        {
            InitializeComponent();
            InitializeAppBarText();
            pageInitialized = false;
        }

        /// <summary>
        /// Extracts the project ID of the project to display from the navigation string and sets the desired project
        /// as the page's data source.
        /// </summary>
        /// <param name="e"></param>
        protected override void OnNavigatedTo(System.Windows.Navigation.NavigationEventArgs e)
        {
            if (RegisterForInitialDataLoadCompleted(InitializePageAfterDataLoaded))
            {
                ApplicationBar.IsVisible = false;
            }
            else
            {
                InitializePage();
            }

            base.OnNavigatedTo(e);
        }

        void InitializePageAfterDataLoaded(object sender, EventArgs e)
        {
            Dispatcher.BeginInvoke(() =>
                {
                    InitializePage();
                });
        }

        private void InitializePage()
        {
            if (!pageInitialized)
            {

                Guid projectID = NavigationContext.GetGuidParam(UIConstants.ProjectIdQueryParam);
                DataContext = App.ProjectsViewModel.Items.FirstOrDefault(p => p.Id == projectID);

                if ((DataContext as Project).OverdueItemCount > 0)
                {
                    textOverdueCount.Foreground = new SolidColorBrush(Colors.Red);
                    textOverdueDescription.Foreground = new SolidColorBrush(Colors.Red);
                }

                // If we are looking at the default project, disable the deletion button
                if (projectID == new Guid(Utils.ProjectIDDefault))
                {
                    ((ApplicationBarIconButton)ApplicationBar.Buttons[(int)Utils.ProjectDetailsViewAppBarButtons.DeleteProject]).IsEnabled = false;
                }

                

                UpdateProjectPinIcons();
                ApplicationBar.IsVisible = true;
                pageInitialized = true;
            }
        }

        private void UpdateProjectPinIcons()
        {
            // Implement me as well!
        } 

        private void appBar_OnDeleteProject(object sender, EventArgs e)
        {
            if (pageInitialized)
            {
                if (MessageBox.Show(ApplicationStrings.Msg_ProjectDelete, ApplicationStrings.MsgTitle_ProjectDelete,
                    MessageBoxButton.OKCancel) == MessageBoxResult.OK)
                {
                    App.ProjectsViewModel.Delete((DataContext as Project).Id);

                    NavigationService.GoBack();
                }
            }
        }

        private void appBar_OnEditProject(object sender, EventArgs e)
        {
            if (pageInitialized)
            {
                NavigationService.Navigate(UIConstants.MakeEditProjectUri(this.DataContext as Project));
            }
        }
        

        private void appBar_OnSettings(object sender, EventArgs e)
        {
            NavigationService.Navigate(UIConstants.SettingsView);
        }

        //TODO 
        private void ItemsTapped(object sender, System.Windows.Input.GestureEventArgs e)
        {
            NavigationService.Navigate( UIConstants.MakeViewProjectUri ( this.DataContext as Project )  );
        }

        private void InitializeAppBarText()
        {
            ((ApplicationBarIconButton)ApplicationBar.Buttons[(int)Utils.ProjectDetailsViewAppBarButtons.EditProject]).Text = ApplicationStrings.appBar_Edit;            
            ((ApplicationBarIconButton)ApplicationBar.Buttons[(int)Utils.ProjectDetailsViewAppBarButtons.PinProject]).Text = ApplicationStrings.appBar_Pin;
            ((ApplicationBarIconButton)ApplicationBar.Buttons[(int)Utils.ProjectDetailsViewAppBarButtons.DeleteProject]).Text = ApplicationStrings.appBar_Delete;
            ((ApplicationBarMenuItem)ApplicationBar.MenuItems[(int)Utils.GeneralAppBarMenuItems.Settings]).Text = ApplicationStrings.appBar_Settings;
            ((ApplicationBarMenuItem)ApplicationBar.MenuItems[(int)Utils.GeneralAppBarMenuItems.Location]).Text = ApplicationStrings.appBar_Location;
        }

        private void appBar_OnSettingsClick(object sender, EventArgs e)
        {
            StoreState();
            base.OnAppBarSettingsClick(sender, e);
        }


        private void appBar_OnLocationClick(object sender, EventArgs e)
        {
            StoreState();
            base.OnAppBarLocationClick(sender, e);
        }

        

        private void appBar_OnPinProject(object sender, EventArgs e)
        {
            // Implement me!
        }

        private void OnHighPrioDrillDown(object sender, System.Windows.Input.GestureEventArgs e)
        {
            NavigationService.Navigate(UIConstants.MakeProjectItemsViewUri(DataContext as Project)); 
        }



    }
}
