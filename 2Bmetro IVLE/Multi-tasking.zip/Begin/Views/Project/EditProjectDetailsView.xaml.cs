﻿// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Todo.Misc;
using Microsoft.Phone.Shell;
using Todo.Resources;
using Todo.Models;
using System.Windows.Navigation;

namespace Todo.Views
{
    public partial class EditProjectDetailsView : EntityEditingPage
    {
        private bool newProjectCreated;
        private Project project;

        private bool pageInitialized;

        public EditProjectDetailsView()
        {
            InitializeComponent();
            InitializeAppBarText();
            pageInitialized = false;            
        }

        /// <summary>
        /// Initializes the page with project information when the user navigates to it.
        /// </summary>
        /// <param name="e"></param>
        protected override void OnNavigatedTo(System.Windows.Navigation.NavigationEventArgs e)
        {
            if (NavigationContext.QueryString.ContainsKey(UIConstants.ProjectIdQueryParam))
            {
                // Populate the dialog with data from the project being edited
                newProjectCreated = false;

                if (RegisterForInitialDataLoadCompleted(
                    InitializePageAfterDataLoaded, GetProjectAfterDataLoaded, RestoreState))
                {
                    ApplicationBar.IsVisible = false;
                }
                else
                {
                    SetSources();
                    GetProjectFromQueryString();
                    DataContext = project;
                }
            }
            else
            {
                // Create a new project
                newProjectCreated = true;

                project = new Project();
                project.Id = Guid.NewGuid();


                
                string defaultColorString = ((ColorEntryList)Application.Current.Resources["ColorEntries"]).First().Color; 

                project.Color = defaultColorString;

                if (RegisterForInitialDataLoadCompleted(InitializePageAfterDataLoaded, RestoreState))
                {
                    ApplicationBar.IsVisible = false;
                }
                else
                {
                    SetSources();
                    DataContext = project;
                }
            }

            base.OnNavigatedTo(e);
        }

        private void GetProjectAfterDataLoaded(object sender, EventArgs e)
        {
            Dispatcher.BeginInvoke(() =>
            {
                GetProjectFromQueryString();
            });
        }

        private void GetProjectFromQueryString()
        {
            Guid projectGuid = NavigationContext.GetGuidParam(UIConstants.ProjectIdQueryParam); 
            project = App.ProjectsViewModel.Items.FirstOrDefault(proj => proj.Id == projectGuid);
        }

        private void SetSources()
        {
            if (!pageInitialized)
            {
                pageInitialized = true;
                listColors.ItemsSource = App.Current.Resources["ColorEntries"] as ColorEntryList;
                listDefaultDueDate.ItemsSource = MetaData.DefaultDueDateValues;
                listDefaultPriority.ItemsSource = MetaData.PriorityValues;
            }
        }

        void InitializePageAfterDataLoaded(object sender, EventArgs e)
        {
            Dispatcher.BeginInvoke(() =>
            {
                SetSources();
                ApplicationBar.IsVisible = true;
            });
        }

        private void appBar_OnAbout(object sender, EventArgs e)
        {
            StoreState();
            NavigationService.Navigate(UIConstants.AboutView);
        }

        private void appBar_OnSave(object sender, EventArgs e)
        {
            // If we did not remove focus from the name box, binding did not update the value yet
            project.Name = textProjectName.Text;
            project.Description = textProjectDescription.Text;  

            if (String.IsNullOrEmpty(project.Name))
            {
                MessageBox.Show(ApplicationStrings.Msg_EmptyProjectName);
                return;
            }

            // Save the new project
            if (newProjectCreated)
            {
                // Check if there are existing projects with the same name
                Project sameNameProject = App.ProjectsViewModel.Items.FirstOrDefault(proj => proj.Name == project.Name);

                if (sameNameProject != null &&
                    MessageBox.Show(ApplicationStrings.Msg_ProjectSameNameSave, ApplicationStrings.MsgTitle_ProjectSameNameSave,
                    MessageBoxButton.OKCancel) == MessageBoxResult.Cancel)
                {
                    return;
                }

                App.ProjectsViewModel.Insert(project);
            }
            // Update the existing project
            else
            {
                // Check if there are existing projects with the same name
                Project sameNameProject = App.ProjectsViewModel.Items.FirstOrDefault(
                    proj => proj.Name == project.Name && proj.Id != project.Id);

                if (sameNameProject != null &&
                    MessageBox.Show(ApplicationStrings.Msg_ProjectSameNameEdit, ApplicationStrings.MsgTitle_ProjectSameNameEdit,
                    MessageBoxButton.OKCancel) == MessageBoxResult.Cancel)
                {
                    return;
                }

                App.ProjectsViewModel.Update(project);
            }

            
            NavigationService.GoBack();
        }

        
        protected override void StoreState()
        {
            State["Name"] = textProjectName.Text;
            State["Description"] = textProjectDescription.Text;
            State["Color"] = (listColors.SelectedItem as ColorEntry).Color.ToString();
            State["DefaultDueDate"] = listDefaultDueDate.SelectedItem;
            State["DefaultPriority"] = listDefaultPriority.SelectedIndex;
        }

        protected override void RestoreState(object sender, EventArgs e)
        {
            Dispatcher.BeginInvoke(() =>
            {
                project.Name = State["Name"].ToString();
                project.Description = State["Description"].ToString();
                project.Color = State["Color"].ToString();
                project.DefaultDueDate = (DefaultDueDate)State["DefaultDueDate"];
                project.DefaultPriority = (PriorityValue)State["DefaultPriority"];

                DataContext = project;
            });
        }

        private void appBar_OnCancel(object sender, EventArgs e)
        {
            NavigationService.GoBack();
        }

        protected override void OnNavigatingFrom(NavigatingCancelEventArgs e)
        {
            // If we did not remove focus from the name/description box, binding did not update the value yet
            base.OnNavigatingFrom(e);
        }

        private void appBar_OnSettingsClick (object sender, EventArgs e)
        {
            StoreState();
            base.OnAppBarSettingsClick(sender, e); 
        }

        protected override void OnBackKeyPress(System.ComponentModel.CancelEventArgs e)
        {
            if (project.Name != textProjectName.Text ||
                project.Description != textProjectDescription.Text)
            {
                if (MessageBox.Show(ApplicationStrings.Msg_DiscardChanges, ApplicationStrings.MsgTitle_DiscardChanges,
                     MessageBoxButton.OKCancel) == MessageBoxResult.Cancel)
                {
                    e.Cancel = true;
                }  
            } 
  
             base.OnBackKeyPress(e);
        }

        private void appBar_OnLocationClick(object sender, EventArgs e)
        {
            StoreState(); 
            base.OnAppBarLocationClick(sender, e);
        }

        private void InitializeAppBarText()
        {
            ((ApplicationBarIconButton)ApplicationBar.Buttons[(int)Utils.ProjectEditViewAppBarButtons.Save]).Text = ApplicationStrings.appBar_Save;
            ((ApplicationBarIconButton)ApplicationBar.Buttons[(int)Utils.ProjectEditViewAppBarButtons.Cancel]).Text = ApplicationStrings.appBar_Cancel;
            ((ApplicationBarMenuItem)ApplicationBar.MenuItems[(int)Utils.GeneralAppBarMenuItems.Settings]).Text = ApplicationStrings.appBar_Settings;
            ((ApplicationBarMenuItem)ApplicationBar.MenuItems[(int)Utils.GeneralAppBarMenuItems.Location]).Text = ApplicationStrings.appBar_Location;
        }
    }
}