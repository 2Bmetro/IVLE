﻿// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using Todo.Data;
using System.ComponentModel;
using Todo.Misc;
using System.Collections.Generic;
using System.Windows.Navigation;

namespace Todo.Views
{
    /// <summary>
    /// A base class for all of the application's pages. This will cause all pages to initialize
    /// the database connection upon loading if the connection has yet to be established.
    /// </summary>
    public class TodoAppPage : PhoneApplicationPage
    {
        ProgressIndicator progressIndicator;

        protected List<EventHandler<EventArgs>> InitialDataHandlers { get; set; }

        /// <summary>
        /// Registers for the page's load event.
        /// </summary>
        public TodoAppPage()
        {
            if (DesignerProperties.IsInDesignTool)
            {
                // We do not want to perform initialization in design time
                return;
            }

            InitialDataHandlers = new List<EventHandler<EventArgs>>();

            // Subscribe to Database initialization event and change progress indicator if was turned on
            (Application.Current as App).DatabaseInitialized += TodoAppPage_DatabaseInitialized;

            // Subscribe to data loaded event and hide the progress indicator if was turned on
            (Application.Current as App).InitialDataLoaded += TodoAppPage_InitialDataLoaded;

            Loaded += OnPageLoaded;

            if (!App.IsAppDataLoaded)
            {
                // Show "Loading..." in the system tray if either database were not initialized or data were not loaded
                progressIndicator = new Microsoft.Phone.Shell.ProgressIndicator();
                Microsoft.Phone.Shell.SystemTray.SetIsVisible(this, true);
                Microsoft.Phone.Shell.SystemTray.SetProgressIndicator(this, progressIndicator);
                progressIndicator.Text = App.AppInitialized ? "Loading" : "Initializing database";
                progressIndicator.IsIndeterminate = true;
                progressIndicator.IsVisible = true;
            }
        }

        private void TodoAppPage_InitialDataLoaded(object sender, EventArgs e)
        {
            Deployment.Current.Dispatcher.BeginInvoke(() =>
            {
                if (null != progressIndicator)
                {
                    // Hide the system tray
                    progressIndicator.IsVisible = false;
                }

                SystemTray.SetIsVisible(this, false);

                // Check for and report any crashes
                LittleWatson.CheckForPreviousException();
            });
        }

        private void TodoAppPage_DatabaseInitialized(object sender, EventArgs e)
        {
            Deployment.Current.Dispatcher.BeginInvoke(() =>
            {
                if (null != progressIndicator)
                {
                    progressIndicator.Text = "Loading";
                }
            });
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            // If no initial data loading events have been registered (assuming they always take
            // care to restore the state) then we should restore the state directly
            if (e.NavigationMode == NavigationMode.Back && InitialDataHandlers.Count == 0)
            {
                RestoreState(this, null);
            }

            base.OnNavigatedTo(e);
        }

        protected override void OnNavigatedFrom(System.Windows.Navigation.NavigationEventArgs e)
        {
            (Application.Current as App).DatabaseInitialized -= TodoAppPage_DatabaseInitialized;
            (Application.Current as App).InitialDataLoaded -= TodoAppPage_InitialDataLoaded;
            Loaded -= OnPageLoaded;

            // Unregister all tombstoning handlers when navigating away from the page
            foreach (EventHandler<EventArgs> dataLoadedHandler in InitialDataHandlers)
            {
                (Application.Current as App).InitialDataLoaded -= dataLoadedHandler;
            }

            // Store the state unless "exiting" the page
            if (e.NavigationMode != NavigationMode.Back)
            {
                StoreState();
            }

            base.OnNavigatedFrom(e);
        }

        protected virtual void OnPageLoaded(object sender, RoutedEventArgs e)
        {
            // Show the system tray if data is being loaded
            if (!App.IsAppDataLoaded)
            {
                if (!SystemTray.GetIsVisible(this))
                {
                    SystemTray.SetIsVisible(this, true);
                }
            }
        }

        /// <summary>
        /// Checks whether or not the application's state indicates that the application has returned from tombstoning
        /// and has yet to load its data. If so, the supplied handlers are registered to the application's data loading event.
        /// </summary>
        /// <param name="args">Page's navigation arguments.</param>
        /// <param name="handlers">Handlers to register to the application's event which indicates all data has been
        /// loaded.</param>
        /// <returns>True if the application has indeed returned from tombstoning and false otherwise.</returns>
        public bool RegisterForInitialDataLoadCompleted(params EventHandler<EventArgs>[] handlers)
        {
            lock (App.SyncObject)
            {
                //TODO: Removing the App.WasTombstoned check.. 
                if (!App.IsAppDataLoaded /* && App.WasTombstoned*/ )
                {
                    foreach (EventHandler<EventArgs> handler in handlers)
                    {
                        InitialDataHandlers.Add(handler);
                        (App.Current as App).InitialDataLoaded += handler;
                    }

                    return true;
                }

                return false;
            }
        }

        /// <summary>
        /// Stores the page's state in isolated storage.
        /// </summary>
        protected virtual void StoreState()
        {
            // The base implementation does nothing
        }

        /// <summary>
        /// Restores the page's state from isolated storage.
        /// </summary>
        protected virtual void RestoreState(object sender, EventArgs args)
        {
            // The base implementation does nothing
        }

        protected virtual void OnAppBarSettingsClick(object sender, EventArgs e)
        {
            NavigationService.Navigate(UIConstants.SettingsView);
        }

        protected virtual void OnAppBarLocationClick(object sender, EventArgs e)
        {
            NavigationService.Navigate(UIConstants.LocationsListView);
        }
    }
}
