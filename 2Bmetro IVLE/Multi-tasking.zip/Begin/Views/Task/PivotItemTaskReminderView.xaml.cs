﻿// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Todo.Misc;
using Todo.Resources;
using Microsoft.Phone.Scheduler;

namespace Todo.Views
{
    /// <summary>
    /// Allows adding task reminders.
    /// </summary>
    public partial class PivotItemTaskReminderView : UserControl
    {
        /// <summary>
        /// Creates a new instance of the control. Be sure to call <see cref="UpdateUI"/> at least once
        /// before using the control for it to function properly.
        /// </summary>
        public PivotItemTaskReminderView()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Updates the control's UI in light of the reminder state of the task which the control
        /// expects as a data context.
        /// </summary>
        public void UpdateUI()
        {
            Task task = DataContext as Task;

            Reminder taskReminder = RemindersHelpers.GetExistingReminder(task.Id);

            UpdateUI(task, taskReminder);
        }

        /// <summary>
        /// Updates the control's UI in light of the reminder state of the task which the control
        /// expects as a data context.
        /// </summary>
        /// <param name="task">The task for which the UI is presented.</param>
        /// <param name="taskReminder">The reminder associated with the task.</param>
        private void UpdateUI(Task task, Reminder taskReminder)
        {
            // If the task does not have an associated reminder, offer a time for one
            if (taskReminder == null || !taskReminder.IsScheduled)
            {
                DateTime suggestedTime = task.DueDate.HasValue ? task.DueDate.Value.AddDays(-1).AddHours(12) : DateTime.MinValue;

                if (suggestedTime  > DateTime.Now)
                {
                    dateReminder.Value = suggestedTime;
                    timeReminder.Value = suggestedTime;
                }
                else
                {
                    dateReminder.Value = DateTime.Now;
                    timeReminder.Value = DateTime.Now;
                }

                buttonUpdateAdd.Content = ApplicationStrings.TaskReminderAddButton;
                buttonRemove.IsEnabled = false;
            }
            // The value already has an associated reminder
            else
            {
                dateReminder.Value = taskReminder.BeginTime;
                timeReminder.Value = taskReminder.BeginTime;

                textDescription.Text = taskReminder.Content;

                buttonUpdateAdd.Content = ApplicationStrings.TaskReminderUpdateButton;
                buttonRemove.IsEnabled = true;
            }
        }

        /// <summary>
        /// Causes the control to store its state in the supplied state store.
        /// </summary>
        /// <param name="stateStore">State store in which to store state information.</param>
        public void StoreState(IDictionary<string, object> stateStore)
        {
            stateStore["ReminderDescription"] = textDescription.Text;
            stateStore["ReminderDate"] = dateReminder.Value.Value;
            stateStore["ReminderTime"] = timeReminder.Value.Value;
        }

        /// <summary>
        /// Causes the control to restore its state from the supplied state store, assuming it has
        /// previously stored state information inside it.
        /// </summary>
        /// <param name="stateStore">State store from which to restore state information.</param>
        public void RestoreState(IDictionary<string, object> stateStore)
        {
            textDescription.Text = stateStore["ReminderDescription"].ToString();
            dateReminder.Value = (DateTime)stateStore["ReminderDate"];
            timeReminder.Value = (DateTime)stateStore["ReminderTime"];
        }

        private void RemoveClicked(object sender, RoutedEventArgs e)
        {
            Task task = DataContext as Task;

            RemindersHelpers.RemoveReminder(task.Id);

            UpdateUI(task, null);
        }

        private void AddOrUpdateClicked(object sender, RoutedEventArgs e)
        {
            Task task = DataContext as Task;

            Reminder taskReminder = RemindersHelpers.AddReminder(task, 
                dateReminder.Value.Value.Date.Add(timeReminder.Value.Value.TimeOfDay), true, textDescription.Text);

            if (taskReminder == null)
            {
                // Adding/updating has failed
                return;
            }

            UpdateUI(task, taskReminder);
        }
    }
}
