﻿// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using Todo.Misc;
using Todo.Resources;
using System.IO;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;

namespace Todo.Views
{
    /// <summary>
    /// Displays an image attachment and allows the user to delete it.
    /// </summary>
    public partial class ImageView : EntityEditingPage
    {
        private Attachment imageAttachment;

        private bool pageInitialized;

        /// <summary>
        /// Creates a new instance of the page.
        /// </summary>
        public ImageView()
        {
            InitializeComponent();

            InitializeAppBarText();

            pageInitialized = false;
        }

        protected override void OnNavigatedTo(System.Windows.Navigation.NavigationEventArgs e)
        {
            if (RegisterForInitialDataLoadCompleted(InitializePageAfterDataLoaded, RestoreState))
            {
                ApplicationBar.IsVisible = false;
            }
            else
            {
                InitializePage();
            }

            base.OnNavigatedTo(e);
        }

        protected override void OnNavigatingFrom(NavigatingCancelEventArgs e)
        {
            // If we did not remove focus from the caption box, binding did not update the value yet
            imageAttachment.TextNote = textCaption.Text;

            base.OnNavigatingFrom(e);
        }

        private void InitializePage()
        {
            if (pageInitialized)
            {
                return;
            }

            pageInitialized = true;

            imageAttachment = App.AttachmentViewModel.Items.First(
                att => att.Id == NavigationContext.GetGuidParam( UIConstants.AttachmentIdQueryParam) );

            DataContext = imageAttachment;

            ApplicationBar.IsVisible = true;
        }

        void InitializePageAfterDataLoaded(object sender, EventArgs e)
        {
            Dispatcher.BeginInvoke(() =>
            {
                InitializePage();
            });
        }

        protected override void StoreState()
        {
            State["Caption"] = textCaption.Text;

            base.StoreState();
        }

        protected override void RestoreState(object sender, EventArgs args)
        {
            Dispatcher.BeginInvoke(() =>
            {
                textCaption.Text = State["Caption"].ToString();
            });

            base.RestoreState(sender, args);
        }

        private void InitializeAppBarText()
        {
            ((ApplicationBarIconButton)ApplicationBar.Buttons[(int)Utils.ImageViewAppBarButtons.Save]).Text = ApplicationStrings.appBar_Save;
            ((ApplicationBarIconButton)ApplicationBar.Buttons[(int)Utils.ImageViewAppBarButtons.Cancel]).Text = ApplicationStrings.appBar_Cancel;
            ((ApplicationBarIconButton)ApplicationBar.Buttons[(int)Utils.ImageViewAppBarButtons.Delete]).Text = ApplicationStrings.appBar_Delete;             
            ((ApplicationBarMenuItem)ApplicationBar.MenuItems[(int)Utils.GeneralAppBarMenuItems.Settings]).Text = ApplicationStrings.appBar_Settings;
        }

        private void appBar_Delete(object sender, EventArgs e)
        {
            if (MessageBox.Show(ApplicationStrings.Msg_AttachmentDelete, ApplicationStrings.MsgTitle_AttachmentDelete,
                    MessageBoxButton.OKCancel) == MessageBoxResult.OK)
            {
                App.AttachmentViewModel.Delete(imageAttachment.Id);

                NavigationService.GoBack();
            }
        }

        private void appBar_OnSave(object sender, EventArgs e)
        {
            // In case we did not remove the focus from the caption textbox
            imageAttachment.TextNote = textCaption.Text;

            App.AttachmentViewModel.Update(imageAttachment);

            NavigationService.GoBack();
        }

        private void appBar_OnCancel(object sender, EventArgs e)
        {
            NavigationService.GoBack();
        }

        private void appBar_OnSettings(object sender, EventArgs e)
        {
            NavigationService.Navigate(UIConstants.SettingsView);
        }

        private void appBar_OnAbout(object sender, EventArgs e)
        {
            NavigationService.Navigate(UIConstants.AboutView);
        }
    }
}