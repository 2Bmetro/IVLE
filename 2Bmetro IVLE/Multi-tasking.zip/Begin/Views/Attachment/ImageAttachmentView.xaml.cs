﻿// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using Todo.Misc;
using Todo.Resources;
using System.Windows.Media.Imaging;
using System.IO;
using Microsoft.Devices;
using Microsoft.Phone.Tasks;

namespace Todo.Views
{
    /// <summary>
    /// Allows the user to capture an image and attach it to a task.
    /// </summary>
    public partial class ImageAttachmentView : EntityEditingPage
    {
        private Task task;

        private bool attachmentSet;

        CameraCaptureTask cameraCaptureTask;
        Attachment imageAttachment;
        bool isNew = false;

        public ImageAttachmentView()
        {
            InitializeComponent();

            InitializeAppBarText();

            cameraCaptureTask = new CameraCaptureTask();
            cameraCaptureTask.Completed += new EventHandler<PhotoResult>(cameraCaptureTask_Completed);

            attachmentSet = false;
        }

        private void cameraCaptureTask_Completed(object sender, PhotoResult e)
        {            
            byte[] bytes = new byte[e.ChosenPhoto.Length];
            e.ChosenPhoto.Position = 0;
            e.ChosenPhoto.Read(bytes, 0, (int)e.ChosenPhoto.Length);
            imageAttachment.Blob = bytes;
            isNew = true;
        }

        protected override void OnNavigatedTo(System.Windows.Navigation.NavigationEventArgs e)
        {
            if (RegisterForInitialDataLoadCompleted(NewImageAttachmentAfterDataLoaded, RestoreState))
            {
                ApplicationBar.IsVisible = false;
            }
            else
            {
                NewImageAttachment();
            }

            base.OnNavigatedTo(e);
        }

        private void NewImageAttachmentAfterDataLoaded(object sender, EventArgs e)
        {
            Dispatcher.BeginInvoke(() =>
                {
                    NewImageAttachment();
                });
        }

        private void NewImageAttachment()
        {
            if (attachmentSet)
            {
                return;
            }

            Guid taskId = NavigationContext.GetGuidParam(UIConstants.TaskIdQueryParam); 
            task = App.TasksViewModel.Items.First(t => t.Id == taskId);

            imageAttachment = new Attachment();
            imageAttachment.Id = Guid.NewGuid();
            imageAttachment.Id = new Guid(Utils.AttachmentTypeIDImage);

            DataContext = imageAttachment;
            attachmentSet = true;
        }

        protected override void StoreState()
        {
            State["PreviewImage"] = (imageAttachment.Blob == null) ? null : imageAttachment.Blob.ToArray();
            State["Caption"] = textCaption.Text;

            base.StoreState();
        }

        protected override void RestoreState(object sender, EventArgs args)
        {
            Dispatcher.BeginInvoke(() =>
                {
                    imageAttachment.Blob = State["PreviewImage"] as byte[];
                    textCaption.Text = State["Caption"].ToString();
                });

            base.RestoreState(sender, args);
        }

        private void appBar_OnAdd(object sender, EventArgs e)
        {
            if (!isNew)
            {
                MessageBox.Show(ApplicationStrings.Msg_NoImage);

                return;
            }            

            imageAttachment.Items = task;

            App.AttachmentViewModel.Insert(imageAttachment);
            
            NavigationService.GoBack();
        }        

        private void appBar_OnCancel(object sender, EventArgs e)
        {
            if (isNew)
            {
                if (MessageBox.Show(ApplicationStrings.Msg_ImageDiscard, ApplicationStrings.MsgTitle_ImageDiscard,
                    MessageBoxButton.OKCancel) == MessageBoxResult.Cancel)
                {
                    NavigationService.GoBack();
                }
            }
            else
            {
                NavigationService.GoBack();
            }
        }

        private void InitializeAppBarText()
        {
            ((ApplicationBarIconButton)ApplicationBar.Buttons[(int)Utils.ImageAttachmentViewAppBarButtons.Add]).Text = ApplicationStrings.appBar_Add;
            ((ApplicationBarIconButton)ApplicationBar.Buttons[(int)Utils.ImageAttachmentViewAppBarButtons.Cancel]).Text = ApplicationStrings.appBar_Cancel;             
            ((ApplicationBarMenuItem)ApplicationBar.MenuItems[(int)Utils.GeneralAppBarMenuItems.Settings]).Text = ApplicationStrings.appBar_Settings;
        }

        private void appBar_OnAbout(object sender, EventArgs e)
        {
            NavigationService.Navigate( UIConstants.AboutView );
        }

        private void appBar_OnSettings(object sender, EventArgs e)
        {
            NavigationService.Navigate(UIConstants.SettingsView);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            cameraCaptureTask.Show();
        }
    }
}