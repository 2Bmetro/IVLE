﻿// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Todo.Misc;

namespace Todo
{
    public static class UIConstants
    {
        public readonly static Uri LocationsListView = new Uri("/Views/Location/LocationListView.xaml", UriKind.Relative);
        public readonly static Uri LocationEditView = new Uri("/Views/Location/EditLocationView.xaml", UriKind.Relative);
        public readonly static Uri SettingsView = new Uri("/Views/Misc/SettingsView.xaml", UriKind.Relative);
        public readonly static Uri AboutView = new Uri("/Views/Misc/AboutView.xaml", UriKind.Relative);
        public readonly static Uri ProjectListView = new Uri("/Views/Project/ProjectsListView.xaml", UriKind.Relative);
        public readonly static Uri HomeUriWithPop = new Uri(string.Format("/Views/MainView.xaml?{0}=true", PopQueryParam), UriKind.Relative); 

        public const string ModeQueryParam = "Mode";
        public const string FromQueryParam = "From";
        public const string ReminderQueryParam = "Reminder";
        public const string PopQueryParam = "Pop"; 

        public const string LocationIdQueryParam = "locationid";
        public const string TaskIdQueryParam = "taskid";         
        public const string ProjectIdQueryParam = "projectid";
        public const string AttachmentIdQueryParam = "attachmentid";


        public const string RestoreStatePivotIndex = "PivotIndex";
        public const int NearbyPivotIndex = 3; 

        public static Uri MakeLocationEditViewUri(Location location)
        {
            string uri = string.Format("/Views/Location/EditLocationView.xaml?{0}={1}",
                    LocationIdQueryParam, location.Id); 
            return new Uri( uri , UriKind.Relative);
        } 

        public static Uri MakeTaskEditViewUri ( Task task ) 
        { 
            string uri = string.Format ( "/Views/Task/EditTaskView.xaml?{0}={1}", 
                    TaskIdQueryParam, task.Id);

            return new Uri(uri, UriKind.Relative); 
        }

        public static Uri MakeEditTaskViewUriForProject( Project project )
        {
            return new Uri(
                           string.Format("/Views/Task/EditTaskView.xaml?{0}={1}", 
                           ProjectIdQueryParam, project.Id ),
                          UriKind.Relative);
        } 
        public static Uri MakeDefaultProjectEditTaskViewUri () 
        { 
             return new Uri  ( 
                 string.Format ( "/Views/Task/EditTaskView.xaml?{0}={1}" , ProjectIdQueryParam, Utils.ProjectIDDefault), 
                UriKind.Relative);
        } 

        public static Uri MakeTaskViewUri ( Task task )
        { 
            return new Uri ( 
                string.Format ( "/Views/Task/TaskView.xaml?{0}={1}", 
                        TaskIdQueryParam,  task.Id ), UriKind.Relative);
        }

        public static Uri MakeReminderUri(Task task)
        {
            return new Uri ( 
                string.Format ( "/Views/Task/TaskView.xaml?{0}={1}&{2}={3}" , 
                       TaskIdQueryParam, task.Id.ToString(), FromQueryParam, ReminderQueryParam ) 
                , UriKind.Relative);
        }

        public static Uri MakePinnedProjectUri( Project p)
        {
            return new Uri( 
                string.Format( "/Views/Project/ProjectDetailsView.xaml?{0}={1}&{2}={3}" , 
                                Constants.PINPROJECTIDPARAM , p.Id, Constants.PINPROJECTCOLORPARAM , p.Color) 
                            , UriKind.Relative);
        }

        public static Uri MakeEditProjectUri(Project p)
        {
            if (p != null)
            {
                return new Uri(
                    string.Format("/Views/Project/EditProjectDetailsView.xaml?{0}={1}",
                    ProjectIdQueryParam, p.Id), UriKind.Relative);
            }
            else
            {
                return new Uri( "/Views/Project/EditProjectDetailsView.xaml", UriKind.Relative);
            } 
        }

        public static Uri MakeViewProjectUri(Project p)
        {
            return new Uri(
            string.Format("/Views/Project/ProjectItemsView.xaml?{0}={1}",
                    ProjectIdQueryParam, p.Id), UriKind.Relative); 
        }

        public static Uri MakeProjectDetailsViewUri(Project p)
        {
            return new Uri(
                   string.Format("/Views/Project/ProjectDetailsView.xaml?{0}={1}",
                   ProjectIdQueryParam, p.Id), UriKind.Relative); 
        } 


        public static Uri MakeDefaultTileUri( string color)
        {
            return new Uri( string.Format ( "/Images/Tiles/{0}check.png", color), UriKind.Relative ); 
        } 

     


        public static Uri MakeProjectItemsViewUri(Project p)
        {
            return new Uri(
                   string.Format("/Views/Project/ProjectItemsView.xaml?{0}={1}",
                   ProjectIdQueryParam, p.Id), UriKind.Relative); 
        } 

         public const string UseBackgroundLocation = "UseBackgroundLocation";
         public const string UseBackgroundTaskUpdater =  "UseBackgroundTaskUpdater"; 
         public const string HideCompletedOnRefresh =  "HideCompletedOnRefresh"  ;
         public const string HideCompletedOnStartup = "HideCompletedOnStartup";
         public const string ColorEntries = "ColorEntries"; 

    }
}
