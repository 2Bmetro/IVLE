﻿// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.Collections.ObjectModel;
using Todo.Misc;
using Todo.Interfaces;

namespace Todo.ViewModels
{
    public abstract class ViewModelItemsBase<T> : INotifyPropertyChanged 
                                            where T : ITodoTable    
    {
        protected DataContextBase todoDC;

        private ObservableCollection<T> items;

        public ViewModelItemsBase(DataContextBase todoDC)
        {
            this.Items = new ObservableCollection<T>();

            this.todoDC = todoDC;
        }

        public bool IsDataLoaded
        {
            get;
            protected set;
        }

        public ObservableCollection<T> Items 
        { 
            get
            {
                return items;
            }
            private set
            {
                if (items != value)
                {
                    items = value;
                    NotifyPropertyChanged("Items");
                }
            }
        }

        public abstract void LoadData();

        public void DropData()
        {
            this.Items = new ObservableCollection<T>();
            IsDataLoaded = false;
        }

        public virtual T Find(Guid id)
        {
            T found = Items.FirstOrDefault<T>(item => item.Id == id);
            System.Diagnostics.Debug.Assert(found != null); 
            return found; 
        } 

        public event PropertyChangedEventHandler PropertyChanged;
        protected void NotifyPropertyChanged(String propertyName)
        {
            Utils.RaisePropertyChanged(propertyName, this, PropertyChanged);
        }
    }

    public abstract class ViewModelBase  : INotifyPropertyChanged
    {        
        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged (String propertyName)
        {
            Utils.RaisePropertyChanged(propertyName, this, PropertyChanged);
        }
    }
}
