﻿// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.Generic;
using System.Reflection;

namespace Todo.Models
{
    public class MetaData
    {
        /// <summary>
        /// Returns a list of default due date values.
        /// </summary>
        public static List<DefaultDueDate> DefaultDueDateValues  
        { 
            get 
            {
                if (defaultDueDateValues == null)
                {
                    defaultDueDateValues = EnumHelper<DefaultDueDate>.GetValues();
                } 
                return defaultDueDateValues; 
            } 
        }

        /// <summary>
        /// Returns a list of available task statuses.
        /// </summary>
        public static List<TaskStatus> TaskStatusValues
        {
            get
            {
                if (taskStatusValues == null)
                {
                    taskStatusValues = EnumHelper<TaskStatus>.GetValues();
                }
                return taskStatusValues; 
            }
        }

        /// <summary>
        /// Returns a list of possible priority values.
        /// </summary>
        public static List<PriorityValue> PriorityValues
        {
            get
            {
                if (priorityValues == null)
                {
                    priorityValues = EnumHelper<PriorityValue>.GetValues();
                }
                return priorityValues;
            }
        }

        static List<DefaultDueDate> defaultDueDateValues;
        static List<TaskStatus> taskStatusValues;
        static List<PriorityValue> priorityValues;
    }

    /// <summary>
    /// Helps returning a list of all values available in a specific enumeration.
    /// </summary>
    /// <typeparam name="T">The enumeration type to work with.</typeparam>
    public static class EnumHelper<T>  where T: struct
    {        
        /// <summary>
        /// Gets a list of all values in the enumeration associated with the calling object.
        /// </summary>
        /// <returns>A list of all values in the enumeration associated with the calling object.</returns>
        public static List<T> GetValues()
        {
            System.Diagnostics.Debug.Assert ( typeof(T).IsEnum ); 
            var fields = typeof(T).GetFields( BindingFlags.Static | BindingFlags.Public ) ;
            List<T> list = new List<T>(); 
            for (var i = 0; i < fields.Length; i++)
            {                
                    list.Add((T)fields[i].GetValue(null));                 
            }
            return list; 
        } 
    } 
}
