﻿// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.ComponentModel;
using Microsoft.Phone.BackgroundTransfer;
using Todo.Misc;
using System.IO.IsolatedStorage;
using Todo.Interfaces;

namespace Todo.Models
{
    public class SettingsModel : INotifyPropertyChanged
    {

        public bool ShowCompletedPivotInMainView
        {
            get
            {
                return showCompletedPivotInMainView;
            }
            set
            {
                if (showCompletedPivotInMainView != value)
                {
                    showCompletedPivotInMainView = value;
                    OnPropertyChanged("ShowCompletedPivotInMainView");
                }
            }
        }

        public SyncSettings SyncSettings
        {
            get
            {
                if (syncSettings == null)
                {
                    syncSettings = new SyncSettings();
                }
                return syncSettings;
            }

            //TODO: is it needed? 
            internal set
            {
                syncSettings = value;
            }
        }

        #region private
        bool showCompletedPivotInMainView;
        SyncSettings syncSettings;
        #endregion
        #region INotifyPropertyChanged Members

        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged(string propertyname)
        {
            PropertyChangedEventHandler eh = PropertyChanged;
            if (eh != null)
            {
                eh(this, new PropertyChangedEventArgs(propertyname));
            }
        }


        #endregion
    }


    public class SyncSettings : INotifyPropertyChanged
    {
        public SyncFrequency SyncFrequency
        {
            get
            {
                return syncFrequency;
            }
            set
            {
                syncFrequency = value;
                Utils.RaisePropertyChanged("SyncFrequency", this, PropertyChanged);
            }
        }

        public bool SaveCredentials
        {
            get
            {
                return saveCredentials;
            }
            set
            {
                if (saveCredentials != value)
                {
                    saveCredentials = value;
                    Utils.RaisePropertyChanged("SaveCredentials", this, PropertyChanged);
                }
            }
        }

        #region private
        bool saveCredentials;
        SyncFrequency syncFrequency;
        #endregion


        #region INotifyPropertyChanged Members

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion
    }
}
