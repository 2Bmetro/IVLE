﻿// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

using Microsoft.Phone.Scheduler;
using System.Runtime.Serialization;
using Todo;
using System.Collections.Generic;
using System.Device.Location;
using System.IO.IsolatedStorage;
using Microsoft.Phone.Shell;
using System;
using System.Threading;
using Todo.Misc;

namespace TaskLocationAgent
{
    //DEMOSTOP#9 
    public class TaskScheduler : ScheduledTaskAgent
    {
        /// <summary>
        /// Agent that runs a scheduled task
        /// </summary>
        /// <param name="task">
        /// The invoked task
        /// </param>
        /// <remarks>
        /// This method is called when a periodic or resource intensive task is invoked
        /// </remarks>
        protected override void OnInvoke(ScheduledTask task)
        {

            SettingsWorkaround preferences = SettingsWorkaround.Load();
            if (preferences == null)
            {
                NotifyComplete();
                return;
            }

            if (preferences.UseLocation)
            {
                runningHelperHandles = new WaitHandle[(int)TaskOrder.End];
                runningHelpers = new IBackgroundTaskHelper[(int)TaskOrder.End];
                AutoResetEvent locationSyncEvent = new AutoResetEvent(false);                
                runningHelperHandles[(int)TaskOrder.Location] = locationSyncEvent;

                System.Threading.ThreadPool.QueueUserWorkItem(DoLocation,
                        runningHelperHandles[(int)TaskOrder.Location]);
            } 

            if ( preferences.UseTileUpdater ) 
                DoTileUpdates(null);    

             

            TimeSpan waitToSyncThreads = TimeSpan.FromSeconds(8);
            if (System.Diagnostics.Debugger.IsAttached)
                waitToSyncThreads = TimeSpan.FromSeconds(30);

            if (preferences.UseLocation)
            {
                System.Threading.WaitHandle.WaitAny(runningHelperHandles, waitToSyncThreads);

                for (int x = 0; x < runningHelpers.Length; x++)
                {
                    if (runningHelpers[x] != null)
                        runningHelpers[x].Stop();
                }
            } 

            if (locationStatus == TaskHelperCompletionStatus.Blocked &&
                updaterStatus == TaskHelperCompletionStatus.Blocked)
                this.Abort();
            else
                this.NotifyComplete();

        }

        void DoLocation(object waitHandle)
        {           
            BackgroundLocationService locationService = new BackgroundLocationService();
            locationService.Completed += new EventHandler<TaskHelperEventArgs>(locationService_Completed);          
            runningHelpers[(int)TaskOrder.Location] = locationService;
            locationService.Start();

        }

        void DoTileUpdates(object ununsed)
        {

            TaskProgressTileUpdater updater = new TaskProgressTileUpdater();             
            updater.Completed += new EventHandler<TaskHelperEventArgs>(updater_Completed);            
            updater.Start();
        }

        WaitHandle[] runningHelperHandles;
        IBackgroundTaskHelper[] runningHelpers;

        TaskHelperCompletionStatus locationStatus = TaskHelperCompletionStatus.Started;
        TaskHelperCompletionStatus updaterStatus = TaskHelperCompletionStatus.Started;
        void updater_Completed(object sender, TaskHelperEventArgs e)
        {
            // throw new NotImplementedException();
            updaterStatus = e.Status;
            System.Diagnostics.Debug.WriteLine("Updater completed " + e.Status.ToString() + " " + DateTime.Now.ToString());

        }

        void locationService_Completed(object sender, TaskHelperEventArgs e)
        {
            locationStatus = e.Status;
            if (runningHelperHandles.Length > 0 && runningHelperHandles[(int)TaskOrder.Location] != null)
            {
                AutoResetEvent evt = runningHelperHandles[(int)TaskOrder.Location] as AutoResetEvent;
                if (evt != null)
                    evt.Set();
            }
            System.Diagnostics.Debug.WriteLine("Location completed " + e.Status.ToString() + " " + DateTime.Now.ToString());
        }

        enum TaskOrder : int
        {
            Location,
            TileUpdates,
            End = 1
        };
    }
}
