﻿// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.Generic;
using Todo;
using Microsoft.Phone.Shell;
using System.Device.Location;
using Microsoft.Phone.Scheduler;
using System.IO.IsolatedStorage;
using System.Runtime.Serialization;

namespace TaskLocationAgent
{
    public class BackgroundLocationService:  IBackgroundTaskHelper
    {
        GeoCoordinateWatcher watcher;
        List<Location> locations;
       
        private void NotifyComplete()
        {
                           EventHandler<TaskHelperEventArgs> eh = Completed;
                if (eh != null)
                    eh(this, new TaskHelperEventArgs(Status));
                    }

        bool isRunning = false; 

        public void DoWork ()
        {
            locations = GetLocations();
            if (locations == null || locations.Count == 0)
            {
                NotifyComplete();
                return;
            }
             
            watcher = new GeoCoordinateWatcher();
            watcher.PositionChanged += new System.EventHandler<GeoPositionChangedEventArgs<GeoCoordinate>>(watcher_PositionChanged);
            watcher.Start();

        }

        public void Stop()
        {
            if (isRunning)
            {               
                isRunning = false;
                CleanUp(); 
                Status = TaskHelperCompletionStatus.TimedOut;
                NotifyComplete();
            } 
        } 

        List<Location> GetLocationsFromXML()
        {
            using (System.IO.IsolatedStorage.IsolatedStorageFile iso = System.IO.IsolatedStorage.IsolatedStorageFile.GetUserStoreForApplication())
            {
                if (iso.FileExists(Constants.LOCATIONSXMLPATH))
                {
                    using (IsolatedStorageFileStream stream = iso.OpenFile(Constants.LOCATIONSXMLPATH, System.IO.FileMode.Open))
                    {
                        DataContractSerializer serializer = new DataContractSerializer(typeof(List<Location>));
                        locations = serializer.ReadObject(stream) as List<Location>;
                    }
                } 
            }
            return locations;
        }

        List<Location> GetLocations()
        {
            locations = new List<Location>();
            Location location = new Location();
            location.Id = Guid.NewGuid();
            location.Name = "Work";
            location.Address = "One Microsoft Way";
            location.City = "Redmond";
            location.State = "WA";
            location.Latitude = 47.639767;
            location.Longitude = -122.129755;
            location.ZipCode = "98052";
            locations.Add(location);

            location = new Location();
            location.Id = Guid.NewGuid();
            location.Name = "Home";
            location.Address = "123 Main";
            location.City = "Seattle";
            location.State = "WA";
            location.Latitude = 47.599903;
            location.Longitude = -122.333728;
            location.ZipCode = "98104";
            locations.Add(location);
            return locations;
        }
        bool doOnce = true;
        void watcher_PositionChanged(object sender, GeoPositionChangedEventArgs<GeoCoordinate> e)
        {
            lock (this)
            {
                if (doOnce)
                {
                    Location location = LocationHelper.FindNearestMeetingThreshold(locations, e.Position.Location, 10.0);
                    if (location != null)
                    {

                        ShellToast toast = new ShellToast();
                        toast.Content = "";
                        toast.Title = "You have tasks nearby " + location.Name;
                        toast.NavigationUri = Constants.MakeNearbyPivotUri();
                        toast.Show();
                        Status = TaskHelperCompletionStatus.Completed;
                        CleanUp();
                        NotifyComplete();
                    }
                    doOnce = false; 
                }
            };
        }

        void CleanUp( )
        {
            if (watcher != null)
            {
                watcher.Stop();
                isRunning = false; 
                //      watcher.Dispose(); 
            }
           
        }



        public event EventHandler<TaskHelperEventArgs> Completed;

        public void Start()
        {
            try
            {
                isRunning = true;  
                DoWork();
                Status = TaskHelperCompletionStatus.Completed; 
            }
            catch (Exception )
            {
                Status = TaskHelperCompletionStatus.Failed;
                NotifyComplete(); 
                //This should log the error 
            }
            // We do not notify because this process runs asynchronous on GeoCoordinateWatcher's callback.. 
        }

        public int ProgressCompleted
        {
            get;
            private set;  
        }

        public TaskHelperCompletionStatus Status
        {
            get; private set; 
        }
    }
}
