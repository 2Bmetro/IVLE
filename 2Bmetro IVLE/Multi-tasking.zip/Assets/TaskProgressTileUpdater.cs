﻿// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Shell;
using Todo;
using Todo.Misc;
using System.Linq; 


namespace TaskLocationAgent
{

    public class TaskProgressTileUpdater : IBackgroundTaskHelper 
    {

        public event EventHandler<TaskHelperEventArgs> Completed;

        public void Start()
        {
            DoWork();   
        }

        public void DoWork()
        {

            try
            {
                var tiles = ShellTile.ActiveTiles;
                foreach (ShellTile tile in tiles)
                {
                    StandardTileData updatedData = new StandardTileData();
                    Project project = GetProject(tile);
                    if (project != null)
                    {
                        int count = GetOverdueCount(project);
                        string color = GetColorName ( project.Color );
                        if (count > 0)
                        {
                            updatedData.BackgroundImage =
                            new Uri(string.Format("/Images/Tiles/{0}{1}.png",
                                color, count), UriKind.Relative); 
                        }
                        else
                        {
                            updatedData.BackgroundImage =
                            new Uri(string.Format("/Images/Tiles/{0}check.png",
                                color), UriKind.Relative); 
                        } 
                         
                        updatedData.BackBackgroundImage= new Uri(
                                string.Format("/Images/Tiles/{0}.png",
                                  project.Color.Substring(1)), UriKind.Relative); 

                        updatedData.BackContent = GetTasks(project);                        
                        tile.Update(updatedData);
                    }
                }
                Status = TaskHelperCompletionStatus.Completed;
                
            }
            catch (Exception ex)
            {
                Status = TaskHelperCompletionStatus.Failed; 
            }
            NotifyComplete();
        }


        Project GetProject(ShellTile tile)
        {             
         
            Project project = null;

            int queryStringIndex = tile.NavigationUri.OriginalString.IndexOf(Constants.QUERYSTRINGSTART);
            if (queryStringIndex > 0)
            {
                project = new Project();
                string querystring = tile.NavigationUri.OriginalString.Substring(queryStringIndex + Constants.QUERYSTRINGSTART.Length);
                string[] parameters = querystring.Split(Constants.QUERYSTRINGSEPARATORS);
                if (parameters.Length >= 2 && parameters[0].Contains(Constants.PINPROJECTIDPARAM))
                    project.Id = new Guid(parameters[1]);
                if (parameters.Length >= 4 && parameters[2].Contains(Constants.PINPROJECTCOLORPARAM))
                    project.Color = parameters[3];
            }
            
            return project; 
        }

        static Random randomCount = new Random();
        string[] fakeTasks = new string[] 
                {   "Submit expense report" , 
                    "Purchase anniversary gift", 
                    "Call mom" , 
                    "Take life seriously" }; 

        int GetOverdueCount(Project project)
        {
            return randomCount.Next(9);     
        }

        static int fakeTasksOrder; 
        public string GetTasks(Project project)
        {
            if (fakeTasksOrder >= fakeTasks.Length)
                fakeTasksOrder = 0;

            return fakeTasks[fakeTasksOrder++]; 
        }


        public string GetColorName(string hexColor)
        {            
            ColorEntryList colorEntries = new ColorEntryList
            {                                 
                new ColorEntry { Name = "Red", Color = "#FFFF0000"},            
                new ColorEntry { Name = "Gray", Color = "#FF808080"},
                new ColorEntry { Name = "Orange", Color = "#FFFF7200"},
                new ColorEntry { Name = "Blue", Color = "#FF0E68AD"},
                new ColorEntry { Name = "Fuchsia", Color = "#FFDA1773"},
                new ColorEntry { Name = "Purple", Color = "#FF6b217E"},
                new ColorEntry { Name = "Green", Color = "#FF62A616"},
                new ColorEntry { Name = "Cyan", Color = "#FF109791"},
                new ColorEntry { Name = "Yellow", Color = "#FFFFAE00"},
                new ColorEntry { Name = "Mauve", Color = "#FFA186BE"},
                new ColorEntry { Name = "Salmon", Color = "#FFFF835D"}
            };

            var colorEntry =  colorEntries.FirstOrDefault(x => x.Color == hexColor);
            if (colorEntry != null)
                return colorEntry.Name;
            else
                return "Blue"; 
   
        } 

        #region  IBackgroundTaskHelper stuff

        private void NotifyComplete()
        {
            EventHandler<TaskHelperEventArgs> eh = Completed;
            if (eh != null)
                eh(this, new TaskHelperEventArgs(Status));
        }

        public void Stop()
        {
            Status = TaskHelperCompletionStatus.TimedOut;
            NotifyComplete();
        }

        public int ProgressCompleted
        {
            get;
            private set;
        }

        public TaskHelperCompletionStatus Status
        {
            get;
            private set;
        }

        #endregion
    }
}
